"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_employee-list_employee-list_module_ts"],{

/***/ 3964:
/*!*********************************************************************!*\
  !*** ./src/app/pages/employee-list/employee-list-routing.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmployeeListPageRoutingModule": () => (/* binding */ EmployeeListPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _employee_list_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./employee-list.page */ 7794);




const routes = [
    {
        path: '',
        component: _employee_list_page__WEBPACK_IMPORTED_MODULE_0__.EmployeeListPage
    }
];
let EmployeeListPageRoutingModule = class EmployeeListPageRoutingModule {
};
EmployeeListPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], EmployeeListPageRoutingModule);



/***/ }),

/***/ 1782:
/*!*************************************************************!*\
  !*** ./src/app/pages/employee-list/employee-list.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmployeeListPageModule": () => (/* binding */ EmployeeListPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _employee_list_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./employee-list-routing.module */ 3964);
/* harmony import */ var _employee_list_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./employee-list.page */ 7794);







let EmployeeListPageModule = class EmployeeListPageModule {
};
EmployeeListPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _employee_list_routing_module__WEBPACK_IMPORTED_MODULE_0__.EmployeeListPageRoutingModule
        ],
        declarations: [_employee_list_page__WEBPACK_IMPORTED_MODULE_1__.EmployeeListPage]
    })
], EmployeeListPageModule);



/***/ }),

/***/ 7794:
/*!***********************************************************!*\
  !*** ./src/app/pages/employee-list/employee-list.page.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmployeeListPage": () => (/* binding */ EmployeeListPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _employee_list_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./employee-list.page.html?ngResource */ 6872);
/* harmony import */ var _employee_list_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./employee-list.page.scss?ngResource */ 8215);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/common.service */ 5620);






let EmployeeListPage = class EmployeeListPage {
    constructor(commonService, router) {
        this.commonService = commonService;
        this.router = router;
        this.allEmployees = [];
        this.allEmployeesReal = [];
    }
    ngOnInit() {
        // this.fetchEmployee()
    }
    ionViewWillEnter() {
        this.fetchEmployee();
    }
    ////Fetch Employees who are on boarding
    fetchEmployee() {
        this.commonService.getEmployeeList().then((resp) => {
            this.allEmployees = resp;
            this.allEmployeesReal = resp;
        });
    }
    searchEmployee(event) {
        console.log("event ", event.target.value);
        let searchTerm = event.target.value;
        this.allEmployees = this.allEmployeesReal.filter(e => e.firstName.toLowerCase().includes(searchTerm.toLowerCase()));
    }
    ////Method to navigate on onboarding page for updating details
    updateEmployee(request) {
        this.router.navigate(['/employee-onboarding/' + request.employeeId]);
    }
};
EmployeeListPage.ctorParameters = () => [
    { type: _services_common_service__WEBPACK_IMPORTED_MODULE_2__.CommonService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router }
];
EmployeeListPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-employee-list',
        template: _employee_list_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_employee_list_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], EmployeeListPage);



/***/ }),

/***/ 8215:
/*!************************************************************************!*\
  !*** ./src/app/pages/employee-list/employee-list.page.scss?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = "ion-menu-button {\n  color: var(--ion-color-primary);\n}\n\n#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n\n.demo-chart {\n  width: 100%;\n  height: 300px;\n}\n\nion-grid {\n  --ion-grid-column-padding: 10px;\n  border-collapse: collapse;\n  border-style: hidden;\n  margin-top: 0px;\n  padding-top: 0px;\n}\n\nion-grid ion-row {\n  margin: 5px 0px;\n}\n\nion-grid ion-row:first-child {\n  background-color: #2980b9;\n  border-radius: 5px;\n  color: #fff;\n  font-weight: bold;\n}\n\nion-grid ion-col {\n  border-bottom: 0;\n  border-right: 0;\n}\n\n:host ::ng-deep .ngx-datatable .datatable-body .datatable-scroll {\n  display: inherit;\n}\n\n.odd {\n  background-color: #161b22;\n  color: #fff;\n  border-radius: 5px;\n}\n\n.even {\n  background-color: #161b22;\n  color: #fff;\n  border-radius: 5px;\n}\n\nion-item {\n  --background: transparent;\n}\n\nion-grid ion-col {\n  border-bottom: 0;\n  border-right: 0;\n  font-size: 14px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImVtcGxveWVlLWxpc3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBO0VBQ0ksK0JBQUE7QUFESjs7QUFJRTtFQUNFLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxPQUFBO0VBQ0EsUUFBQTtFQUNBLFFBQUE7RUFDQSwyQkFBQTtBQURKOztBQUlFO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0FBREo7O0FBSUU7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsU0FBQTtBQURKOztBQUlFO0VBQ0UscUJBQUE7QUFESjs7QUFJRTtFQUNFLFdBQUE7RUFDQSxhQUFBO0FBREo7O0FBSUU7RUFDRSwrQkFBQTtFQUNBLHlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUFESjs7QUFHSTtFQUNFLGVBQUE7QUFETjs7QUFJSTtFQUNFLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7QUFGTjs7QUFLSTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtBQUhOOztBQU9FO0VBQ0UsZ0JBQUE7QUFKSjs7QUFPRTtFQUNFLHlCQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0FBSko7O0FBT0U7RUFDRSx5QkFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtBQUpKOztBQU9FO0VBQ0UseUJBQUE7QUFKSjs7QUFPRTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7QUFKSiIsImZpbGUiOiJlbXBsb3llZS1saXN0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxuXG5pb24tbWVudS1idXR0b24ge1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gIH1cbiAgXG4gICNjb250YWluZXIge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgbGVmdDogMDtcbiAgICByaWdodDogMDtcbiAgICB0b3A6IDUwJTtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSk7XG4gIH1cbiAgXG4gICNjb250YWluZXIgc3Ryb25nIHtcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgbGluZS1oZWlnaHQ6IDI2cHg7XG4gIH1cbiAgXG4gICNjb250YWluZXIgcCB7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIGxpbmUtaGVpZ2h0OiAyMnB4O1xuICAgIGNvbG9yOiAjOGM4YzhjO1xuICAgIG1hcmdpbjogMDtcbiAgfVxuICBcbiAgI2NvbnRhaW5lciBhIHtcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG4gIH1cbiAgXG4gIC5kZW1vLWNoYXJ0IHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDMwMHB4O1xuICB9XG4gIFxuICBpb24tZ3JpZCB7XG4gICAgLS1pb24tZ3JpZC1jb2x1bW4tcGFkZGluZzogMTBweDtcbiAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xuICAgIGJvcmRlci1zdHlsZTogaGlkZGVuO1xuICAgIG1hcmdpbi10b3A6IDBweDtcbiAgICBwYWRkaW5nLXRvcDogMHB4O1xuICBcbiAgICBpb24tcm93IHtcbiAgICAgIG1hcmdpbjogNXB4IDBweDtcbiAgICB9XG4gIFxuICAgIGlvbi1yb3c6Zmlyc3QtY2hpbGQge1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjogIzI5ODBiOTtcbiAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgfVxuICBcbiAgICBpb24tY29sIHtcbiAgICAgIGJvcmRlci1ib3R0b206IDA7XG4gICAgICBib3JkZXItcmlnaHQ6IDA7XG4gICAgfVxuICB9XG4gIFxuICA6aG9zdCA6Om5nLWRlZXAgLm5neC1kYXRhdGFibGUgLmRhdGF0YWJsZS1ib2R5IC5kYXRhdGFibGUtc2Nyb2xsIHtcbiAgICBkaXNwbGF5OiBpbmhlcml0O1xuICB9XG4gIFxuICAub2RkIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMTYxYjIyO1xuICAgIGNvbG9yOiAjZmZmO1xuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgfVxuICBcbiAgLmV2ZW4ge1xuICAgIGJhY2tncm91bmQtY29sb3I6ICMxNjFiMjI7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICB9XG4gIFxuICBpb24taXRlbSB7XG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgfVxuICBcbiAgaW9uLWdyaWQgaW9uLWNvbCB7XG4gICAgYm9yZGVyLWJvdHRvbTogMDtcbiAgICBib3JkZXItcmlnaHQ6IDA7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICB9Il19 */";

/***/ }),

/***/ 6872:
/*!************************************************************************!*\
  !*** ./src/app/pages/employee-list/employee-list.page.html?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar color=\"gray\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Employee List</ion-title>\n    <ion-buttons slot=\"end\" class=\"hidden-sm-down\">\n      <ion-button [routerLink]=\"['/employee-onboarding/null']\" color=\"dark\" style=\"font-weight: 300;width: 100px;\">\n        <ion-icon name=\"person-add-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n  <ion-toolbar color=\"gray\">\n    <ion-searchbar (ionChange)=\"searchEmployee($event)\" debounce=\"500\" placeholder=\"Search Employee\"></ion-searchbar>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <!-- Desktop View -->\n  <ion-grid class=\"ion-margin hidden-sm-down\">    \n    <ion-row style=\"\n    position: sticky;\n    top: 0px;\n    z-index: 999999999;\n    background-color: #0d1116;\n    color: #fff;\n    margin: 0px;\n  \">\n      <ion-col size=\"3\">Employee Name</ion-col>\n      <ion-col size=\"3\">Designation</ion-col>\n      <ion-col size=\"2.5\">Official Mail Id</ion-col>\n      <ion-col size=\"2\">Contact No.</ion-col>\n      <ion-col size=\"1.5\">Date of Joining</ion-col>\n      <!-- <ion-col size=\"0.5\"></ion-col> -->\n    </ion-row>\n    <ion-row *ngIf=\"allEmployees.length == 0\">\n      <!-- <ion-row> -->\n      <div id=\"container\">\n        <img width=\"100px\" src=\"assets/loader.gif\" alt=\"\">\n      </div>\n    </ion-row>\n    <ion-row *ngFor=\"let request of allEmployees; index as i\" [ngClass]=\"(i % 2 == 0) ? 'odd' : 'even'\"  (click)=\"updateEmployee(request)\">\n\n      <ion-col size=\"3\" style=\"padding: 0px\">\n        <ion-item lines=\"none\">\n          <ion-avatar slot=\"start\">\n            <ion-img [src]=\"request.image\"></ion-img>\n          </ion-avatar>\n          <ion-label>\n            {{request.firstName}} {{request.middleName}} {{request.lastName}}\n          </ion-label>\n        </ion-item>\n      </ion-col>\n      <ion-col style=\"padding: 0px\" size=\"3\">\n        <ion-item lines=\"none\">\n          <ion-label>\n            {{request.designation}}\n          </ion-label>\n        </ion-item>\n      </ion-col>\n      <ion-col style=\"padding: 0px\" size=\"2.5\">\n        <ion-item lines=\"none\">\n          <ion-label>\n            {{request.officialEmail}}\n            </ion-label>\n            </ion-item>\n          </ion-col>\n      <ion-col style=\"padding: 0px\" size=\"2\">\n        <ion-item lines=\"none\">\n          <ion-label>\n            {{request.phoneNo}}\n            </ion-label>\n            </ion-item>\n          </ion-col>\n      <ion-col style=\"padding: 0px\" size=\"1.5\">\n        <ion-item lines=\"none\">\n          <ion-label>\n            {{request.DOJ | date:'dd MMM, yyyy'}}\n          </ion-label>\n          </ion-item>\n          </ion-col>\n      <!-- <ion-col style=\"padding: 0px;text-align: center;\" size=\"0.5\">\n        <ion-button style=\"text-align: center;\" size=\"small\" fill=\"clear\"\n          color=\"primary\">\n          <ion-icon slot=\"icon-only\" name=\"create-outline\"></ion-icon>\n        </ion-button>\n      </ion-col> -->\n    </ion-row>\n  </ion-grid>\n  <!-- <ion-infinite-scroll>\n    <ion-infinite-scroll-content loadingSpinner=\"bubbles\" loadingText=\"Loading more data...\">\n    </ion-infinite-scroll-content>\n  </ion-infinite-scroll> -->\n</ion-content>\n<!-- <ion-footer>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"showModal()\" fill=\"outline\" color=\"dark\" expand=\"block\" style=\"font-weight: 300;width: 80px;\">\n        Import\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-footer> -->\n\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_employee-list_employee-list_module_ts.js.map