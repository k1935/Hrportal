"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_view-all-dsr_view-all-dsr_module_ts"],{

/***/ 6940:
/*!*******************************************************************!*\
  !*** ./src/app/pages/view-all-dsr/view-all-dsr-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ViewAllDsrPageRoutingModule": () => (/* binding */ ViewAllDsrPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _view_all_dsr_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./view-all-dsr.page */ 9657);




const routes = [
    {
        path: '',
        component: _view_all_dsr_page__WEBPACK_IMPORTED_MODULE_0__.ViewAllDsrPage
    }
];
let ViewAllDsrPageRoutingModule = class ViewAllDsrPageRoutingModule {
};
ViewAllDsrPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ViewAllDsrPageRoutingModule);



/***/ }),

/***/ 8689:
/*!***********************************************************!*\
  !*** ./src/app/pages/view-all-dsr/view-all-dsr.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ViewAllDsrPageModule": () => (/* binding */ ViewAllDsrPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _view_all_dsr_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./view-all-dsr-routing.module */ 6940);
/* harmony import */ var _view_all_dsr_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./view-all-dsr.page */ 9657);







let ViewAllDsrPageModule = class ViewAllDsrPageModule {
};
ViewAllDsrPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _view_all_dsr_routing_module__WEBPACK_IMPORTED_MODULE_0__.ViewAllDsrPageRoutingModule
        ],
        declarations: [_view_all_dsr_page__WEBPACK_IMPORTED_MODULE_1__.ViewAllDsrPage]
    })
], ViewAllDsrPageModule);



/***/ }),

/***/ 9657:
/*!*********************************************************!*\
  !*** ./src/app/pages/view-all-dsr/view-all-dsr.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ViewAllDsrPage": () => (/* binding */ ViewAllDsrPage)
/* harmony export */ });
/* harmony import */ var _Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _view_all_dsr_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./view-all-dsr.page.html?ngResource */ 8216);
/* harmony import */ var _view_all_dsr_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./view-all-dsr.page.scss?ngResource */ 6594);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/common.service */ 5620);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_tasks_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/tasks.service */ 2632);
/* harmony import */ var _services_project_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/project.service */ 354);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/auth.service */ 7556);
/* harmony import */ var _pages_dsr_monthly_preview_dsr_monthly_preview_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../pages/dsr-monthly-preview/dsr-monthly-preview.page */ 310);











let ViewAllDsrPage = class ViewAllDsrPage {
  constructor(authService, tasksService, projectService, commonService, modalCtrl) {
    this.authService = authService;
    this.tasksService = tasksService;
    this.projectService = projectService;
    this.commonService = commonService;
    this.modalCtrl = modalCtrl;
    this.status = "0";
    this.dsrEmployees = [];
    this.employees = [];
    this.teams = [];
    this.teamEmployees = [];
    this.selectedStatuses = [0];
    this.permissionViewAllDSR = false;
    this.isReportingManager = false;
  }

  ngOnInit() {
    this.toDate = this.commonService.formatDate(new Date());
    this.fromDate = this.commonService.formatDate(new Date());
    this.authService.userLogin.subscribe(resp => {
      if (resp && Object.keys(resp).length > 0) {
        this.permissionViewAllDSR = resp.permissions.ViewAllDSR;
        this.commonService.fetchAllTeams().then(resp => {
          this.teams = resp;
          this.selectedTeam = resp[0].teamId;
          this.teamEmployees = resp[0].users;
          this.getDSR(resp[0].users);
        });
      }
    });
  }

  teamChanged(event) {
    let selectedTeams = this.teams.filter(t => this.selectedTeam.indexOf(t.teamId) != -1);
    let employees = [];
    selectedTeams.forEach(team => {
      employees = employees.concat(team.users);
    });
    employees = employees.filter((item, index) => {
      return employees.indexOf(item) == index;
    });
    this.teamEmployees = employees;
    this.getDSR(employees);
  }

  statusChanged(event) {
    this.selectedStatuses = event;
    this.getDSR(this.teamEmployees);
  }

  getDSR(employees) {
    this.commonService.getDSR({
      statuses: this.selectedStatuses,
      employeeId: employees,
      from: this.fromDate,
      to: this.toDate
    }).then(dsrs => {
      let dsrArray = [];
      dsrs.forEach(dsr => {
        dsrArray.push(dsr.details);
      });
      this.dsrEmployees = dsrArray;
    });
  } // async openCalendar() {
  //   const options: CalendarModalOptions = {
  //     pickMode: 'range',
  //     title: 'RANGE',
  //     color:'dark'
  //   };
  //   const myCalendar = await this.modalCtrl.create({
  //     component: CalendarModal,
  //     componentProps: { options }
  //   });
  //   myCalendar.present();
  //   const event: any = await myCalendar.onDidDismiss();
  //   const date = event.data;
  //   const from: CalendarResult = date.from;
  //   const to: CalendarResult = date.to;
  //   console.log(date, from, to);
  //   this.date = from.string +" - "+to.string
  // }


  parseFloat(number) {
    return parseFloat(number).toFixed(2);
  }

  acceptTask(task) {
    task.status = 1;
    this.tasksService.updateTask(task).then(resp => {});
  }

  dateChange(ev) {
    let that = this;
    setTimeout(() => {
      that.getDSR(this.teamEmployees);
    }, 500);
  }

  rejectTask(task) {
    task.status = 2;
    this.tasksService.updateTask(task).then(resp => {});
  }

  downloadDSR() {
    this.authService.apiUrl;
    let url = this.authService.apiUrl + "downloadDsr?employeeIds=9&from=2022-09-01&to=2022-09-30";
    window.location.assign(url); // this.tasksService.downloadDSR(task).then(resp => {
    // })
  }

  previewFilterDSR() {
    var _this = this;

    return (0,_Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const popover = yield _this.modalCtrl.create({
        component: _pages_dsr_monthly_preview_dsr_monthly_preview_page__WEBPACK_IMPORTED_MODULE_7__.DsrMonthlyPreviewPage,
        cssClass: 'dsr-preview-modal',
        //    enterAnimation(baseEl) {
        //     const wrapperAnimation = createAnimation()
        //     .beforeStyles({
        //       transform: 'translateY(0) scale(1)'
        //     })
        //     .addElement(baseEl.shadowRoot.querySelector('.modal-wrapper'));
        //   return createAnimation()
        //     .addElement(baseEl)
        //     .duration(250)
        //     .fromTo('opacity', '0', '1')
        //     .addAnimation([wrapperAnimation]);
        // },
        showBackdrop: true
      });
      yield popover.present();
    })();
  }

};

ViewAllDsrPage.ctorParameters = () => [{
  type: _services_auth_service__WEBPACK_IMPORTED_MODULE_6__.AuthService
}, {
  type: _services_tasks_service__WEBPACK_IMPORTED_MODULE_4__.TasksService
}, {
  type: _services_project_service__WEBPACK_IMPORTED_MODULE_5__.ProjectService
}, {
  type: _services_common_service__WEBPACK_IMPORTED_MODULE_3__.CommonService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ModalController
}];

ViewAllDsrPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
  selector: 'app-view-all-dsr',
  template: _view_all_dsr_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_view_all_dsr_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], ViewAllDsrPage);


/***/ }),

/***/ 6594:
/*!**********************************************************************!*\
  !*** ./src/app/pages/view-all-dsr/view-all-dsr.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ2aWV3LWFsbC1kc3IucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 8216:
/*!**********************************************************************!*\
  !*** ./src/app/pages/view-all-dsr/view-all-dsr.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar color=\"gray\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>View All DSRs</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n<div style=\"padding: 20px;\">\n  <!-- <ion-toolbar color=\"gray\">\n      <ion-title>Daily Status Reports</ion-title>\n    </ion-toolbar> -->\n  <ion-toolbar color=\"gray\">\n    <ion-searchbar placeholder=\"Search Employee\"></ion-searchbar>\n  </ion-toolbar>\n  <ion-toolbar color=\"gray\" style=\"border-top: 0px solid #3f4040;border-bottom: 0px solid #3f4040;\">\n    <ion-row>\n      <ion-col size=\"2\" style=\"border-right: 1px solid rgb(37 38 40);\n        background-color: transparent;\n        padding: 0px;\">\n        <ion-item lines=\"none\">\n          <ion-select placeholder=\"Select team\" [(ngModel)]=\"status\" (ngModelChange)=\"statusChanged($event)\" style=\"color: #fff;width: 100%;\" multiple>\n            <!-- <ion-select-option style=\"color: #fff;font-weight: bold;\" value=\"1\">All Teams</ion-select-option> -->\n            <ion-select-option style=\"color: #fff;font-weight: bold;\" value=\"0\">New</ion-select-option>\n            <ion-select-option style=\"color: #fff;font-weight: bold;\" value=\"1\">Accepted</ion-select-option>\n            <ion-select-option style=\"color: #fff;font-weight: bold;\" value=\"2\">Rejected</ion-select-option>\n          </ion-select>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"4\" style=\"border-right: 1px solid rgb(37 38 40);\n        background-color: transparent;\n        padding: 0px;\">\n        <ion-item lines=\"none\">\n          <ion-select placeholder=\"Select team\" [(ngModel)]=\"selectedTeam\" (ngModelChange)=\"teamChanged($event)\"\n            style=\"color: #fff;width: 100%;\" multiple>\n            <ion-select-option *ngFor=\"let team of teams\" style=\"color: #fff;font-weight: bold;\" [value]=\"team.teamId\">\n              {{team.teamName}}</ion-select-option>\n          </ion-select>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"1\" style=\"border-right: 1px solid rgb(37 38 40);\n        background-color: transparent;\n        padding: 0px;\">\n        <ion-item lines=\"none\">\n          <ion-button fill=\"clear\" color=\"dark\" expand=\"block\" (click)=\"previewFilterDSR()\">\n            <ion-icon slot=\"start\" name=\"calendar-outline\"></ion-icon>\n            <ion-label>Preview</ion-label>\n          </ion-button>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"1\" style=\"border-right: 1px solid rgb(37 38 40);\n        background-color: transparent;\n        padding: 0px;\">\n        <ion-item lines=\"none\">\n          <ion-button fill=\"clear\" color=\"dark\" expand=\"block\" (click)=\"downloadDSR()\">\n            <ion-icon slot=\"start\" name=\"download-outline\"></ion-icon>\n          </ion-button>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"1.5\" style=\"border: 0px solid rgb(37 38 40);\n        background-color: transparent;\n        padding: 0px;\">\n        <ion-item lines=\"none\">\n          <!-- <ion-button (click)=\"openCalendar()\" expand=\"block\" fill=\"clear\" color=\"light\">\n              {{date}}\n            </ion-button> -->\n          <ion-input [(ngModel)]=\"toDate\" (change)=\"dateChange($event)\" type=\"date\"\n            style=\"color: #ccc;font-weight: bold;\">\n          </ion-input>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"1\" style=\"text-align: center;line-height: 34px;\">\n        <div>\n          to\n        </div>\n      </ion-col>\n      <ion-col size=\"1.5\" style=\"border: 0px solid rgb(37 38 40);\n        background-color: transparent;\n        padding: 0px;\">\n        <ion-item lines=\"none\">\n          <!-- <ion-button (click)=\"openCalendar()\" expand=\"block\" fill=\"clear\" color=\"light\">\n              {{date}}\n            </ion-button> -->\n          <ion-input [(ngModel)]=\"fromDate\" (change)=\"dateChange($event)\" type=\"date\"\n            style=\"color: #ccc;font-weight: bold;\">\n          </ion-input>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n  </ion-toolbar>\n\n  <ion-accordion-group *ngFor=\"let employee of dsrEmployees\" value=\"first\" style=\"margin-bottom: 5px;\">\n    <ion-accordion value=\"first\" style=\"border: 1px solid #494a4a !important;\">\n      <ion-item slot=\"header\" lines=\"none\">\n        <ion-avatar slot=\"start\">\n          <img\n            src=\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRFMEVXuFb_tRXt584wK0LUfXhUWC5XkZyvyHV5LZBi4xzkbd4RNT_gSxr_337y8fZUccw&usqp=CAU\">\n        </ion-avatar>\n        <!-- <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373;\" slot=\"start\" name=\"close-circle-outline\"></ion-icon> -->\n        <!-- <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon> -->\n        <ion-label style=\"font-size: 18px !important;\">{{employee.firstName}} {{employee.lastName}}</ion-label>\n      </ion-item>\n      <div class=\"ion-padding\" slot=\"content\" class=\"expandedDSR\">\n        <ion-item lines=\"none\" class=\"ion-text-wrap\" *ngFor=\"let task of employee.task;let i = index;\">\n          <ion-note slot=\"start\" style=\"font-weight: 300;font-size: 12px;\">\n            {{i+1}}\n          </ion-note>\n          <ion-button slot=\"start\" (click)=\"rejectTask(task)\" fill=\"clear\" [disabled]=\"!isReportingManager\" style=\"padding: 0px;text-align:center;font-size: 16px;margin: 0px;\">\n            <ion-icon [color]=\"task.status == 2 ? \n              'danger' : 'dark'\" name=\"close-circle-outline\" slot=\"icon-only\"></ion-icon>\n          </ion-button>\n          <ion-button slot=\"start\" (click)=\"acceptTask(task)\" fill=\"clear\" [disabled]=\"!isReportingManager\" style=\"padding: 0px;text-align:center;font-size: 16px;margin: 0px;\">\n            <ion-icon [color]=\"task.status == 1 ? \n            'success' : 'dark'\" name=\"checkmark-circle-outline\" slot=\"icon-only\"></ion-icon>\n          </ion-button>\n          <ion-label class=\"ion-text-wrap\">{{task.taskName}}</ion-label>\n          <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;text-align: right;\">\n            SpotYourDeal <br> {{parseFloat(task.hours)}} hrs\n          </ion-note>\n          <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;\">\n            {{task.from | date:'HH:mm a'}} - {{task.to | date:'HH:mm a'}} <br> {{task.date | date:'dd MMM, yyyy'}}\n          </ion-note>\n        </ion-item>\n        <!-- <ion-item lines=\"none\">\n            <ion-note slot=\"start\" style=\"font-weight: 300;font-size: 12px;\">\n              2\n            </ion-note>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;\" slot=\"start\" name=\"close-circle-outline\"></ion-icon>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon>\n            <ion-label>Chat message date not showing</ion-label>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;text-align: right;\">\n              iDMX <br> 2 hrs\n            </ion-note>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;\">\n              1:30 PM - 4:30 PM <br> 2 Aug, 2022\n            </ion-note>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-note slot=\"start\" style=\"font-weight: 300;font-size: 12px;\">\n              3\n            </ion-note>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373;\" slot=\"start\" name=\"close-circle-outline\"></ion-icon>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon>\n            <ion-label>Feeds page not scrolling back to top when segment change</ion-label>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;text-align: right;\">\n              Hr Portal <br> 2 hrs\n            </ion-note>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;\">\n              1:30 PM - 4:30 PM <br> 2 Aug, 2022\n            </ion-note>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-note slot=\"start\" style=\"font-weight: 300;font-size: 12px;\">\n              4\n            </ion-note>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373;\" slot=\"start\" name=\"close-circle-outline\"></ion-icon>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon>\n            <ion-label>User chat not opening on receiving chat notification</ion-label>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;text-align: right;\">\n              SpotYourDeal <br> 2 hrs\n            </ion-note>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;\">\n              1:30 PM - 4:30 PM <br> 2 Aug, 2022\n            </ion-note>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-note slot=\"start\" style=\"font-weight: 300;font-size: 12px;\">\n              5\n            </ion-note>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373;\" slot=\"start\" name=\"close-circle-outline\"></ion-icon>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon>\n            <ion-label>Remove possible duplicate users</ion-label>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;text-align: right;\">\n              SpotYourDeal <br> 2 hrs\n            </ion-note>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;\">\n              1:30 PM - 4:30 PM <br> 2 Aug, 2022\n            </ion-note>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-note slot=\"start\" style=\"font-weight: 300;font-size: 12px;\">\n              6\n            </ion-note>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373;\" slot=\"start\" name=\"close-circle-outline\"></ion-icon>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon>\n            <ion-label>Blocked users cannot send message from anywhere</ion-label>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;text-align: right;\">\n              SpotYourDeal <br> 2 hrs\n            </ion-note>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;\">\n              1:30 PM - 4:30 PM <br> 2 Aug, 2022\n            </ion-note>\n          </ion-item> -->\n      </div>\n    </ion-accordion>\n  </ion-accordion-group>\n</div>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_view-all-dsr_view-all-dsr_module_ts.js.map