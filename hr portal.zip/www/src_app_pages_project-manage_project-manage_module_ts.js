"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_project-manage_project-manage_module_ts"],{

/***/ 9409:
/*!***********************************************************************!*\
  !*** ./src/app/pages/project-manage/project-manage-routing.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProjectManagePageRoutingModule": () => (/* binding */ ProjectManagePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _project_manage_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./project-manage.page */ 8364);




const routes = [
    {
        path: '',
        component: _project_manage_page__WEBPACK_IMPORTED_MODULE_0__.ProjectManagePage
    }
];
let ProjectManagePageRoutingModule = class ProjectManagePageRoutingModule {
};
ProjectManagePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ProjectManagePageRoutingModule);



/***/ }),

/***/ 7405:
/*!***************************************************************!*\
  !*** ./src/app/pages/project-manage/project-manage.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProjectManagePageModule": () => (/* binding */ ProjectManagePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _project_manage_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./project-manage-routing.module */ 9409);
/* harmony import */ var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/cdk/drag-drop */ 7727);
/* harmony import */ var _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/cdk/overlay */ 5895);
/* harmony import */ var _project_manage_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./project-manage.page */ 8364);
/* harmony import */ var ngx_quill__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-quill */ 3115);










let ProjectManagePageModule = class ProjectManagePageModule {
};
ProjectManagePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_7__.OverlayModule,
            _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_8__.DragDropModule,
            ngx_quill__WEBPACK_IMPORTED_MODULE_9__.QuillModule,
            _project_manage_routing_module__WEBPACK_IMPORTED_MODULE_0__.ProjectManagePageRoutingModule
        ],
        declarations: [_project_manage_page__WEBPACK_IMPORTED_MODULE_1__.ProjectManagePage]
    })
], ProjectManagePageModule);



/***/ }),

/***/ 8364:
/*!*************************************************************!*\
  !*** ./src/app/pages/project-manage/project-manage.page.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProjectManagePage": () => (/* binding */ ProjectManagePage)
/* harmony export */ });
/* harmony import */ var _Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _project_manage_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./project-manage.page.html?ngResource */ 4883);
/* harmony import */ var _project_manage_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./project-manage.page.scss?ngResource */ 5178);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/cdk/drag-drop */ 7727);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/common.service */ 5620);
/* harmony import */ var _services_project_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/project.service */ 354);
/* harmony import */ var _services_tasks_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/tasks.service */ 2632);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/auth.service */ 7556);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _modals_project_task_details_project_task_details_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../modals/project-task-details/project-task-details.page */ 9357);
/* harmony import */ var _modals_project_epic_details_project_epic_details_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../modals/project-epic-details/project-epic-details.page */ 2715);
/* harmony import */ var _modals_project_story_details_project_story_details_page__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../modals/project-story-details/project-story-details.page */ 1461);
/* harmony import */ var frappe_gantt__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! frappe-gantt */ 7871);
/* harmony import */ var quill_mention__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! quill-mention */ 5367);

















let ProjectManagePage = class ProjectManagePage {
  constructor(router, tasksService, menuController, modalController, activated, authService, projectService, alertController, commonService) {
    this.router = router;
    this.tasksService = tasksService;
    this.menuController = menuController;
    this.modalController = modalController;
    this.activated = activated;
    this.authService = authService;
    this.projectService = projectService;
    this.alertController = alertController;
    this.commonService = commonService;
    this.projectId = 0;
    this.ganttWidth = 0;
    this.selectedEpicIndex = 0;
    this.selectedStoryIndex = 0;
    this.selectedEpic = {};
    this.selectedStory = 0;
    this.ganttMode = 'Day';
    this.isOpen = false;
    this.atValues = [{
      id: 1,
      value: 'Fredrik Sundqvist'
    }, {
      id: 2,
      value: 'Patrik Sjölin'
    }];
    this.hashValues = [{
      id: 3,
      value: 'Fredrik Sundqvist 2'
    }, {
      id: 4,
      value: 'Patrik Sjölin 2'
    }];
    this.quillConfig = {
      //toolbar: '.toolbar',
      toolbar: {
        container: [['bold', 'italic', 'underline', 'strike'], ['code-block'], [{
          'header': 1
        }, {
          'header': 2
        }], [{
          'list': 'ordered'
        }, {
          'list': 'bullet'
        }, {
          'color': ['#000000', '#e60000', '#ff9900', '#ffff00', '#008a00', '#0066cc', '#9933ff', '#ffffff', '#facccc', '#ffebcc', '#ffffcc', '#cce8cc', '#cce0f5', '#ebd6ff', '#bbbbbb', '#f06666', '#ffc266', '#ffff66', '#66b966', '#66a3e0', '#c285ff', '#888888', '#a10000', '#b26b00', '#b2b200', '#006100', '#0047b2', '#6b24b2', '#444444', '#5c0000', '#663d00', '#666600', '#003700', '#002966', '#3d1466', 'custom-color']
        }, {
          'background': []
        }, 'link', 'emoji'], [{
          'script': 'sub'
        }, {
          'script': 'super'
        }], [{
          'indent': '-1'
        }, {
          'indent': '+1'
        }], [{
          'direction': 'rtl'
        }], [{
          'size': ['small', false, 'large', 'huge']
        }], [{
          'header': [1, 2, 3, 4, 5, 6, false]
        }], [{
          'font': []
        }], [{
          'align': []
        }], ['clean'], ['link'] // ['link', 'image', 'video']  
        ]
      },
      mention: {
        allowedChars: /^[A-Za-z\sÅÄÖåäö]*$/,
        mentionDenotationChars: ["@", "#"],
        source: (searchTerm, renderList, mentionChar) => {
          let values;

          if (mentionChar === "@") {
            values = this.atValues;
          } else {
            values = this.hashValues;
          }

          if (searchTerm.length === 0) {
            renderList(values, searchTerm);
          } else {
            const matches = [];

            for (var i = 0; i < values.length; i++) if (~values[i].value.toLowerCase().indexOf(searchTerm.toLowerCase())) matches.push(values[i]);

            renderList(matches, searchTerm);
          }
        }
      },
      "emoji-toolbar": false,
      "emoji-textarea": false,
      "emoji-shortname": false,
      keyboard: {
        bindings: {
          shiftEnter: {
            key: 13,
            shiftKey: true,
            handler: (range, context) => {// Handle shift+enter
              // console.log("shift+enter")
            }
          },
          enter: {
            key: 13,
            handler: (range, context) => {
              console.log("enter");
              return true;
            }
          }
        }
      }
    };
    this.segment = 'roadmap';
    this.epics = [];
    this.windowHeight = 0;
    this.projectEpics = [{
      id: 'sample',
      name: 'Sample Epic',
      start: this.commonService.formatDate(new Date()),
      end: this.commonService.formatDate(new Date()),
      progress: 0
    }];
    this.epicStories = [];
    this.epicStoriesArray = [];
    this.storyTasks = [];
    this.projectEpicsTest = [{
      id: 'Task 1',
      name: 'Sample Epic',
      start: this.commonService.formatDate(new Date()),
      end: this.commonService.formatDate(new Date()),
      progress: 0
    }];
    this.toggleMenu = true;
    this.teamBoardColumns = [];
    this.connectedTo = [];
    this.projectMembers = [];
  }

  logScrolling(ev) {// this.top = ev.detail.scrollTop;
    // console.log("logScrolling")
  }

  toggleMenuButton() {
    this.toggleMenu = !this.toggleMenu;
    this.menuController.enable(this.toggleMenu);
  }

  ngOnInit() {
    let that = this;
    this.projectId = this.activated.snapshot.params.id; // this.projectService.getProjectColumns({ projectId: this.projectId }).then((columns: any) => {
    //   columns.forEach(c => {
    //     c.tasks = []
    //     this.connectedTo.push("box" + c.columnId);
    //     // this.getTasks(c);
    //   })
    //   this.teamBoardColumns = columns;
    // })
    // console.log("window height ", window.innerHeight)

    this.windowHeight = window.innerHeight - 90 + 'px';
    this.gantt = new frappe_gantt__WEBPACK_IMPORTED_MODULE_10__["default"]("#gantt", this.projectEpics, {
      header_height: 50,
      column_width: 30,
      step: 24,
      view_mode: 'Day',
      view_modes: ['Quarter Day', 'Half Day', 'Day', 'Week', 'Month', 'Year'],
      bar_height: 30,
      bar_corner_radius: 3,
      arrow_curve: 5,
      padding: 20,
      date_format: 'YYYY-MM-DD',
      custom_popup_html: null,
      draggable: true,
      on_click: function (task) {// console.log(task);
      },
      on_drag: function (task) {
        // console.log(task);
        let taskObj = Object.assign(task);
        taskObj.id = parseInt(task.id.replace('epic', ''));
        that.projectService.updateProjectEpic(taskObj);
      },
      on_date_change: function (task, start, end) {
        // console.log(task);
        let taskObj = Object.assign(task);
        taskObj.start = that.commonService.formatDate(start);
        taskObj.end = that.commonService.formatDate(end);
        taskObj.id = parseInt(task.id.replace('epic', ''));
        that.projectService.updateProjectEpic(taskObj);
      },
      on_progress_change: function (task, progress) {// console.log(task, progress);
      },
      on_view_change: function (mode) {// console.log(mode);
      }
    });
    this.authService.userLogin.subscribe(resp => {
      if (resp && Object.keys(resp).length > 0) {
        console.log("userLogin resp ", resp);
        this.commonService.presentLoading();
        this.projectService.getProjectMembers({
          projectId: this.projectId
        }).then(members => {
          console.log("project members ", members);
          this.commonService.loadingDismiss();
          this.projectMembers = members; // this.selectedTeam = resp[0].teamId;
          // this.tasksService.fetchTeamColumns(this.selectedTeam).then((columns:any) => {
          //   columns.forEach(c => {
          //     c.tasks = []
          //     this.connectedTo.push("box" + c.columnId);
          //     this.getTasks(c);
          //   })
          //   this.teamBoardColumns = columns;
          // })
          // this.projectService.getMemberProjects().then(resp => {
          //   this.memberProjects = resp;
          // })
          // this.tasksService.filterDsr({month: month+1}).then( resp => {
          //   console.log("resp filterDsr ",resp);
          // })
        });
      }
    });
    this.projectService.getProjectColumns({
      projectId: this.projectId
    }).then(columns => {
      columns.forEach(c => {
        c.tasks = [];
        this.connectedTo.push("box" + c.columnId); // this.getTasks(c);
      });
      this.teamBoardColumns = columns; // this.selectEpic(that.selectedEpic, 0);
    });
    this.projectService.getProjectEpics({
      projectId: this.projectId
    }).then(epics => {
      if (epics.length > 0) {
        epics.forEach(epic => {
          epic.id = "epic" + epic.id;
          delete epic.projectId;
        });
        let epicsData = [];

        for (var i = 0; i < 20; i++) {
          epicsData.push({
            id: 'Task ' + i,
            name: 'Redesign website',
            start: '2022-09-18',
            end: '2022-09-30',
            progress: 20
          });
        } // this.projectEpics = epicsData;


        this.projectEpics = epics;
        that.selectedEpic = that.projectEpics[0];
        that.selectEpic(that.selectedEpic, 0); // this.projectService.getProjectColumns({ projectId: this.projectId }).then((columns: any) => {
        //   columns.forEach(c => {
        //     c.tasks = []
        //     this.connectedTo.push("box" + c.columnId);
        //     // this.getTasks(c);
        //   })
        //   this.teamBoardColumns = columns;
        //   this.selectEpic(that.selectedEpic, 0);
        // })
        // console.log("this.projectEpics getProjectEpics ", this.projectEpics)

        this.gantt.refresh(this.projectEpics);
      }
    });
    const myTimeout = setTimeout(myStopFunction, 200); // let topScroller = document.getElementById('topScroller');
    // topScroller.addEventListener('scroll', el => {
    //   console.log("addEventListener topScroller " + window.scrollX);
    //   // setTimeout(() => {
    //   //   console.log("setTimeout topScroller " + window.scrollX);
    //   // }, 1000);
    // })

    var userSelection = document.getElementsByClassName('gantt-container');
    userSelection[0].addEventListener('scroll', el => {
      // console.log("userSelection getElementsByClassName ");
      let topScroller = document.getElementById('topScroller');
      topScroller.scrollLeft = userSelection[0].scrollLeft;
    });
    let topScroller = document.getElementById('topScroller');
    topScroller.addEventListener('scroll', el => {
      var userSelection = document.getElementsByClassName('gantt-container');
      userSelection[0].scrollLeft = topScroller.scrollLeft;
    });

    function myStopFunction() {
      var userSelection = document.getElementsByClassName('gantt-container'); // var gant = document.getElementById('gantt');

      userSelection[0].classList.add('ganttTest');
      let sl = userSelection[0].scrollLeft,
          cw = userSelection[0].scrollWidth; // console.log("sl " + sl);
      // console.log("cw " + cw);

      that.ganttWidth = cw;
      userSelection[0].scrollLeft = cw / 4; // let topScroller = document.getElementById('topScroller');
      // topScroller.addEventListener('scroll', el => {
      //   var userSelection = document.getElementsByClassName('gantt-container');
      //   userSelection[0].scrollLeft = topScroller.scrollLeft;
      // })
      // topScroller.scrollLeft = userSelection[0].scrollLeft
      // let x = gant.scrollLeft = 999999999999;
      // console.log("userSelection[0].scrollWidth x " + x);
      // gant.addEventListener("scroll", function() {
      //      console.log("Clicked index: " + 0);
      //    })

      clearTimeout(myTimeout);
    } // var innerContent = $('.demo > div');
    // outerContent.scrollLeft = 100
    // {
    //   header_height: 50,
    //   column_width: 30,
    //   step: 24,
    //   bar_height: 20,
    //   bar_corner_radius: 3,
    //   arrow_curve: 5,
    //   padding: 18,
    //   view_mode: 'Day',
    //   date_format: 'YYYY-MM-DD',
    //   popup_trigger: 'click',
    //   custom_popup_html: null,
    //   language: 'en'
    // }

  }

  selectEpic(epic, index) {
    var _this = this;

    this.selectedEpicIndex = index;
    this.selectedEpic = epic;
    let c = 0;
    this.projectService.getEpicStories({
      epicId: this.selectedEpic.id.replace('epic', '')
    }).then(stories => {
      this.epicStories = stories;

      if (c == 0) {
        this.selectedStoryIndex = 0;
        this.selectedStory = this.epicStories[this.selectedStoryIndex];
      }

      if (stories.length == 0) {
        this.storyTasks = [];
      }

      this.epicStories.forEach((story, i) => {
        story.columnTasks = JSON.parse(JSON.stringify(this.teamBoardColumns));
        this.projectService.getStoryTasks({
          storyId: story.id
        }).then( /*#__PURE__*/function () {
          var _ref = (0,_Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (tasksData) {
            story.tasks = tasksData;

            if (i == 0) {
              c = 1;
              _this.storyTasks = tasksData;
            }

            story.columnTasks.forEach((column, j) => {
              let filteredTasks = tasksData.filter(t => t.columnId == column.columnId && t.storyId == story.id);

              if (filteredTasks.length > 0) {
                column.tasks = filteredTasks;
              }
            });
            _this.epicStoriesArray = Object.assign(_this.epicStories, {});
            console.log("this.epicStoriesArray ", _this.epicStoriesArray);
          });

          return function (_x) {
            return _ref.apply(this, arguments);
          };
        }());
      });
    });
  }

  selectStory(story, index) {
    this.selectedStoryIndex = index;
    this.selectedStory = story;
    this.storyTasks = story.tasks || [];
  }

  addTask() {
    let newTask = {
      taskName: "",
      projectId: 0
    }; // this.teamBoardColumns[0].tasks.unshift(newTask);
    // this.editTask(newTask, 0, 0);
    // console.log("addTask  ");
  }

  onBlur(event, item, c, i) {
    item['edit'] = false;

    if (item.name == '') {
      this.teamBoardColumns[c].tasks.splice(i, 1);
    } else {}

    item.focus = false;
  }

  taskNameUpdated(ev, item, c, i) {
    item['taskName'] = ev.target.value; // console.log("taskNameUpdated  ");/

    if (item.taskId) {// this.updateTask(item);
    } else {
      // item.teamId = this.selectedTeam;
      // item.date = this.taskDate;
      // item.columnId = this.teamBoardColumns[c].columnId
      this.tasksService.createTask(item).then(resp => {
        item.taskId = resp.taskId;
      });
    }
  }

  drop(event) {
    var _this2 = this;

    return (0,_Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // console.log("CdkDragDrop event", event)
      if (event.previousContainer === event.container) {
        (0,_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_12__.moveItemInArray)(event.container.data, event.previousIndex, event.currentIndex);
        event.container.data.forEach((task, index) => {
          task.order = index;

          _this2.updateTask(task);
        });
      } else {
        (0,_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_12__.transferArrayItem)(event.previousContainer.data, event.container.data, event.previousIndex, event.currentIndex); // console.log("CdkDragDrop event.container.id", event.container.id)
        // console.log("CdkDragDrop event.previousIndex", event.previousIndex)
        // console.log("CdkDragDrop event.currentIndex", event.currentIndex)
        // console.log("CdkDragDrop event.container.data", event.container.data)

        event.container.data.forEach((task, index) => {
          task.order = index;
          task.columnId = event.container.id;

          _this2.updateTask(task);
        });
      }
    })();
  }

  updateTask(task) {
    this.projectService.updateProjectTask(task).then(resp => {});
  }

  updateEpic(epic) {
    this.projectService.updateProjectEpic(epic).then(resp => {
      this.gantt.refresh(this.projectEpics);
    });
  }

  updateStory(story) {
    this.projectService.updateEpicStory(story).then(resp => {});
  }

  assignTaskOverlay(item, i) {
    item.isOpen = !item.isOpen;
    item.index = i;
  }

  assignTask(item, user) {
    item.assignee = user.employeeId;
    item.firstName = user.firstName;
    item.lastName = user.lastName;
    item.image = user.image;
    item.isOpen = !item.isOpen;
    this.updateTask(item);
  }

  getAssigneeDetails(item, data) {
    let user = this.projectMembers.filter(e => e.employeeId == item.assignee);
    if (user.length > 0) return user[0][data] || '';else return '';
  }

  updateTaskStatus(item) {
    item.status = !item.status;
    this.updateTask(item);
  }

  selectMemberTasks(member) {
    member.selected = !member.selected;
    let selectedMembers = this.projectMembers.filter(m => m.selected == true); // console.log("selectedMembers ", selectedMembers)

    let members = [];
    selectedMembers.forEach(m => {
      members.push(m.employeeId);
    }); // let filteredStories = this.epicStoriesArray.map((element) => {
    //   return {...element, tasks: element.tasks.filter((subElement) => members.indexOf(subElement.assignee) > -1)}
    // })

    var filteredArray = this.epicStoriesArray.filter(element => element.tasks.some(subElement => members.indexOf(subElement.assignee) > -1)).map(element => {
      let n = Object.assign({}, element, {
        'tasks': element.tasks.filter(subElement => members.indexOf(subElement.assignee) > -1)
      });
      return n;
    });
    if (members.length > 0) this.epicStories = filteredArray;else this.epicStories = this.epicStoriesArray; // console.log(filteredArray)
    // console.log("filteredStories ", filteredStories)
  }

  addEpic() {
    var _this3 = this;

    return (0,_Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let date = _this3.commonService.formatDate(new Date());

      let that = _this3;
      const alert = yield _this3.alertController.create({
        header: 'Enter epic details!',
        inputs: [{
          name: 'epicName',
          type: 'text',
          placeholder: 'Epic name'
        }, {
          name: 'epicStartDate',
          value: date,
          type: 'date',
          placeholder: 'Start Date'
        }, {
          name: 'epicStopDate',
          value: date,
          type: 'date',
          placeholder: 'Start Date'
        }],
        buttons: [{
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Add',
          handler: epicData => {
            let epic = {};
            epic['name'] = epicData.epicName;
            epic['start'] = epicData.epicStartDate;
            epic['end'] = epicData.epicStopDate;
            epic['progress'] = 0;
            epic['reporter'] = _this3.authService.userId;
            epic['projectId'] = _this3.projectId;

            _this3.projectService.createEpic(epic).then(resp => {
              epic['id'] = "epic" + resp.id;

              if (that.projectEpics[0].id == 'sample') {
                that.projectEpics = [epic];
                that.selectedEpic = epic;
              } else {
                that.projectEpics.push(epic);
              }

              that.gantt.refresh(that.projectEpics); // console.log("that.projectEpics ", that.projectEpics)
            });
          }
        }]
      });
      yield alert.present();
    })();
  }

  addStory() {
    var _this4 = this;

    return (0,_Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let date = _this4.commonService.formatDate(new Date());

      let that = _this4;
      const alert = yield _this4.alertController.create({
        header: 'Enter story details!',
        inputs: [{
          name: 'storyName',
          type: 'textarea',
          placeholder: 'Story name'
        } // {
        //   label: 'Start Date',
        //   name: 'storyStartDate',
        //   value: date,
        //   type: 'date',
        //   placeholder: 'Start Date'
        // },
        // {
        //   label: 'End Date',
        //   name: 'epicStopDate',
        //   value: date,
        //   type: 'date',
        //   placeholder: 'Start Date'
        // }
        ],
        buttons: [{
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Add',
          handler: epicData => {
            console.log("this.selectedEpic ", _this4.selectedEpic);
            let story = {};
            story['name'] = epicData.storyName, story['progress'] = 0, story['reporter'] = _this4.authService.userId;
            story['epicId'] = _this4.selectedEpic.id.replace('epic', '');
            story['projectId'] = _this4.projectId;

            _this4.projectService.createStory(story).then(resp => {
              story['id'] = resp.id;
              that.epicStories.push(story);
              if (that.epicStories.length == 1) that.selectedStory = that.epicStories[0]; // this.gantt.refresh(that.projectEpics);
              // console.log("that.projectEpics ", that.projectEpics)
            });
          }
        }]
      });
      yield alert.present();
    })();
  }

  addStoryTask() {
    var _this5 = this;

    return (0,_Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let date = _this5.commonService.formatDate(new Date());

      let that = _this5;
      const alert = yield _this5.alertController.create({
        header: 'Enter task!',
        inputs: [{
          name: 'taskName',
          type: 'textarea',
          placeholder: 'Task name'
        }, {
          name: 'hours',
          value: date,
          type: 'number',
          placeholder: 'Estimated Hours'
        }],
        buttons: [{
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Add',
          handler: taskData => {
            let task = {};
            console.log("that.that.storyTasks ", that.storyTasks);
            task['taskName'] = taskData.taskName;
            task['order'] = that.storyTasks.length;
            task['reporter'] = _this5.authService.userId;
            task['columnId'] = _this5.teamBoardColumns[0].columnId;
            task['epicId'] = _this5.selectedEpic.id.replace('epic', '');
            task['storyId'] = _this5.selectedStory.id;
            task['projectId'] = _this5.projectId;

            _this5.projectService.createStoryTask(task).then(resp => {
              task['taskId'] = resp.taskId;
              that.storyTasks.push(task); // this.gantt.refresh(that.projectEpics);
              // console.log("that.projectEpics ", that.projectEpics)
            });
          }
        }]
      });
      yield alert.present();
    })();
  }

  viewTaskDetails(item) {
    var _this6 = this;

    return (0,_Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const popover = yield _this6.modalController.create({
        component: _modals_project_task_details_project_task_details_page__WEBPACK_IMPORTED_MODULE_7__.ProjectTaskDetailsPage,
        cssClass: 'task-details',
        componentProps: {
          item,
          projectMembers: _this6.projectMembers
        },
        showBackdrop: true
      });
      yield popover.present();
      popover.onDidDismiss().then(resp => {
        console.log("that.onDidDismiss ");

        _this6.updateTask(item);
      });
    })();
  }

  viewEpicDetails(epic) {
    var _this7 = this;

    return (0,_Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const popover = yield _this7.modalController.create({
        component: _modals_project_epic_details_project_epic_details_page__WEBPACK_IMPORTED_MODULE_8__.ProjectEpicDetailsPage,
        cssClass: 'task-details',
        componentProps: {
          epic,
          projectMembers: _this7.projectMembers
        },
        showBackdrop: true
      });
      yield popover.present();
      popover.onDidDismiss().then(resp => {
        console.log("that.onDidDismiss ");

        _this7.updateEpic(epic);
      });
    })();
  }

  viewStoryDetails(story) {
    var _this8 = this;

    return (0,_Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const popover = yield _this8.modalController.create({
        component: _modals_project_story_details_project_story_details_page__WEBPACK_IMPORTED_MODULE_9__.ProjectStoryDetailsPage,
        cssClass: 'task-details',
        componentProps: {
          story,
          projectMembers: _this8.projectMembers
        },
        showBackdrop: true
      });
      yield popover.present();
      popover.onDidDismiss().then(resp => {
        console.log("that.onDidDismiss ");

        _this8.updateStory(story);
      });
    })();
  }

  change_view_mode(mode) {
    this.gantt.change_view_mode(mode);
  }

};

ProjectManagePage.ctorParameters = () => [{
  type: _angular_router__WEBPACK_IMPORTED_MODULE_13__.Router
}, {
  type: _services_tasks_service__WEBPACK_IMPORTED_MODULE_5__.TasksService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.MenuController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.ModalController
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_13__.ActivatedRoute
}, {
  type: _services_auth_service__WEBPACK_IMPORTED_MODULE_6__.AuthService
}, {
  type: _services_project_service__WEBPACK_IMPORTED_MODULE_4__.ProjectService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.AlertController
}, {
  type: _services_common_service__WEBPACK_IMPORTED_MODULE_3__.CommonService
}];

ProjectManagePage.propDecorators = {
  ganttEl: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_15__.ViewChild,
    args: ['gantt']
  }]
};
ProjectManagePage = (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_15__.Component)({
  selector: 'app-project-manage',
  template: _project_manage_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_project_manage_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], ProjectManagePage);


/***/ }),

/***/ 354:
/*!*********************************************!*\
  !*** ./src/app/services/project.service.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProjectService": () => (/* binding */ ProjectService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth.service */ 7556);




let ProjectService = class ProjectService {
    constructor(authService, http) {
        this.authService = authService;
        this.http = http;
    }
    createProject(projectObject) {
        projectObject.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'createProject', projectObject).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateProject(projectObject) {
        projectObject.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'updateProject', projectObject).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getOneProject(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getOneProject', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getProjectMembers(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getProjectMembers', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    addProjectMember(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'addProjectMember', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    removeProjectMember(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'removeProjectMember', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateProjectMember(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'updateProjectMember', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    fetchAllProjects(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'fetchAllProjects', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getMemberProjects() {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getMemberProjects', { employeeId: this.authService.userId }).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getTeamsReporting() {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getTeamsReporting', { userId: this.authService.userId }).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    createEpic(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'createEpic', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateProjectEpic(epicData) {
        let newEpic = Object.assign(epicData);
        newEpic['id'] = newEpic.id.replace('epic', '');
        console.log("updateProjectEpic epicData ", epicData);
        console.log("updateProjectEpic newEpic ", newEpic);
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'epicUpdate', newEpic).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getProjectEpics(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getProjectEpics', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    createStory(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'createStory', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateEpicStory(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'storyUpdate', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getEpicStories(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getStories', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    createStoryTask(taskData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'createStoryTask', taskData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getStoryTasks(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getStoryTasks', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getProjectColumns(projectData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getProjectColumns', projectData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateProjectTask(task) {
        return new Promise((resolve, reject) => {
            task.organisationId = this.authService.organisationId;
            this.http.post(this.authService.apiUrl + 'updateProjectTask', task).subscribe((resp) => {
                console.log("rsp", resp);
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
};
ProjectService.ctorParameters = () => [
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
ProjectService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], ProjectService);



/***/ }),

/***/ 2632:
/*!*******************************************!*\
  !*** ./src/app/services/tasks.service.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TasksService": () => (/* binding */ TasksService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth.service */ 7556);




let TasksService = class TasksService {
    constructor(authService, http) {
        this.authService = authService;
        this.http = http;
    }
    getUserTeams() {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getUserTeams', { userId: this.authService.userId }).subscribe((resp) => {
                console.log("rsp", resp);
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    fetchTeamColumns(teamId) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'fetchTeamColumns', { teamId }).subscribe((resp) => {
                console.log("rsp", resp);
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateTask(task) {
        return new Promise((resolve, reject) => {
            task.organisationId = this.authService.organisationId;
            this.http.post(this.authService.apiUrl + 'updateTask', task).subscribe((resp) => {
                console.log("rsp", resp);
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    createTask(task) {
        return new Promise((resolve, reject) => {
            task.organisationId = this.authService.organisationId;
            task.employeeId = this.authService.userId;
            this.http.post(this.authService.apiUrl + 'createTask', task).subscribe((resp) => {
                console.log("rsp", resp);
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getUserTasks(column) {
        return new Promise((resolve, reject) => {
            column.organisationId = this.authService.organisationId;
            column.employeeId = this.authService.userId;
            this.http.post(this.authService.apiUrl + 'getUserTasks', column).subscribe((resp) => {
                // console.log("rsp",resp)
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    deleteUserTasks(column) {
        return new Promise((resolve, reject) => {
            column.organisationId = this.authService.organisationId;
            column.employeeId = this.authService.userId;
            this.http.post(this.authService.apiUrl + 'deleteTask', column).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    filterDsr(params) {
        return new Promise((resolve, reject) => {
            params.organisationId = this.authService.organisationId;
            // if(!params.employeeIds)
            // params.employeeIds = [this.authService.userId];
            // params.employeeIds = [4,9,31];
            this.http.post(this.authService.apiUrl + 'filterDsr', params).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
};
TasksService.ctorParameters = () => [
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
TasksService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], TasksService);



/***/ }),

/***/ 4045:
/*!************************************************!*\
  !*** ./node_modules/frappe-gantt/src/arrow.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Arrow)
/* harmony export */ });
/* harmony import */ var _svg_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./svg_utils */ 882);

class Arrow {
  constructor(gantt, from_task, to_task) {
    this.gantt = gantt;
    this.from_task = from_task;
    this.to_task = to_task;
    this.calculate_path();
    this.draw();
  }

  calculate_path() {
    let start_x = this.from_task.$bar.getX() + this.from_task.$bar.getWidth() / 2;

    const condition = () => this.to_task.$bar.getX() < start_x + this.gantt.options.padding && start_x > this.from_task.$bar.getX() + this.gantt.options.padding;

    while (condition()) {
      start_x -= 10;
    }

    const start_y = this.gantt.options.header_height + this.gantt.options.bar_height + (this.gantt.options.padding + this.gantt.options.bar_height) * this.from_task.task._index + this.gantt.options.padding;
    const end_x = this.to_task.$bar.getX() - this.gantt.options.padding / 2;
    const end_y = this.gantt.options.header_height + this.gantt.options.bar_height / 2 + (this.gantt.options.padding + this.gantt.options.bar_height) * this.to_task.task._index + this.gantt.options.padding;
    const from_is_below_to = this.from_task.task._index > this.to_task.task._index;
    const curve = this.gantt.options.arrow_curve;
    const clockwise = from_is_below_to ? 1 : 0;
    const curve_y = from_is_below_to ? -curve : curve;
    const offset = from_is_below_to ? end_y + this.gantt.options.arrow_curve : end_y - this.gantt.options.arrow_curve;
    this.path = `
            M ${start_x} ${start_y}
            V ${offset}
            a ${curve} ${curve} 0 0 ${clockwise} ${curve} ${curve_y}
            L ${end_x} ${end_y}
            m -5 -5
            l 5 5
            l -5 5`;

    if (this.to_task.$bar.getX() < this.from_task.$bar.getX() + this.gantt.options.padding) {
      const down_1 = this.gantt.options.padding / 2 - curve;
      const down_2 = this.to_task.$bar.getY() + this.to_task.$bar.getHeight() / 2 - curve_y;
      const left = this.to_task.$bar.getX() - this.gantt.options.padding;
      this.path = `
                M ${start_x} ${start_y}
                v ${down_1}
                a ${curve} ${curve} 0 0 1 -${curve} ${curve}
                H ${left}
                a ${curve} ${curve} 0 0 ${clockwise} -${curve} ${curve_y}
                V ${down_2}
                a ${curve} ${curve} 0 0 ${clockwise} ${curve} ${curve_y}
                L ${end_x} ${end_y}
                m -5 -5
                l 5 5
                l -5 5`;
    }
  }

  draw() {
    this.element = (0,_svg_utils__WEBPACK_IMPORTED_MODULE_0__.createSVG)('path', {
      d: this.path,
      'data-from': this.from_task.task.id,
      'data-to': this.to_task.task.id
    });
  }

  update() {
    this.calculate_path();
    this.element.setAttribute('d', this.path);
  }

}

/***/ }),

/***/ 5171:
/*!**********************************************!*\
  !*** ./node_modules/frappe-gantt/src/bar.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Bar)
/* harmony export */ });
/* harmony import */ var _date_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./date_utils */ 2280);
/* harmony import */ var _svg_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./svg_utils */ 882);


class Bar {
  constructor(gantt, task) {
    this.set_defaults(gantt, task);
    this.prepare();
    this.draw();
    this.bind();
  }

  set_defaults(gantt, task) {
    this.action_completed = false;
    this.gantt = gantt;
    this.task = task;
  }

  prepare() {
    this.prepare_values();
    this.prepare_helpers();
  }

  prepare_values() {
    this.invalid = this.task.invalid;
    this.height = this.gantt.options.bar_height;
    this.x = this.compute_x();
    this.y = this.compute_y();
    this.corner_radius = this.gantt.options.bar_corner_radius;
    this.duration = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].diff(this.task._end, this.task._start, 'hour') / this.gantt.options.step;
    this.width = this.gantt.options.column_width * this.duration;
    this.progress_width = this.gantt.options.column_width * this.duration * (this.task.progress / 100) || 0;
    this.group = (0,_svg_utils__WEBPACK_IMPORTED_MODULE_1__.createSVG)('g', {
      class: 'bar-wrapper ' + (this.task.custom_class || ''),
      'data-id': this.task.id
    });
    this.bar_group = (0,_svg_utils__WEBPACK_IMPORTED_MODULE_1__.createSVG)('g', {
      class: 'bar-group',
      append_to: this.group
    });
    this.handle_group = (0,_svg_utils__WEBPACK_IMPORTED_MODULE_1__.createSVG)('g', {
      class: 'handle-group',
      append_to: this.group
    });
  }

  prepare_helpers() {
    SVGElement.prototype.getX = function () {
      return +this.getAttribute('x');
    };

    SVGElement.prototype.getY = function () {
      return +this.getAttribute('y');
    };

    SVGElement.prototype.getWidth = function () {
      return +this.getAttribute('width');
    };

    SVGElement.prototype.getHeight = function () {
      return +this.getAttribute('height');
    };

    SVGElement.prototype.getEndX = function () {
      return this.getX() + this.getWidth();
    };
  }

  draw() {
    this.draw_bar();
    this.draw_progress_bar();
    this.draw_label();
    this.draw_resize_handles();
  }

  draw_bar() {
    this.$bar = (0,_svg_utils__WEBPACK_IMPORTED_MODULE_1__.createSVG)('rect', {
      x: this.x,
      y: this.y,
      width: this.width,
      height: this.height,
      rx: this.corner_radius,
      ry: this.corner_radius,
      class: 'bar',
      append_to: this.bar_group
    });
    (0,_svg_utils__WEBPACK_IMPORTED_MODULE_1__.animateSVG)(this.$bar, 'width', 0, this.width);

    if (this.invalid) {
      this.$bar.classList.add('bar-invalid');
    }
  }

  draw_progress_bar() {
    if (this.invalid) return;
    this.$bar_progress = (0,_svg_utils__WEBPACK_IMPORTED_MODULE_1__.createSVG)('rect', {
      x: this.x,
      y: this.y,
      width: this.progress_width,
      height: this.height,
      rx: this.corner_radius,
      ry: this.corner_radius,
      class: 'bar-progress',
      append_to: this.bar_group
    });
    (0,_svg_utils__WEBPACK_IMPORTED_MODULE_1__.animateSVG)(this.$bar_progress, 'width', 0, this.progress_width);
  }

  draw_label() {
    (0,_svg_utils__WEBPACK_IMPORTED_MODULE_1__.createSVG)('text', {
      x: this.x + this.width / 2,
      y: this.y + this.height / 2,
      innerHTML: this.task.name,
      class: 'bar-label',
      append_to: this.bar_group
    }); // labels get BBox in the next tick

    requestAnimationFrame(() => this.update_label_position());
  }

  draw_resize_handles() {
    if (this.invalid) return;
    const bar = this.$bar;
    const handle_width = 8;

    if (this.gantt.options.draggable) {
      (0,_svg_utils__WEBPACK_IMPORTED_MODULE_1__.createSVG)('rect', {
        x: bar.getX() + bar.getWidth() - 9,
        y: bar.getY() + 1,
        width: handle_width,
        height: this.height - 2,
        rx: this.corner_radius,
        ry: this.corner_radius,
        class: 'handle right',
        append_to: this.handle_group
      });
      (0,_svg_utils__WEBPACK_IMPORTED_MODULE_1__.createSVG)('rect', {
        x: bar.getX() + 1,
        y: bar.getY() + 1,
        width: handle_width,
        height: this.height - 2,
        rx: this.corner_radius,
        ry: this.corner_radius,
        class: 'handle left',
        append_to: this.handle_group
      });

      if (this.task.progress && this.task.progress < 100) {
        this.$handle_progress = (0,_svg_utils__WEBPACK_IMPORTED_MODULE_1__.createSVG)('polygon', {
          points: this.get_progress_polygon_points().join(','),
          class: 'handle progress',
          append_to: this.handle_group
        });
      }
    }
  }

  get_progress_polygon_points() {
    const bar_progress = this.$bar_progress;
    return [bar_progress.getEndX() - 5, bar_progress.getY() + bar_progress.getHeight(), bar_progress.getEndX() + 5, bar_progress.getY() + bar_progress.getHeight(), bar_progress.getEndX(), bar_progress.getY() + bar_progress.getHeight() - 8.66];
  }

  bind() {
    if (this.invalid) return;
    this.setup_click_event();
  }

  setup_click_event() {
    _svg_utils__WEBPACK_IMPORTED_MODULE_1__.$.on(this.group, 'focus ' + this.gantt.options.popup_trigger, e => {
      if (this.action_completed) {
        // just finished a move action, wait for a few seconds
        return;
      }

      this.show_popup();
      this.gantt.unselect_all();
      this.group.classList.add('active');
    });
    _svg_utils__WEBPACK_IMPORTED_MODULE_1__.$.on(this.group, 'dblclick', e => {
      if (this.action_completed) {
        // just finished a move action, wait for a few seconds
        return;
      }

      this.gantt.trigger_event('click', [this.task]);
    });
  }

  show_popup() {
    if (this.gantt.bar_being_dragged) return;
    const start_date = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].format(this.task._start, 'MMM D', this.gantt.options.language);
    const end_date = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].format(_date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].add(this.task._end, -1, 'second'), 'MMM D', this.gantt.options.language);
    const subtitle = start_date + ' - ' + end_date;
    this.gantt.show_popup({
      target_element: this.$bar,
      title: this.task.name,
      subtitle: subtitle,
      task: this.task
    });
  }

  update_bar_position({
    x = null,
    width = null
  }) {
    const bar = this.$bar;

    if (x) {
      // get all x values of parent task
      const xs = this.task.dependencies.map(dep => {
        return this.gantt.get_bar(dep).$bar.getX();
      }); // child task must not go before parent

      const valid_x = xs.reduce((prev, curr) => {
        return x >= curr;
      }, x);

      if (!valid_x) {
        width = null;
        return;
      }

      this.update_attr(bar, 'x', x);
    }

    if (width && width >= this.gantt.options.column_width) {
      this.update_attr(bar, 'width', width);
    }

    this.update_label_position();
    this.update_handle_position();
    this.update_progressbar_position();
    this.update_arrow_position();
  }

  date_changed() {
    let changed = false;
    const {
      new_start_date,
      new_end_date
    } = this.compute_start_end_date();

    if (Number(this.task._start) !== Number(new_start_date)) {
      changed = true;
      this.task._start = new_start_date;
    }

    if (Number(this.task._end) !== Number(new_end_date)) {
      changed = true;
      this.task._end = new_end_date;
    }

    if (!changed) return;
    this.gantt.trigger_event('date_change', [this.task, new_start_date, _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].add(new_end_date, -1, 'second')]);
  }

  progress_changed() {
    const new_progress = this.compute_progress();
    this.task.progress = new_progress;
    this.gantt.trigger_event('progress_change', [this.task, new_progress]);
  }

  set_action_completed() {
    this.action_completed = true;
    setTimeout(() => this.action_completed = false, 1000);
  }

  compute_start_end_date() {
    const bar = this.$bar;
    const x_in_units = bar.getX() / this.gantt.options.column_width;
    const new_start_date = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].add(this.gantt.gantt_start, x_in_units * this.gantt.options.step, 'hour');
    const width_in_units = bar.getWidth() / this.gantt.options.column_width;
    const new_end_date = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].add(new_start_date, width_in_units * this.gantt.options.step, 'hour');
    return {
      new_start_date,
      new_end_date
    };
  }

  compute_progress() {
    const progress = this.$bar_progress.getWidth() / this.$bar.getWidth() * 100;
    return parseInt(progress, 10);
  }

  compute_x() {
    const {
      step,
      column_width
    } = this.gantt.options;
    const task_start = this.task._start;
    const gantt_start = this.gantt.gantt_start;
    const diff = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].diff(task_start, gantt_start, 'hour');
    let x = diff / step * column_width;

    if (this.gantt.view_is('Month')) {
      const diff = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].diff(task_start, gantt_start, 'day');
      x = diff * column_width / 30;
    }

    return x;
  }

  compute_y() {
    return this.gantt.options.header_height + this.gantt.options.padding + this.task._index * (this.height + this.gantt.options.padding);
  }

  get_snap_position(dx) {
    let odx = dx,
        rem,
        position;

    if (this.gantt.view_is('Week')) {
      rem = dx % (this.gantt.options.column_width / 7);
      position = odx - rem + (rem < this.gantt.options.column_width / 14 ? 0 : this.gantt.options.column_width / 7);
    } else if (this.gantt.view_is('Month')) {
      rem = dx % (this.gantt.options.column_width / 30);
      position = odx - rem + (rem < this.gantt.options.column_width / 60 ? 0 : this.gantt.options.column_width / 30);
    } else {
      rem = dx % this.gantt.options.column_width;
      position = odx - rem + (rem < this.gantt.options.column_width / 2 ? 0 : this.gantt.options.column_width);
    }

    return position;
  }

  update_attr(element, attr, value) {
    value = +value;

    if (!isNaN(value)) {
      element.setAttribute(attr, value);
    }

    return element;
  }

  update_progressbar_position() {
    this.$bar_progress.setAttribute('x', this.$bar.getX());
    this.$bar_progress.setAttribute('width', this.$bar.getWidth() * (this.task.progress / 100));
  }

  update_label_position() {
    const bar = this.$bar,
          label = this.group.querySelector('.bar-label');

    if (label.getBBox().width > bar.getWidth()) {
      label.classList.add('big');
      label.setAttribute('x', bar.getX() + bar.getWidth() + 5);
    } else {
      label.classList.remove('big');
      label.setAttribute('x', bar.getX() + bar.getWidth() / 2);
    }
  }

  update_handle_position() {
    const bar = this.$bar;
    this.handle_group.querySelector('.handle.left').setAttribute('x', bar.getX() + 1);
    this.handle_group.querySelector('.handle.right').setAttribute('x', bar.getEndX() - 9);
    const handle = this.group.querySelector('.handle.progress');
    handle && handle.setAttribute('points', this.get_progress_polygon_points());
  }

  update_arrow_position() {
    this.arrows = this.arrows || [];

    for (let arrow of this.arrows) {
      arrow.update();
    }
  }

}

function isFunction(functionToCheck) {
  var getType = {};
  return functionToCheck && getType.toString.call(functionToCheck) === '[object Function]';
}

/***/ }),

/***/ 2280:
/*!*****************************************************!*\
  !*** ./node_modules/frappe-gantt/src/date_utils.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const YEAR = 'year';
const MONTH = 'month';
const DAY = 'day';
const HOUR = 'hour';
const MINUTE = 'minute';
const SECOND = 'second';
const MILLISECOND = 'millisecond';
const month_names = {
  en: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
  es: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
  ru: ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'],
  ptBr: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
  fr: ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'],
  tr: ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'],
  zh: ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月']
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  parse(date, date_separator = '-', time_separator = /[.:]/) {
    if (date instanceof Date) {
      return date;
    }

    if (typeof date === 'string') {
      let date_parts, time_parts;
      const parts = date.split(' ');
      date_parts = parts[0].split(date_separator).map(val => parseInt(val, 10));
      time_parts = parts[1] && parts[1].split(time_separator); // month is 0 indexed

      date_parts[1] = date_parts[1] - 1;
      let vals = date_parts;

      if (time_parts && time_parts.length) {
        if (time_parts.length == 4) {
          time_parts[3] = '0.' + time_parts[3];
          time_parts[3] = parseFloat(time_parts[3]) * 1000;
        }

        vals = vals.concat(time_parts);
      }

      return new Date(...vals);
    }
  },

  to_string(date, with_time = false) {
    if (!(date instanceof Date)) {
      throw new TypeError('Invalid argument type');
    }

    const vals = this.get_date_values(date).map((val, i) => {
      if (i === 1) {
        // add 1 for month
        val = val + 1;
      }

      if (i === 6) {
        return padStart(val + '', 3, '0');
      }

      return padStart(val + '', 2, '0');
    });
    const date_string = `${vals[0]}-${vals[1]}-${vals[2]}`;
    const time_string = `${vals[3]}:${vals[4]}:${vals[5]}.${vals[6]}`;
    return date_string + (with_time ? ' ' + time_string : '');
  },

  format(date, format_string = 'YYYY-MM-DD HH:mm:ss.SSS', lang = 'en') {
    const values = this.get_date_values(date).map(d => padStart(d, 2, 0));
    const format_map = {
      YYYY: values[0],
      MM: padStart(+values[1] + 1, 2, 0),
      DD: values[2],
      HH: values[3],
      mm: values[4],
      ss: values[5],
      SSS: values[6],
      D: values[2],
      MMMM: month_names[lang][+values[1]],
      MMM: month_names[lang][+values[1]]
    };
    let str = format_string;
    const formatted_values = [];
    Object.keys(format_map).sort((a, b) => b.length - a.length) // big string first
    .forEach(key => {
      if (str.includes(key)) {
        str = str.replace(key, `$${formatted_values.length}`);
        formatted_values.push(format_map[key]);
      }
    });
    formatted_values.forEach((value, i) => {
      str = str.replace(`$${i}`, value);
    });
    return str;
  },

  diff(date_a, date_b, scale = DAY) {
    let milliseconds, seconds, hours, minutes, days, months, years;
    milliseconds = date_a - date_b;
    seconds = milliseconds / 1000;
    minutes = seconds / 60;
    hours = minutes / 60;
    days = hours / 24;
    months = days / 30;
    years = months / 12;

    if (!scale.endsWith('s')) {
      scale += 's';
    }

    return Math.floor({
      milliseconds,
      seconds,
      minutes,
      hours,
      days,
      months,
      years
    }[scale]);
  },

  today() {
    const vals = this.get_date_values(new Date()).slice(0, 3);
    return new Date(...vals);
  },

  now() {
    return new Date();
  },

  add(date, qty, scale) {
    qty = parseInt(qty, 10);
    const vals = [date.getFullYear() + (scale === YEAR ? qty : 0), date.getMonth() + (scale === MONTH ? qty : 0), date.getDate() + (scale === DAY ? qty : 0), date.getHours() + (scale === HOUR ? qty : 0), date.getMinutes() + (scale === MINUTE ? qty : 0), date.getSeconds() + (scale === SECOND ? qty : 0), date.getMilliseconds() + (scale === MILLISECOND ? qty : 0)];
    return new Date(...vals);
  },

  start_of(date, scale) {
    const scores = {
      [YEAR]: 6,
      [MONTH]: 5,
      [DAY]: 4,
      [HOUR]: 3,
      [MINUTE]: 2,
      [SECOND]: 1,
      [MILLISECOND]: 0
    };

    function should_reset(_scale) {
      const max_score = scores[scale];
      return scores[_scale] <= max_score;
    }

    const vals = [date.getFullYear(), should_reset(YEAR) ? 0 : date.getMonth(), should_reset(MONTH) ? 1 : date.getDate(), should_reset(DAY) ? 0 : date.getHours(), should_reset(HOUR) ? 0 : date.getMinutes(), should_reset(MINUTE) ? 0 : date.getSeconds(), should_reset(SECOND) ? 0 : date.getMilliseconds()];
    return new Date(...vals);
  },

  clone(date) {
    return new Date(...this.get_date_values(date));
  },

  get_date_values(date) {
    return [date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds(), date.getMilliseconds()];
  },

  get_days_in_month(date) {
    const no_of_days = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    const month = date.getMonth();

    if (month !== 1) {
      return no_of_days[month];
    } // Feb


    const year = date.getFullYear();

    if (year % 4 == 0 && year % 100 != 0 || year % 400 == 0) {
      return 29;
    }

    return 28;
  }

}); // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/padStart

function padStart(str, targetLength, padString) {
  str = str + '';
  targetLength = targetLength >> 0;
  padString = String(typeof padString !== 'undefined' ? padString : ' ');

  if (str.length > targetLength) {
    return String(str);
  } else {
    targetLength = targetLength - str.length;

    if (targetLength > padString.length) {
      padString += padString.repeat(targetLength / padString.length);
    }

    return padString.slice(0, targetLength) + String(str);
  }
}

/***/ }),

/***/ 7871:
/*!************************************************!*\
  !*** ./node_modules/frappe-gantt/src/index.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Gantt)
/* harmony export */ });
/* harmony import */ var _date_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./date_utils */ 2280);
/* harmony import */ var _svg_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./svg_utils */ 882);
/* harmony import */ var _bar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./bar */ 5171);
/* harmony import */ var _arrow__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./arrow */ 4045);
/* harmony import */ var _popup__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./popup */ 9392);
/* harmony import */ var _gantt_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./gantt.scss */ 8529);






const VIEW_MODE = {
  QUARTER_DAY: 'Quarter Day',
  HALF_DAY: 'Half Day',
  DAY: 'Day',
  WEEK: 'Week',
  MONTH: 'Month',
  YEAR: 'Year'
};
class Gantt {
  constructor(wrapper, tasks, options) {
    this.setup_wrapper(wrapper);
    this.setup_options(options);
    this.setup_tasks(tasks); // initialize with default view mode

    this.change_view_mode();
    this.bind_events();
  }

  setup_wrapper(element) {
    let svg_element, wrapper_element; // CSS Selector is passed

    if (typeof element === 'string') {
      element = document.querySelector(element);
    } // get the SVGElement


    if (element instanceof HTMLElement) {
      wrapper_element = element;
      svg_element = element.querySelector('svg');
    } else if (element instanceof SVGElement) {
      svg_element = element;
    } else {
      throw new TypeError('Frappé Gantt only supports usage of a string CSS selector,' + " HTML DOM element or SVG DOM element for the 'element' parameter");
    } // svg element


    if (!svg_element) {
      // create it
      this.$svg = (0,_svg_utils__WEBPACK_IMPORTED_MODULE_1__.createSVG)('svg', {
        append_to: wrapper_element,
        class: 'gantt'
      });
    } else {
      this.$svg = svg_element;
      this.$svg.classList.add('gantt');
    } // wrapper element


    this.$container = document.createElement('div');
    this.$container.classList.add('gantt-container');
    const parent_element = this.$svg.parentElement;
    parent_element.appendChild(this.$container);
    this.$container.appendChild(this.$svg); // popup wrapper

    this.popup_wrapper = document.createElement('div');
    this.popup_wrapper.classList.add('popup-wrapper');
    this.$container.appendChild(this.popup_wrapper);
  }

  setup_options(options) {
    const default_options = {
      header_height: 50,
      column_width: 30,
      step: 24,
      view_modes: [...Object.values(VIEW_MODE)],
      bar_height: 20,
      bar_corner_radius: 3,
      arrow_curve: 5,
      padding: 18,
      view_mode: 'Day',
      date_format: 'YYYY-MM-DD',
      popup_trigger: 'mouseover',
      custom_popup_html: null,
      language: 'en',
      draggable: false,
      hasArrows: false
    };
    this.options = Object.assign({}, default_options, options);
  }

  setup_tasks(tasks) {
    // prepare tasks
    this.tasks = tasks.map((task, i) => {
      // convert to Date objects
      task._start = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].parse(task.start);
      task._end = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].parse(task.end); // make task invalid if duration too large

      if (_date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].diff(task._end, task._start, 'year') > 10) {
        task.end = null;
      } // cache index


      task._index = i; // invalid dates

      if (!task.start && !task.end) {
        const today = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].today();
        task._start = today;
        task._end = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].add(today, 2, 'day');
      }

      if (!task.start && task.end) {
        task._start = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].add(task._end, -2, 'day');
      }

      if (task.start && !task.end) {
        task._end = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].add(task._start, 2, 'day');
      } // if hours is not set, assume the last day is full day
      // e.g: 2018-09-09 becomes 2018-09-09 23:59:59


      const task_end_values = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].get_date_values(task._end);

      if (task_end_values.slice(3).every(d => d === 0)) {
        task._end = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].add(task._end, 24, 'hour');
      } // invalid flag


      if (!task.start || !task.end) {
        task.invalid = true;
      } // dependencies


      if (typeof task.dependencies === 'string' || !task.dependencies) {
        let deps = [];

        if (task.dependencies) {
          deps = task.dependencies.split(',').map(d => d.trim()).filter(d => d);
        }

        task.dependencies = deps;
      } // uids


      if (!task.id) {
        task.id = generate_id(task);
      }

      return task;
    });
    this.setup_dependencies();
  }

  setup_dependencies() {
    this.dependency_map = {};

    for (let t of this.tasks) {
      for (let d of t.dependencies) {
        this.dependency_map[d] = this.dependency_map[d] || [];
        this.dependency_map[d].push(t.id);
      }
    }
  }

  refresh(tasks) {
    this.setup_tasks(tasks);
    this.change_view_mode();
  }

  change_view_mode(mode = this.options.view_mode) {
    this.update_view_scale(mode);
    this.setup_dates();
    this.render(); // fire viewmode_change event

    this.trigger_event('view_change', [mode]);
  }

  update_view_scale(view_mode) {
    this.options.view_mode = view_mode;

    if (view_mode === VIEW_MODE.DAY) {
      this.options.step = 24;
      this.options.column_width = 38;
    } else if (view_mode === VIEW_MODE.HALF_DAY) {
      this.options.step = 24 / 2;
      this.options.column_width = 38;
    } else if (view_mode === VIEW_MODE.QUARTER_DAY) {
      this.options.step = 24 / 4;
      this.options.column_width = 38;
    } else if (view_mode === VIEW_MODE.WEEK) {
      this.options.step = 24 * 7;
      this.options.column_width = 140;
    } else if (view_mode === VIEW_MODE.MONTH) {
      this.options.step = 24 * 30;
      this.options.column_width = 120;
    } else if (view_mode === VIEW_MODE.YEAR) {
      this.options.step = 24 * 365;
      this.options.column_width = 120;
    }
  }

  setup_dates() {
    this.setup_gantt_dates();
    this.setup_date_values();
  }

  setup_gantt_dates() {
    this.gantt_start = this.gantt_end = null;

    for (let task of this.tasks) {
      // set global start and end date
      if (!this.gantt_start || task._start < this.gantt_start) {
        this.gantt_start = task._start;
      }

      if (!this.gantt_end || task._end > this.gantt_end) {
        this.gantt_end = task._end;
      }
    }

    this.gantt_start = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].start_of(this.gantt_start, 'day');
    this.gantt_end = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].start_of(this.gantt_end, 'day'); // add date padding on both sides

    if (this.view_is([VIEW_MODE.QUARTER_DAY, VIEW_MODE.HALF_DAY])) {
      this.gantt_start = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].add(this.gantt_start, -7, 'day');
      this.gantt_end = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].add(this.gantt_end, 7, 'day');
    } else if (this.view_is(VIEW_MODE.MONTH)) {
      this.gantt_start = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].start_of(this.gantt_start, 'year');
      this.gantt_end = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].add(this.gantt_end, 1, 'year');
    } else if (this.view_is(VIEW_MODE.YEAR)) {
      this.gantt_start = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].add(this.gantt_start, -2, 'year');
      this.gantt_end = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].add(this.gantt_end, 2, 'year');
    } else {
      this.gantt_start = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].add(this.gantt_start, -1, 'month');
      this.gantt_end = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].add(this.gantt_end, 1, 'month');
    }
  }

  setup_date_values() {
    this.dates = [];
    let cur_date = null;

    while (cur_date === null || cur_date < this.gantt_end) {
      if (!cur_date) {
        cur_date = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].clone(this.gantt_start);
      } else {
        if (this.view_is(VIEW_MODE.YEAR)) {
          cur_date = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].add(cur_date, 1, 'year');
        } else if (this.view_is(VIEW_MODE.MONTH)) {
          cur_date = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].add(cur_date, 1, 'month');
        } else {
          cur_date = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].add(cur_date, this.options.step, 'hour');
        }
      }

      this.dates.push(cur_date);
    }
  }

  bind_events() {
    this.bind_grid_click();
    this.bind_bar_events();
  }

  render() {
    this.clear();
    this.setup_layers();
    this.make_grid();
    this.make_dates();
    this.make_bars();
    this.make_arrows();
    this.map_arrows_on_bars();
    this.set_width();
    this.set_scroll_position();
  }

  setup_layers() {
    this.layers = {};
    const layers = ['grid', 'date', 'arrow', 'progress', 'bar', 'details']; // make group layers

    for (let layer of layers) {
      this.layers[layer] = (0,_svg_utils__WEBPACK_IMPORTED_MODULE_1__.createSVG)('g', {
        class: layer,
        append_to: this.$svg
      });
    }
  }

  make_grid() {
    this.make_grid_background();
    this.make_grid_rows();
    this.make_grid_header();
    this.make_grid_ticks();
    this.make_grid_highlights();
  }

  make_grid_background() {
    const grid_width = this.dates.length * this.options.column_width;
    const grid_height = this.options.header_height + this.options.padding + (this.options.bar_height + this.options.padding) * this.tasks.length;
    (0,_svg_utils__WEBPACK_IMPORTED_MODULE_1__.createSVG)('rect', {
      x: 0,
      y: 0,
      width: grid_width,
      height: grid_height,
      class: 'grid-background',
      append_to: this.layers.grid
    });
    _svg_utils__WEBPACK_IMPORTED_MODULE_1__.$.attr(this.$svg, {
      height: grid_height + this.options.padding + 100,
      width: '100%'
    });
  }

  make_grid_rows() {
    const rows_layer = (0,_svg_utils__WEBPACK_IMPORTED_MODULE_1__.createSVG)('g', {
      append_to: this.layers.grid
    });
    const lines_layer = (0,_svg_utils__WEBPACK_IMPORTED_MODULE_1__.createSVG)('g', {
      append_to: this.layers.grid
    });
    const row_width = this.dates.length * this.options.column_width;
    const row_height = this.options.bar_height + this.options.padding;
    let row_y = this.options.header_height + this.options.padding / 2;

    for (let task of this.tasks) {
      (0,_svg_utils__WEBPACK_IMPORTED_MODULE_1__.createSVG)('rect', {
        x: 0,
        y: row_y,
        width: row_width,
        height: row_height,
        class: `grid-row ${task.isChild ? 'child-row' : 'parent-row'}`,
        append_to: rows_layer
      });
      (0,_svg_utils__WEBPACK_IMPORTED_MODULE_1__.createSVG)('line', {
        x1: 0,
        y1: row_y + row_height,
        x2: row_width,
        y2: row_y + row_height,
        class: `row-line ${task.isChild ? 'child-line' : 'parent-line'}`,
        append_to: lines_layer
      });
      row_y += this.options.bar_height + this.options.padding;
    }
  }

  make_grid_header() {
    const header_width = this.dates.length * this.options.column_width;
    const header_height = this.options.header_height + 10;
    (0,_svg_utils__WEBPACK_IMPORTED_MODULE_1__.createSVG)('rect', {
      x: 0,
      y: 0,
      width: header_width,
      height: header_height,
      class: 'grid-header',
      append_to: this.layers.grid
    });
  }

  make_grid_ticks() {
    let tick_x = 0;
    let tick_y = this.options.header_height + this.options.padding / 2;
    let tick_height = (this.options.bar_height + this.options.padding) * this.tasks.length;

    for (let date of this.dates) {
      let tick_class = 'tick'; // thick tick for monday

      if (this.view_is(VIEW_MODE.DAY) && date.getDate() === 1) {
        tick_class += ' thick';
      } // thick tick for first week


      if (this.view_is(VIEW_MODE.WEEK) && date.getDate() >= 1 && date.getDate() < 8) {
        tick_class += ' thick';
      } // thick ticks for quarters


      if (this.view_is(VIEW_MODE.MONTH) && (date.getMonth() + 1) % 3 === 0) {
        tick_class += ' thick';
      }

      (0,_svg_utils__WEBPACK_IMPORTED_MODULE_1__.createSVG)('path', {
        d: `M ${tick_x} ${tick_y} v ${tick_height}`,
        class: tick_class,
        append_to: this.layers.grid
      });

      if (this.view_is(VIEW_MODE.MONTH)) {
        tick_x += _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].get_days_in_month(date) * this.options.column_width / 30;
      } else {
        tick_x += this.options.column_width;
      }
    }
  }

  make_grid_highlights() {
    // highlight today's date
    if (this.view_is(VIEW_MODE.DAY)) {
      const x = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].diff(_date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].today(), this.gantt_start, 'hour') / this.options.step * this.options.column_width;
      const y = 0;
      const width = this.options.column_width;
      const height = (this.options.bar_height + this.options.padding) * this.tasks.length + this.options.header_height + this.options.padding / 2;
      (0,_svg_utils__WEBPACK_IMPORTED_MODULE_1__.createSVG)('rect', {
        x,
        y,
        width,
        height,
        class: 'today-highlight',
        append_to: this.layers.grid
      });
    }
  }

  make_dates() {
    const today = new Date().getDate();

    for (let date of this.get_dates_to_draw()) {
      const addClassNameTodayHighlight = this.view_is(VIEW_MODE.DAY) && (date.lower_text === today || date.upper_text === today);

      if (addClassNameTodayHighlight) {
        (0,_svg_utils__WEBPACK_IMPORTED_MODULE_1__.createSVG)('text', {
          x: date.lower_x,
          y: date.lower_y,
          innerHTML: date.lower_text,
          class: 'today-date',
          append_to: this.layers.date
        });
      } else {
        (0,_svg_utils__WEBPACK_IMPORTED_MODULE_1__.createSVG)('text', {
          x: date.lower_x,
          y: date.lower_y,
          innerHTML: date.lower_text,
          class: 'lower-text',
          append_to: this.layers.date
        });
      }

      if (date.upper_text) {
        const $upper_text = (0,_svg_utils__WEBPACK_IMPORTED_MODULE_1__.createSVG)('text', {
          x: date.upper_x,
          y: date.upper_y,
          innerHTML: date.upper_text,
          class: 'upper-text',
          append_to: this.layers.date
        }); // remove out-of-bound dates

        if ($upper_text.getBBox().x2 > this.layers.grid.getBBox().width) {
          $upper_text.remove();
        }
      }
    }
  }

  get_dates_to_draw() {
    let last_date = null;
    const dates = this.dates.map((date, i) => {
      const d = this.get_date_info(date, last_date, i);
      last_date = date;
      return d;
    });
    return dates;
  }

  get_date_info(date, last_date, i) {
    if (!last_date) {
      last_date = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].add(date, 1, 'year');
    }

    const date_text = {
      'Quarter Day_lower': _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].format(date, 'HH', this.options.language),
      'Half Day_lower': _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].format(date, 'HH', this.options.language),
      Day_lower: date.getDate() !== last_date.getDate() ? _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].format(date, 'D', this.options.language) : '',
      Week_lower: date.getMonth() !== last_date.getMonth() ? _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].format(date, 'D MMM', this.options.language) : _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].format(date, 'D', this.options.language),
      Month_lower: _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].format(date, 'MMMM', this.options.language),
      Year_lower: _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].format(date, 'YYYY', this.options.language),
      'Quarter Day_upper': date.getDate() !== last_date.getDate() ? _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].format(date, 'D MMM', this.options.language) : '',
      'Half Day_upper': date.getDate() !== last_date.getDate() ? date.getMonth() !== last_date.getMonth() ? _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].format(date, 'D MMM', this.options.language) : _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].format(date, 'D', this.options.language) : '',
      Day_upper: date.getMonth() !== last_date.getMonth() ? _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].format(date, 'MMMM', this.options.language) : '',
      Week_upper: date.getMonth() !== last_date.getMonth() ? _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].format(date, 'MMMM', this.options.language) : '',
      Month_upper: date.getFullYear() !== last_date.getFullYear() ? _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].format(date, 'YYYY', this.options.language) : '',
      Year_upper: date.getFullYear() !== last_date.getFullYear() ? _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].format(date, 'YYYY', this.options.language) : ''
    };
    const base_pos = {
      x: i * this.options.column_width,
      lower_y: this.options.header_height,
      upper_y: this.options.header_height - 25
    };
    const x_pos = {
      'Quarter Day_lower': this.options.column_width * 4 / 2,
      'Quarter Day_upper': 0,
      'Half Day_lower': this.options.column_width * 2 / 2,
      'Half Day_upper': 0,
      Day_lower: this.options.column_width / 2,
      Day_upper: this.options.column_width * 30 / 2,
      Week_lower: 0,
      Week_upper: this.options.column_width * 4 / 2,
      Month_lower: this.options.column_width / 2,
      Month_upper: this.options.column_width * 12 / 2,
      Year_lower: this.options.column_width / 2,
      Year_upper: this.options.column_width * 30 / 2
    };
    return {
      upper_text: date_text[`${this.options.view_mode}_upper`],
      lower_text: date_text[`${this.options.view_mode}_lower`],
      upper_x: base_pos.x + x_pos[`${this.options.view_mode}_upper`],
      upper_y: base_pos.upper_y,
      lower_x: base_pos.x + x_pos[`${this.options.view_mode}_lower`],
      lower_y: base_pos.lower_y
    };
  }

  make_bars() {
    this.bars = this.tasks.map(task => {
      const bar = new _bar__WEBPACK_IMPORTED_MODULE_2__["default"](this, task);
      this.layers.bar.appendChild(bar.group);
      return bar;
    });
  }

  make_arrows() {
    this.arrows = [];

    if (this.options.hasArrows) {
      for (let task of this.tasks) {
        let arrows = [];
        arrows = task.dependencies.map(task_id => {
          const dependency = this.get_task(task_id);
          if (!dependency) return;
          const arrow = new _arrow__WEBPACK_IMPORTED_MODULE_3__["default"](this, this.bars[dependency._index], // from_task
          this.bars[task._index] // to_task
          );
          this.layers.arrow.appendChild(arrow.element);
          return arrow;
        }).filter(Boolean); // filter falsy values

        this.arrows = this.arrows.concat(arrows);
      }
    }
  }

  map_arrows_on_bars() {
    if (this.options.hasArrows) {
      for (let bar of this.bars) {
        bar.arrows = this.arrows.filter(arrow => {
          return arrow.from_task.task.id === bar.task.id || arrow.to_task.task.id === bar.task.id;
        });
      }
    }
  }

  set_width() {
    const cur_width = this.$svg.getBoundingClientRect().width;
    const actual_width = this.$svg.querySelector('.grid .grid-row').getAttribute('width');

    if (cur_width < actual_width) {
      this.$svg.setAttribute('width', actual_width);
    }
  }

  set_scroll_position() {
    const parent_element = this.$svg.parentElement;
    if (!parent_element) return;
    const hours_before_first_task = _date_utils__WEBPACK_IMPORTED_MODULE_0__["default"].diff(this.get_oldest_starting_date(), this.gantt_start, 'hour');
    const scroll_pos = hours_before_first_task / this.options.step * this.options.column_width - this.options.column_width;
    parent_element.scrollLeft = scroll_pos;
  }

  bind_grid_click() {
    _svg_utils__WEBPACK_IMPORTED_MODULE_1__.$.on(this.$svg, this.options.popup_trigger, '.grid-row, .grid-header', () => {
      this.unselect_all();
      this.hide_popup();
    });
  }

  bind_bar_events() {
    // enable/disable dragging
    if (this.options.draggable) {
      let is_dragging = false;
      let x_on_start = 0;
      let y_on_start = 0;
      let is_resizing_left = false;
      let is_resizing_right = false;
      let parent_bar_id = null;
      let bars = []; // instanceof Bar

      this.bar_being_dragged = null;

      function action_in_progress() {
        return is_dragging || is_resizing_left || is_resizing_right;
      }

      _svg_utils__WEBPACK_IMPORTED_MODULE_1__.$.on(this.$svg, 'mousedown', '.bar-wrapper, .handle', (e, element) => {
        const bar_wrapper = _svg_utils__WEBPACK_IMPORTED_MODULE_1__.$.closest('.bar-wrapper', element);

        if (element.classList.contains('left')) {
          is_resizing_left = true;
        } else if (element.classList.contains('right')) {
          is_resizing_right = true;
        } else if (element.classList.contains('bar-wrapper')) {
          is_dragging = true;
        }

        bar_wrapper.classList.add('active');
        x_on_start = e.offsetX;
        y_on_start = e.offsetY;
        parent_bar_id = bar_wrapper.getAttribute('data-id');
        const ids = [parent_bar_id, ...this.get_all_dependent_tasks(parent_bar_id)];
        bars = ids.map(id => this.get_bar(id));
        this.bar_being_dragged = parent_bar_id;
        bars.forEach(bar => {
          const $bar = bar.$bar;
          $bar.ox = $bar.getX();
          $bar.oy = $bar.getY();
          $bar.owidth = $bar.getWidth();
          $bar.finaldx = 0;
        });
      });
      _svg_utils__WEBPACK_IMPORTED_MODULE_1__.$.on(this.$svg, 'mousemove', e => {
        if (!action_in_progress()) return;
        const dx = e.offsetX - x_on_start;
        const dy = e.offsetY - y_on_start;
        bars.forEach(bar => {
          const $bar = bar.$bar;
          $bar.finaldx = this.get_snap_position(dx);

          if (is_resizing_left) {
            if (parent_bar_id === bar.task.id) {
              bar.update_bar_position({
                x: $bar.ox + $bar.finaldx,
                width: $bar.owidth - $bar.finaldx
              });
            } else {
              bar.update_bar_position({
                x: $bar.ox + $bar.finaldx
              });
            }
          } else if (is_resizing_right) {
            if (parent_bar_id === bar.task.id) {
              bar.update_bar_position({
                width: $bar.owidth + $bar.finaldx
              });
            }
          } else if (is_dragging) {
            bar.update_bar_position({
              x: $bar.ox + $bar.finaldx
            });
          }
        });
      });
      document.addEventListener('mouseup', e => {
        if (is_dragging || is_resizing_left || is_resizing_right) {
          bars.forEach(bar => bar.group.classList.remove('active'));
        }

        is_dragging = false;
        is_resizing_left = false;
        is_resizing_right = false;
      });
      _svg_utils__WEBPACK_IMPORTED_MODULE_1__.$.on(this.$svg, 'mouseup', e => {
        this.bar_being_dragged = null;
        bars.forEach(bar => {
          const $bar = bar.$bar;
          if (!$bar.finaldx) return;
          bar.date_changed();
          bar.set_action_completed();
        });
      });
    }

    this.bind_bar_progress();
  }

  bind_bar_progress() {
    let x_on_start = 0;
    let y_on_start = 0;
    let is_resizing = null;
    let bar = null;
    let $bar_progress = null;
    let $bar = null;
    _svg_utils__WEBPACK_IMPORTED_MODULE_1__.$.on(this.$svg, 'mousedown', '.handle.progress', (e, handle) => {
      is_resizing = true;
      x_on_start = e.offsetX;
      y_on_start = e.offsetY;
      const $bar_wrapper = _svg_utils__WEBPACK_IMPORTED_MODULE_1__.$.closest('.bar-wrapper', handle);
      const id = $bar_wrapper.getAttribute('data-id');
      bar = this.get_bar(id);
      $bar_progress = bar.$bar_progress;
      $bar = bar.$bar;
      $bar_progress.finaldx = 0;
      $bar_progress.owidth = $bar_progress.getWidth();
      $bar_progress.min_dx = -$bar_progress.getWidth();
      $bar_progress.max_dx = $bar.getWidth() - $bar_progress.getWidth();
    });
    _svg_utils__WEBPACK_IMPORTED_MODULE_1__.$.on(this.$svg, 'mousemove', e => {
      if (!is_resizing) return;
      let dx = e.offsetX - x_on_start;
      let dy = e.offsetY - y_on_start;

      if (dx > $bar_progress.max_dx) {
        dx = $bar_progress.max_dx;
      }

      if (dx < $bar_progress.min_dx) {
        dx = $bar_progress.min_dx;
      }

      const $handle = bar.$handle_progress;
      _svg_utils__WEBPACK_IMPORTED_MODULE_1__.$.attr($bar_progress, 'width', $bar_progress.owidth + dx);
      _svg_utils__WEBPACK_IMPORTED_MODULE_1__.$.attr($handle, 'points', bar.get_progress_polygon_points());
      $bar_progress.finaldx = dx;
    });
    _svg_utils__WEBPACK_IMPORTED_MODULE_1__.$.on(this.$svg, 'mouseup', () => {
      is_resizing = false;
      if (!($bar_progress && $bar_progress.finaldx)) return;
      bar.progress_changed();
      bar.set_action_completed();
    });
  }

  get_all_dependent_tasks(task_id) {
    let out = [];
    let to_process = [task_id];

    while (to_process.length) {
      const deps = to_process.reduce((acc, curr) => {
        acc = acc.concat(this.dependency_map[curr]);
        return acc;
      }, []);
      out = out.concat(deps);
      to_process = deps.filter(d => !to_process.includes(d));
    }

    return out.filter(Boolean);
  }

  get_snap_position(dx) {
    let odx = dx,
        rem,
        position;

    if (this.view_is(VIEW_MODE.WEEK)) {
      rem = dx % (this.options.column_width / 7);
      position = odx - rem + (rem < this.options.column_width / 14 ? 0 : this.options.column_width / 7);
    } else if (this.view_is(VIEW_MODE.MONTH)) {
      rem = dx % (this.options.column_width / 30);
      position = odx - rem + (rem < this.options.column_width / 60 ? 0 : this.options.column_width / 30);
    } else {
      rem = dx % this.options.column_width;
      position = odx - rem + (rem < this.options.column_width / 2 ? 0 : this.options.column_width);
    }

    return position;
  }

  unselect_all() {
    [...this.$svg.querySelectorAll('.bar-wrapper')].forEach(el => {
      el.classList.remove('active');
    });
  }

  view_is(modes) {
    if (typeof modes === 'string') {
      return this.options.view_mode === modes;
    }

    if (Array.isArray(modes)) {
      return modes.some(mode => this.options.view_mode === mode);
    }

    return false;
  }

  get_task(id) {
    return this.tasks.find(task => {
      return task.id === id;
    });
  }

  get_bar(id) {
    return this.bars.find(bar => {
      return bar.task.id === id;
    });
  }

  show_popup(options) {
    if (!this.popup) {
      this.popup = new _popup__WEBPACK_IMPORTED_MODULE_4__["default"](this.popup_wrapper, this.options.custom_popup_html);
    }

    this.popup.show(options);
  }

  hide_popup() {
    this.popup && this.popup.hide();
  }

  trigger_event(event, args) {
    if (this.options['on_' + event]) {
      this.options['on_' + event].apply(null, args);
    }
  }
  /**
   * Gets the oldest starting date from the list of tasks
   *
   * @returns Date
   * @memberof Gantt
   */


  get_oldest_starting_date() {
    return this.tasks.map(task => task._start).reduce((prev_date, cur_date) => cur_date <= prev_date ? cur_date : prev_date);
  }
  /**
   * Clear all elements from the parent svg element
   *
   * @memberof Gantt
   */


  clear() {
    this.$svg.innerHTML = '';
  }

}
Gantt.VIEW_MODE = VIEW_MODE;

function generate_id(task) {
  return task.name + '_' + Math.random().toString(36).slice(2, 12);
}

/***/ }),

/***/ 9392:
/*!************************************************!*\
  !*** ./node_modules/frappe-gantt/src/popup.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Popup)
/* harmony export */ });
class Popup {
  constructor(parent, custom_html) {
    this.parent = parent;
    this.custom_html = custom_html;
    this.make();
  }

  make() {
    this.parent.innerHTML = `
            <div class="title"></div>
            <div class="subtitle"></div>
            <div class="pointer"></div>
        `;
    this.hide();
    this.title = this.parent.querySelector('.title');
    this.subtitle = this.parent.querySelector('.subtitle');
    this.pointer = this.parent.querySelector('.pointer');
  }

  show(options) {
    if (!options.target_element) {
      throw new Error('target_element is required to show popup');
    }

    if (!options.position) {
      options.position = 'left';
    }

    const target_element = options.target_element;

    if (this.custom_html) {
      let html = this.custom_html(options.task);
      html += '<div class="pointer"></div>';
      this.parent.innerHTML = html;
      this.pointer = this.parent.querySelector('.pointer');
    } else {
      // set data
      this.title.innerHTML = options.title;
      this.subtitle.innerHTML = options.subtitle;
      this.parent.style.width = this.parent.clientWidth + 'px';
    } // set position


    let position_meta;

    if (target_element instanceof HTMLElement) {
      position_meta = target_element.getBoundingClientRect();
    } else if (target_element instanceof SVGElement) {
      position_meta = options.target_element.getBBox();
    }

    if (options.position === 'left') {
      this.parent.style.left = position_meta.x + (position_meta.width + 10) + 'px';
      this.parent.style.top = position_meta.y + 'px';
      this.pointer.style.transform = 'rotateZ(90deg)';
      this.pointer.style.left = '-7px';
      this.pointer.style.top = '2px';
    } // show


    this.parent.style.opacity = 1;
  }

  hide() {
    this.parent.style.opacity = 0;
  }

}

/***/ }),

/***/ 882:
/*!****************************************************!*\
  !*** ./node_modules/frappe-gantt/src/svg_utils.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": () => (/* binding */ $),
/* harmony export */   "animateSVG": () => (/* binding */ animateSVG),
/* harmony export */   "createSVG": () => (/* binding */ createSVG)
/* harmony export */ });
function $(expr, con) {
  return typeof expr === 'string' ? (con || document).querySelector(expr) : expr || null;
}
function createSVG(tag, attrs) {
  const elem = document.createElementNS('http://www.w3.org/2000/svg', tag);

  for (let attr in attrs) {
    if (attr === 'append_to') {
      const parent = attrs.append_to;
      parent.appendChild(elem);
    } else if (attr === 'innerHTML') {
      elem.innerHTML = attrs.innerHTML;
    } else {
      elem.setAttribute(attr, attrs[attr]);
    }
  }

  return elem;
}
function animateSVG(svgElement, attr, from, to) {
  const animatedSvgElement = getAnimationElement(svgElement, attr, from, to);

  if (animatedSvgElement === svgElement) {
    // triggered 2nd time programmatically
    // trigger artificial click event
    const event = document.createEvent('HTMLEvents');
    event.initEvent('click', true, true);
    event.eventName = 'click';
    animatedSvgElement.dispatchEvent(event);
  }
}

function getAnimationElement(svgElement, attr, from, to, dur = '0.4s', begin = '0.1s') {
  const animEl = svgElement.querySelector('animate');

  if (animEl) {
    $.attr(animEl, {
      attributeName: attr,
      from,
      to,
      dur,
      begin: 'click + ' + begin // artificial click

    });
    return svgElement;
  }

  const animateElement = createSVG('animate', {
    attributeName: attr,
    from,
    to,
    dur,
    begin,
    calcMode: 'spline',
    values: from + ';' + to,
    keyTimes: '0; 1',
    keySplines: cubic_bezier('ease-out')
  });
  svgElement.appendChild(animateElement);
  return svgElement;
}

function cubic_bezier(name) {
  return {
    ease: '.25 .1 .25 1',
    linear: '0 0 1 1',
    'ease-in': '.42 0 1 1',
    'ease-out': '0 0 .58 1',
    'ease-in-out': '.42 0 .58 1'
  }[name];
}

$.on = (element, event, selector, callback) => {
  if (!callback) {
    callback = selector;
    $.bind(element, event, callback);
  } else {
    $.delegate(element, event, selector, callback);
  }
};

$.off = (element, event, handler) => {
  element.removeEventListener(event, handler);
};

$.bind = (element, event, callback) => {
  event.split(/\s+/).forEach(function (event) {
    element.addEventListener(event, callback);
  });
};

$.delegate = (element, event, selector, callback) => {
  element.addEventListener(event, function (e) {
    const delegatedTarget = e.target.closest(selector);

    if (delegatedTarget) {
      e.delegatedTarget = delegatedTarget;
      callback.call(this, e, delegatedTarget);
    }
  });
};

$.closest = (selector, element) => {
  if (!element) return null;

  if (element.matches(selector)) {
    return element;
  }

  return $.closest(selector, element.parentNode);
};

$.attr = (element, attr, value) => {
  if (!value && typeof attr === 'string') {
    return element.getAttribute(attr);
  }

  if (typeof attr === 'object') {
    for (let key in attr) {
      $.attr(element, key, attr[key]);
    }

    return;
  }

  element.setAttribute(attr, value);
};

/***/ }),

/***/ 5367:
/*!**************************************************************!*\
  !*** ./node_modules/quill-mention/dist/quill.mention.esm.js ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Mention)
/* harmony export */ });
/* harmony import */ var quill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! quill */ 3786);
/* harmony import */ var quill__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(quill__WEBPACK_IMPORTED_MODULE_0__);


function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

function _extends() {
  _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _possibleConstructorReturn(self, call) {
  if (call && (typeof call === "object" || typeof call === "function")) {
    return call;
  } else if (call !== void 0) {
    throw new TypeError("Derived constructors may only return object or undefined");
  }

  return _assertThisInitialized(self);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _superPropBase(object, property) {
  while (!Object.prototype.hasOwnProperty.call(object, property)) {
    object = _getPrototypeOf(object);
    if (object === null) break;
  }

  return object;
}

function _get() {
  if (typeof Reflect !== "undefined" && Reflect.get) {
    _get = Reflect.get;
  } else {
    _get = function _get(target, property, receiver) {
      var base = _superPropBase(target, property);

      if (!base) return;
      var desc = Object.getOwnPropertyDescriptor(base, property);

      if (desc.get) {
        return desc.get.call(arguments.length < 3 ? target : receiver);
      }

      return desc.value;
    };
  }

  return _get.apply(this, arguments);
}

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];

  return arr2;
}

function _createForOfIteratorHelper(o, allowArrayLike) {
  var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"];

  if (!it) {
    if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") {
      if (it) o = it;
      var i = 0;

      var F = function () {};

      return {
        s: F,
        n: function () {
          if (i >= o.length) return {
            done: true
          };
          return {
            done: false,
            value: o[i++]
          };
        },
        e: function (e) {
          throw e;
        },
        f: F
      };
    }

    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }

  var normalCompletion = true,
      didErr = false,
      err;
  return {
    s: function () {
      it = it.call(o);
    },
    n: function () {
      var step = it.next();
      normalCompletion = step.done;
      return step;
    },
    e: function (e) {
      didErr = true;
      err = e;
    },
    f: function () {
      try {
        if (!normalCompletion && it.return != null) it.return();
      } finally {
        if (didErr) throw err;
      }
    }
  };
}

var Keys = {
  TAB: 9,
  ENTER: 13,
  ESCAPE: 27,
  UP: 38,
  DOWN: 40
};

function attachDataValues(element, data, dataAttributes) {
  var mention = element;
  Object.keys(data).forEach(function (key) {
    if (dataAttributes.indexOf(key) > -1) {
      mention.dataset[key] = data[key];
    } else {
      delete mention.dataset[key];
    }
  });
  return mention;
}

function getMentionCharIndex(text, mentionDenotationChars) {
  return mentionDenotationChars.reduce(function (prev, mentionChar) {
    var mentionCharIndex = text.lastIndexOf(mentionChar);

    if (mentionCharIndex > prev.mentionCharIndex) {
      return {
        mentionChar: mentionChar,
        mentionCharIndex: mentionCharIndex
      };
    }

    return {
      mentionChar: prev.mentionChar,
      mentionCharIndex: prev.mentionCharIndex
    };
  }, {
    mentionChar: null,
    mentionCharIndex: -1
  });
}

function hasValidChars(text, allowedChars) {
  return allowedChars.test(text);
}

function hasValidMentionCharIndex(mentionCharIndex, text, isolateChar) {
  if (mentionCharIndex > -1) {
    if (isolateChar && !(mentionCharIndex === 0 || !!text[mentionCharIndex - 1].match(/\s/g))) {
      return false;
    }

    return true;
  }

  return false;
}

var Embed = quill__WEBPACK_IMPORTED_MODULE_0___default()["import"]("blots/embed");

var MentionBlot = /*#__PURE__*/function (_Embed) {
  _inherits(MentionBlot, _Embed);

  var _super = _createSuper(MentionBlot);

  function MentionBlot(scroll, node) {
    var _this;

    _classCallCheck(this, MentionBlot);

    _this = _super.call(this, scroll, node);

    _defineProperty(_assertThisInitialized(_this), "hoverHandler", void 0);

    _defineProperty(_assertThisInitialized(_this), "hoverHandler", void 0);

    _this.clickHandler = null;
    _this.hoverHandler = null;
    _this.mounted = false;
    return _this;
  }

  _createClass(MentionBlot, [{
    key: "attach",
    value: function attach() {
      _get(_getPrototypeOf(MentionBlot.prototype), "attach", this).call(this);

      if (!this.mounted) {
        this.mounted = true;
        this.clickHandler = this.getClickHandler();
        this.hoverHandler = this.getHoverHandler();
        this.domNode.addEventListener("click", this.clickHandler, false);
        this.domNode.addEventListener("mouseenter", this.hoverHandler, false);
      }
    }
  }, {
    key: "detach",
    value: function detach() {
      _get(_getPrototypeOf(MentionBlot.prototype), "detach", this).call(this);

      this.mounted = false;

      if (this.clickHandler) {
        this.domNode.removeEventListener("click", this.clickHandler);
        this.clickHandler = null;
      }
    }
  }, {
    key: "getClickHandler",
    value: function getClickHandler() {
      var _this2 = this;

      return function (e) {
        var event = _this2.buildEvent("mention-clicked", e);

        window.dispatchEvent(event);
        e.preventDefault();
      };
    }
  }, {
    key: "getHoverHandler",
    value: function getHoverHandler() {
      var _this3 = this;

      return function (e) {
        var event = _this3.buildEvent('mention-hovered', e);

        window.dispatchEvent(event);
        e.preventDefault();
      };
    }
  }, {
    key: "buildEvent",
    value: function buildEvent(name, e) {
      var event = new Event(name, {
        bubbles: true,
        cancelable: true
      });
      event.value = _extends({}, this.domNode.dataset);
      event.event = e;
      return event;
    }
  }], [{
    key: "create",
    value: function create(data) {
      var node = _get(_getPrototypeOf(MentionBlot), "create", this).call(this);

      var denotationChar = document.createElement("span");
      denotationChar.className = "ql-mention-denotation-char";
      denotationChar.innerHTML = data.denotationChar;
      node.appendChild(denotationChar);
      node.innerHTML += data.value;
      return MentionBlot.setDataValues(node, data);
    }
  }, {
    key: "setDataValues",
    value: function setDataValues(element, data) {
      var domNode = element;
      Object.keys(data).forEach(function (key) {
        domNode.dataset[key] = data[key];
      });
      return domNode;
    }
  }, {
    key: "value",
    value: function value(domNode) {
      return domNode.dataset;
    }
  }]);

  return MentionBlot;
}(Embed);

MentionBlot.blotName = "mention";
MentionBlot.tagName = "span";
MentionBlot.className = "mention";
quill__WEBPACK_IMPORTED_MODULE_0___default().register(MentionBlot);

var Mention = /*#__PURE__*/function () {
  function Mention(quill, options) {
    var _this = this;

    _classCallCheck(this, Mention);

    this.isOpen = false;
    this.itemIndex = 0;
    this.mentionCharPos = null;
    this.cursorPos = null;
    this.values = [];
    this.suspendMouseEnter = false; //this token is an object that may contains one key "abandoned", set to
    //true when the previous source call should be ignored in favor or a
    //more recent execution.  This token will be null unless a source call
    //is in progress.

    this.existingSourceExecutionToken = null;
    this.quill = quill;
    this.options = {
      source: null,
      renderItem: function renderItem(item) {
        return "".concat(item.value);
      },
      renderLoading: function renderLoading() {
        return null;
      },
      onSelect: function onSelect(item, insertItem) {
        insertItem(item);
      },
      mentionDenotationChars: ["@"],
      showDenotationChar: true,
      allowedChars: /^[a-zA-Z0-9_]*$/,
      minChars: 0,
      maxChars: 31,
      offsetTop: 2,
      offsetLeft: 0,
      isolateCharacter: false,
      fixMentionsToQuill: false,
      positioningStrategy: "normal",
      defaultMenuOrientation: "bottom",
      blotName: "mention",
      dataAttributes: ["id", "value", "denotationChar", "link", "target", "disabled"],
      linkTarget: "_blank",
      onOpen: function onOpen() {
        return true;
      },
      onBeforeClose: function onBeforeClose() {
        return true;
      },
      onClose: function onClose() {
        return true;
      },
      // Style options
      listItemClass: "ql-mention-list-item",
      mentionContainerClass: "ql-mention-list-container",
      mentionListClass: "ql-mention-list",
      spaceAfterInsert: true,
      selectKeys: [Keys.ENTER]
    };

    _extends(this.options, options, {
      dataAttributes: Array.isArray(options.dataAttributes) ? this.options.dataAttributes.concat(options.dataAttributes) : this.options.dataAttributes
    }); //create mention container


    this.mentionContainer = document.createElement("div");
    this.mentionContainer.className = this.options.mentionContainerClass ? this.options.mentionContainerClass : "";
    this.mentionContainer.style.cssText = "display: none; position: absolute;";
    this.mentionContainer.onmousemove = this.onContainerMouseMove.bind(this);

    if (this.options.fixMentionsToQuill) {
      this.mentionContainer.style.width = "auto";
    }

    this.mentionList = document.createElement("ul");
    this.mentionList.id = 'quill-mention-list';
    quill.root.setAttribute('aria-owns', 'quill-mention-list');
    this.mentionList.className = this.options.mentionListClass ? this.options.mentionListClass : "";
    this.mentionContainer.appendChild(this.mentionList);
    quill.on("text-change", this.onTextChange.bind(this));
    quill.on("selection-change", this.onSelectionChange.bind(this)); //Pasting doesn't fire selection-change after the pasted text is
    //inserted, so here we manually trigger one

    quill.container.addEventListener("paste", function () {
      setTimeout(function () {
        var range = quill.getSelection();

        _this.onSelectionChange(range);
      });
    });
    quill.keyboard.addBinding({
      key: Keys.TAB
    }, this.selectHandler.bind(this));
    quill.keyboard.bindings[Keys.TAB].unshift(quill.keyboard.bindings[Keys.TAB].pop());

    var _iterator = _createForOfIteratorHelper(this.options.selectKeys),
        _step;

    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var selectKey = _step.value;
        quill.keyboard.addBinding({
          key: selectKey
        }, this.selectHandler.bind(this));
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }

    quill.keyboard.bindings[Keys.ENTER].unshift(quill.keyboard.bindings[Keys.ENTER].pop());
    quill.keyboard.addBinding({
      key: Keys.ESCAPE
    }, this.escapeHandler.bind(this));
    quill.keyboard.addBinding({
      key: Keys.UP
    }, this.upHandler.bind(this));
    quill.keyboard.addBinding({
      key: Keys.DOWN
    }, this.downHandler.bind(this));
  }

  _createClass(Mention, [{
    key: "selectHandler",
    value: function selectHandler() {
      if (this.isOpen && !this.existingSourceExecutionToken) {
        this.selectItem();
        return false;
      }

      return true;
    }
  }, {
    key: "escapeHandler",
    value: function escapeHandler() {
      if (this.isOpen) {
        if (this.existingSourceExecutionToken) {
          this.existingSourceExecutionToken.abandoned = true;
        }

        this.hideMentionList();
        return false;
      }

      return true;
    }
  }, {
    key: "upHandler",
    value: function upHandler() {
      if (this.isOpen && !this.existingSourceExecutionToken) {
        this.prevItem();
        return false;
      }

      return true;
    }
  }, {
    key: "downHandler",
    value: function downHandler() {
      if (this.isOpen && !this.existingSourceExecutionToken) {
        this.nextItem();
        return false;
      }

      return true;
    }
  }, {
    key: "showMentionList",
    value: function showMentionList() {
      if (this.options.positioningStrategy === "fixed") {
        document.body.appendChild(this.mentionContainer);
      } else {
        this.quill.container.appendChild(this.mentionContainer);
      }

      this.mentionContainer.style.visibility = "hidden";
      this.mentionContainer.style.display = "";
      this.mentionContainer.scrollTop = 0;
      this.setMentionContainerPosition();
      this.setIsOpen(true);
    }
  }, {
    key: "hideMentionList",
    value: function hideMentionList() {
      this.options.onBeforeClose();
      this.mentionContainer.style.display = "none";
      this.mentionContainer.remove();
      this.setIsOpen(false);
      this.quill.root.removeAttribute('aria-activedescendant');
    }
  }, {
    key: "highlightItem",
    value: function highlightItem() {
      var scrollItemInView = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;

      for (var i = 0; i < this.mentionList.childNodes.length; i += 1) {
        this.mentionList.childNodes[i].classList.remove("selected");
      }

      if (this.itemIndex === -1 || this.mentionList.childNodes[this.itemIndex].dataset.disabled === "true") {
        return;
      }

      this.mentionList.childNodes[this.itemIndex].classList.add("selected");
      this.quill.root.setAttribute('aria-activedescendant', this.mentionList.childNodes[this.itemIndex].id);

      if (scrollItemInView) {
        var itemHeight = this.mentionList.childNodes[this.itemIndex].offsetHeight;
        var itemPos = this.mentionList.childNodes[this.itemIndex].offsetTop;
        var containerTop = this.mentionContainer.scrollTop;
        var containerBottom = containerTop + this.mentionContainer.offsetHeight;

        if (itemPos < containerTop) {
          // Scroll up if the item is above the top of the container
          this.mentionContainer.scrollTop = itemPos;
        } else if (itemPos > containerBottom - itemHeight) {
          // scroll down if any part of the element is below the bottom of the container
          this.mentionContainer.scrollTop += itemPos - containerBottom + itemHeight;
        }
      }
    }
  }, {
    key: "getItemData",
    value: function getItemData() {
      var link = this.mentionList.childNodes[this.itemIndex].dataset.link;
      var hasLinkValue = typeof link !== "undefined";
      var itemTarget = this.mentionList.childNodes[this.itemIndex].dataset.target;

      if (hasLinkValue) {
        this.mentionList.childNodes[this.itemIndex].dataset.value = "<a href=\"".concat(link, "\" target=").concat(itemTarget || this.options.linkTarget, ">").concat(this.mentionList.childNodes[this.itemIndex].dataset.value);
      }

      return this.mentionList.childNodes[this.itemIndex].dataset;
    }
  }, {
    key: "onContainerMouseMove",
    value: function onContainerMouseMove() {
      this.suspendMouseEnter = false;
    }
  }, {
    key: "selectItem",
    value: function selectItem() {
      var _this2 = this;

      if (this.itemIndex === -1) {
        return;
      }

      var data = this.getItemData();

      if (data.disabled) {
        return;
      }

      this.options.onSelect(data, function (asyncData) {
        _this2.insertItem(asyncData);
      });
      this.hideMentionList();
    }
  }, {
    key: "insertItem",
    value: function insertItem(data, programmaticInsert) {
      var render = data;

      if (render === null) {
        return;
      }

      if (!this.options.showDenotationChar) {
        render.denotationChar = "";
      }

      var insertAtPos;

      if (!programmaticInsert) {
        insertAtPos = this.mentionCharPos;
        this.quill.deleteText(this.mentionCharPos, this.cursorPos - this.mentionCharPos, (quill__WEBPACK_IMPORTED_MODULE_0___default().sources.USER));
      } else {
        insertAtPos = this.cursorPos;
      }

      this.quill.insertEmbed(insertAtPos, this.options.blotName, render, (quill__WEBPACK_IMPORTED_MODULE_0___default().sources.USER));

      if (this.options.spaceAfterInsert) {
        this.quill.insertText(insertAtPos + 1, " ", (quill__WEBPACK_IMPORTED_MODULE_0___default().sources.USER)); // setSelection here sets cursor position

        this.quill.setSelection(insertAtPos + 2, (quill__WEBPACK_IMPORTED_MODULE_0___default().sources.USER));
      } else {
        this.quill.setSelection(insertAtPos + 1, (quill__WEBPACK_IMPORTED_MODULE_0___default().sources.USER));
      }

      this.hideMentionList();
    }
  }, {
    key: "onItemMouseEnter",
    value: function onItemMouseEnter(e) {
      if (this.suspendMouseEnter) {
        return;
      }

      var index = Number(e.target.dataset.index);

      if (!Number.isNaN(index) && index !== this.itemIndex) {
        this.itemIndex = index;
        this.highlightItem(false);
      }
    }
  }, {
    key: "onDisabledItemMouseEnter",
    value: function onDisabledItemMouseEnter(e) {
      if (this.suspendMouseEnter) {
        return;
      }

      this.itemIndex = -1;
      this.highlightItem(false);
    }
  }, {
    key: "onItemClick",
    value: function onItemClick(e) {
      if (e.button !== 0) {
        return;
      }

      e.preventDefault();
      e.stopImmediatePropagation();
      this.itemIndex = e.currentTarget.dataset.index;
      this.highlightItem();
      this.selectItem();
    }
  }, {
    key: "onItemMouseDown",
    value: function onItemMouseDown(e) {
      e.preventDefault();
      e.stopImmediatePropagation();
    }
  }, {
    key: "renderLoading",
    value: function renderLoading() {
      var renderedLoading = this.options.renderLoading();

      if (!renderedLoading) {
        return;
      }

      if (this.mentionContainer.getElementsByClassName("ql-mention-loading").length > 0) {
        this.showMentionList();
        return;
      }

      this.mentionList.innerHTML = "";
      var loadingDiv = document.createElement("div");
      loadingDiv.className = "ql-mention-loading";
      loadingDiv.innerHTML = this.options.renderLoading();
      this.mentionContainer.append(loadingDiv);
      this.showMentionList();
    }
  }, {
    key: "removeLoading",
    value: function removeLoading() {
      var loadingDiv = this.mentionContainer.getElementsByClassName("ql-mention-loading");

      if (loadingDiv.length > 0) {
        loadingDiv[0].remove();
      }
    }
  }, {
    key: "renderList",
    value: function renderList(mentionChar, data, searchTerm) {
      if (data && data.length > 0) {
        this.removeLoading();
        this.values = data;
        this.mentionList.innerHTML = "";
        var initialSelection = -1;

        for (var i = 0; i < data.length; i += 1) {
          var li = document.createElement("li");
          li.id = 'quill-mention-item-' + i;
          li.className = this.options.listItemClass ? this.options.listItemClass : "";

          if (data[i].disabled) {
            li.className += " disabled";
            li.setAttribute('aria-hidden', 'true');
          } else if (initialSelection === -1) {
            initialSelection = i;
          }

          li.dataset.index = i;
          li.innerHTML = this.options.renderItem(data[i], searchTerm);

          if (!data[i].disabled) {
            li.onmouseenter = this.onItemMouseEnter.bind(this);
            li.onmouseup = this.onItemClick.bind(this);
            li.onmousedown = this.onItemMouseDown.bind(this);
          } else {
            li.onmouseenter = this.onDisabledItemMouseEnter.bind(this);
          }

          li.dataset.denotationChar = mentionChar;
          this.mentionList.appendChild(attachDataValues(li, data[i], this.options.dataAttributes));
        }

        this.itemIndex = initialSelection;
        this.highlightItem();
        this.showMentionList();
      } else {
        this.hideMentionList();
      }
    }
  }, {
    key: "nextItem",
    value: function nextItem() {
      var increment = 0;
      var newIndex;

      do {
        increment++;
        newIndex = (this.itemIndex + increment) % this.values.length;
        var disabled = this.mentionList.childNodes[newIndex].dataset.disabled === "true";

        if (increment === this.values.length + 1) {
          //we've wrapped around w/o finding an enabled item
          newIndex = -1;
          break;
        }
      } while (disabled);

      this.itemIndex = newIndex;
      this.suspendMouseEnter = true;
      this.highlightItem();
    }
  }, {
    key: "prevItem",
    value: function prevItem() {
      var decrement = 0;
      var newIndex;

      do {
        decrement++;
        newIndex = (this.itemIndex + this.values.length - decrement) % this.values.length;
        var disabled = this.mentionList.childNodes[newIndex].dataset.disabled === "true";

        if (decrement === this.values.length + 1) {
          //we've wrapped around w/o finding an enabled item
          newIndex = -1;
          break;
        }
      } while (disabled);

      this.itemIndex = newIndex;
      this.suspendMouseEnter = true;
      this.highlightItem();
    }
  }, {
    key: "containerBottomIsNotVisible",
    value: function containerBottomIsNotVisible(topPos, containerPos) {
      var mentionContainerBottom = topPos + this.mentionContainer.offsetHeight + containerPos.top;
      return mentionContainerBottom > window.pageYOffset + window.innerHeight;
    }
  }, {
    key: "containerRightIsNotVisible",
    value: function containerRightIsNotVisible(leftPos, containerPos) {
      if (this.options.fixMentionsToQuill) {
        return false;
      }

      var rightPos = leftPos + this.mentionContainer.offsetWidth + containerPos.left;
      var browserWidth = window.pageXOffset + document.documentElement.clientWidth;
      return rightPos > browserWidth;
    }
  }, {
    key: "setIsOpen",
    value: function setIsOpen(isOpen) {
      if (this.isOpen !== isOpen) {
        if (isOpen) {
          this.options.onOpen();
        } else {
          this.options.onClose();
        }

        this.isOpen = isOpen;
      }
    }
  }, {
    key: "setMentionContainerPosition",
    value: function setMentionContainerPosition() {
      if (this.options.positioningStrategy === "fixed") {
        this.setMentionContainerPosition_Fixed();
      } else {
        this.setMentionContainerPosition_Normal();
      }
    }
  }, {
    key: "setMentionContainerPosition_Normal",
    value: function setMentionContainerPosition_Normal() {
      var _this3 = this;

      var containerPos = this.quill.container.getBoundingClientRect();
      var mentionCharPos = this.quill.getBounds(this.mentionCharPos);
      var containerHeight = this.mentionContainer.offsetHeight;
      var topPos = this.options.offsetTop;
      var leftPos = this.options.offsetLeft; // handle horizontal positioning

      if (this.options.fixMentionsToQuill) {
        var rightPos = 0;
        this.mentionContainer.style.right = "".concat(rightPos, "px");
      } else {
        leftPos += mentionCharPos.left;
      }

      if (this.containerRightIsNotVisible(leftPos, containerPos)) {
        var containerWidth = this.mentionContainer.offsetWidth + this.options.offsetLeft;
        var quillWidth = containerPos.width;
        leftPos = quillWidth - containerWidth;
      } // handle vertical positioning


      if (this.options.defaultMenuOrientation === "top") {
        // Attempt to align the mention container with the top of the quill editor
        if (this.options.fixMentionsToQuill) {
          topPos = -1 * (containerHeight + this.options.offsetTop);
        } else {
          topPos = mentionCharPos.top - (containerHeight + this.options.offsetTop);
        } // default to bottom if the top is not visible


        if (topPos + containerPos.top <= 0) {
          var overMentionCharPos = this.options.offsetTop;

          if (this.options.fixMentionsToQuill) {
            overMentionCharPos += containerPos.height;
          } else {
            overMentionCharPos += mentionCharPos.bottom;
          }

          topPos = overMentionCharPos;
        }
      } else {
        // Attempt to align the mention container with the bottom of the quill editor
        if (this.options.fixMentionsToQuill) {
          topPos += containerPos.height;
        } else {
          topPos += mentionCharPos.bottom;
        } // default to the top if the bottom is not visible


        if (this.containerBottomIsNotVisible(topPos, containerPos)) {
          var _overMentionCharPos = this.options.offsetTop * -1;

          if (!this.options.fixMentionsToQuill) {
            _overMentionCharPos += mentionCharPos.top;
          }

          topPos = _overMentionCharPos - containerHeight;
        }
      }

      if (topPos >= 0) {
        this.options.mentionContainerClass.split(' ').forEach(function (className) {
          _this3.mentionContainer.classList.add("".concat(className, "-bottom"));

          _this3.mentionContainer.classList.remove("".concat(className, "-top"));
        });
      } else {
        this.options.mentionContainerClass.split(' ').forEach(function (className) {
          _this3.mentionContainer.classList.add("".concat(className, "-top"));

          _this3.mentionContainer.classList.remove("".concat(className, "-bottom"));
        });
      }

      this.mentionContainer.style.top = "".concat(topPos, "px");
      this.mentionContainer.style.left = "".concat(leftPos, "px");
      this.mentionContainer.style.visibility = "visible";
    }
  }, {
    key: "setMentionContainerPosition_Fixed",
    value: function setMentionContainerPosition_Fixed() {
      var _this4 = this;

      this.mentionContainer.style.position = "fixed";
      this.mentionContainer.style.height = null;
      var containerPos = this.quill.container.getBoundingClientRect();
      var mentionCharPos = this.quill.getBounds(this.mentionCharPos);
      var mentionCharPosAbsolute = {
        left: containerPos.left + mentionCharPos.left,
        top: containerPos.top + mentionCharPos.top,
        width: 0,
        height: mentionCharPos.height
      }; //Which rectangle should it be relative to

      var relativeToPos = this.options.fixMentionsToQuill ? containerPos : mentionCharPosAbsolute;
      var topPos = this.options.offsetTop;
      var leftPos = this.options.offsetLeft; // handle horizontal positioning

      if (this.options.fixMentionsToQuill) {
        var rightPos = relativeToPos.right;
        this.mentionContainer.style.right = "".concat(rightPos, "px");
      } else {
        leftPos += relativeToPos.left; //if its off the righ edge, push it back

        if (leftPos + this.mentionContainer.offsetWidth > document.documentElement.clientWidth) {
          leftPos -= leftPos + this.mentionContainer.offsetWidth - document.documentElement.clientWidth;
        }
      }

      var availableSpaceTop = relativeToPos.top;
      var availableSpaceBottom = document.documentElement.clientHeight - (relativeToPos.top + relativeToPos.height);
      var fitsBottom = this.mentionContainer.offsetHeight <= availableSpaceBottom;
      var fitsTop = this.mentionContainer.offsetHeight <= availableSpaceTop;
      var placement;

      if (this.options.defaultMenuOrientation === "top" && fitsTop) {
        placement = "top";
      } else if (this.options.defaultMenuOrientation === "bottom" && fitsBottom) {
        placement = "bottom";
      } else {
        //it doesnt fit either so put it where there's the most space
        placement = availableSpaceBottom > availableSpaceTop ? "bottom" : "top";
      }

      if (placement === "bottom") {
        topPos = relativeToPos.top + relativeToPos.height;

        if (!fitsBottom) {
          //shrink it to fit
          //3 is a bit of a fudge factor so it doesnt touch the edge of the screen
          this.mentionContainer.style.height = availableSpaceBottom - 3 + "px";
        }

        this.options.mentionContainerClass.split(" ").forEach(function (className) {
          _this4.mentionContainer.classList.add("".concat(className, "-bottom"));

          _this4.mentionContainer.classList.remove("".concat(className, "-top"));
        });
      } else {
        topPos = relativeToPos.top - this.mentionContainer.offsetHeight;

        if (!fitsTop) {
          //shrink it to fit
          //3 is a bit of a fudge factor so it doesnt touch the edge of the screen
          this.mentionContainer.style.height = availableSpaceTop - 3 + "px";
          topPos = 3;
        }

        this.options.mentionContainerClass.split(" ").forEach(function (className) {
          _this4.mentionContainer.classList.add("".concat(className, "-top"));

          _this4.mentionContainer.classList.remove("".concat(className, "-bottom"));
        });
      }

      this.mentionContainer.style.top = "".concat(topPos, "px");
      this.mentionContainer.style.left = "".concat(leftPos, "px");
      this.mentionContainer.style.visibility = "visible";
    }
  }, {
    key: "getTextBeforeCursor",
    value: function getTextBeforeCursor() {
      var startPos = Math.max(0, this.cursorPos - this.options.maxChars);
      var textBeforeCursorPos = this.quill.getText(startPos, this.cursorPos - startPos);
      return textBeforeCursorPos;
    }
  }, {
    key: "onSomethingChange",
    value: function onSomethingChange() {
      var _this5 = this;

      var range = this.quill.getSelection();
      if (range == null) return;
      this.cursorPos = range.index;
      var textBeforeCursor = this.getTextBeforeCursor();

      var _getMentionCharIndex = getMentionCharIndex(textBeforeCursor, this.options.mentionDenotationChars),
          mentionChar = _getMentionCharIndex.mentionChar,
          mentionCharIndex = _getMentionCharIndex.mentionCharIndex;

      if (hasValidMentionCharIndex(mentionCharIndex, textBeforeCursor, this.options.isolateCharacter)) {
        var mentionCharPos = this.cursorPos - (textBeforeCursor.length - mentionCharIndex);
        this.mentionCharPos = mentionCharPos;
        var textAfter = textBeforeCursor.substring(mentionCharIndex + mentionChar.length);

        if (textAfter.length >= this.options.minChars && hasValidChars(textAfter, this.getAllowedCharsRegex(mentionChar))) {
          if (this.existingSourceExecutionToken) {
            this.existingSourceExecutionToken.abandoned = true;
          }

          this.renderLoading();
          var sourceRequestToken = {
            abandoned: false
          };
          this.existingSourceExecutionToken = sourceRequestToken;
          this.options.source(textAfter, function (data, searchTerm) {
            if (sourceRequestToken.abandoned) {
              return;
            }

            _this5.existingSourceExecutionToken = null;

            _this5.renderList(mentionChar, data, searchTerm);
          }, mentionChar);
        } else {
          if (this.existingSourceExecutionToken) {
            this.existingSourceExecutionToken.abandoned = true;
          }

          this.hideMentionList();
        }
      } else {
        if (this.existingSourceExecutionToken) {
          this.existingSourceExecutionToken.abandoned = true;
        }

        this.hideMentionList();
      }
    }
  }, {
    key: "getAllowedCharsRegex",
    value: function getAllowedCharsRegex(denotationChar) {
      if (this.options.allowedChars instanceof RegExp) {
        return this.options.allowedChars;
      } else {
        return this.options.allowedChars(denotationChar);
      }
    }
  }, {
    key: "onTextChange",
    value: function onTextChange(delta, oldDelta, source) {
      if (source === "user") {
        this.onSomethingChange();
      }
    }
  }, {
    key: "onSelectionChange",
    value: function onSelectionChange(range) {
      if (range && range.length === 0) {
        this.onSomethingChange();
      } else {
        this.hideMentionList();
      }
    }
  }, {
    key: "openMenu",
    value: function openMenu(denotationChar) {
      var selection = this.quill.getSelection(true);
      this.quill.insertText(selection.index, denotationChar);
      this.quill.blur();
      this.quill.focus();
    }
  }]);

  return Mention;
}();

quill__WEBPACK_IMPORTED_MODULE_0___default().register("modules/mention", Mention);


/***/ }),

/***/ 8529:
/*!**************************************************!*\
  !*** ./node_modules/frappe-gantt/src/gantt.scss ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ 5178:
/*!**************************************************************************!*\
  !*** ./src/app/pages/project-manage/project-manage.page.scss?ngResource ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --ion-color-rose: #fecdd3;\n  --ion-color-rose-rgb: 254,205,211;\n  --ion-color-rose-contrast: #000000;\n  --ion-color-rose-contrast-rgb: 0,0,0;\n  --ion-color-rose-shade: #e0b4ba;\n  --ion-color-rose-tint: #fed2d7;\n}\n\n.ion-color-rose {\n  --ion-color-base: var(--ion-color-rose);\n  --ion-color-base-rgb: var(--ion-color-rose-rgb);\n  --ion-color-contrast: var(--ion-color-rose-contrast);\n  --ion-color-contrast-rgb: var(--ion-color-rose-contrast-rgb);\n  --ion-color-shade: var(--ion-color-rose-shade);\n  --ion-color-tint: var(--ion-color-rose-tint);\n}\n\ndiv[slot=content] {\n  background: rgba(var(--ion-color-rose-rgb), 0.25);\n}\n\n.root {\n  display: flex;\n  flex-direction: column;\n  height: 100%;\n}\n\ntextarea {\n  width: 100%;\n  border: none;\n  font-size: 15px;\n  background: transparent;\n  border: none;\n  overflow: auto;\n  outline: none;\n  box-shadow: none;\n  resize: none; /*remove the resize handle on the bottom right*/\n}\n\n.app-name {\n  font-size: 28px;\n  font-family: \"Lato\", sans-serif;\n  font-weight: bold;\n}\n\n.has-gradient-text {\n  background: -webkit-linear-gradient(#13f7f4, #2af598);\n  -webkit-background-clip: text;\n  -webkit-text-fill-color: transparent;\n}\n\n.board {\n  display: flex;\n  flex-direction: column;\n  flex-grow: 1;\n  min-width: 0;\n  min-height: 0;\n}\n\n.board .board-bar {\n  background: rgba(128, 128, 128, 0.5);\n  padding: 8px 15px;\n}\n\n.board .board-bar .board-name {\n  font-size: 20px;\n  font-weight: bold;\n  color: white;\n}\n\n.board .board-wrapper {\n  display: flex;\n  flex-grow: 1;\n  overflow-x: auto;\n}\n\n.board .board-wrapper .board-columns {\n  display: flex;\n  flex-grow: 1;\n}\n\n.board .board-wrapper .board-columns .board-column {\n  display: flex;\n  flex-direction: column;\n  flex-grow: 1;\n  flex-basis: 0;\n  max-width: 300px;\n  margin: 0px 10px;\n  padding: 5px;\n  border-radius: 4px;\n  background: #161b22;\n}\n\n.board .board-wrapper .board-columns .board-column:not(:first-child) {\n  margin-left: 0;\n}\n\n.board .board-wrapper .board-columns .board-column .column-title {\n  font-size: 16px;\n  color: #fff;\n  font-weight: 800;\n  font-family: \"Lato\", sans-serif;\n  text-transform: uppercase;\n}\n\n.tasks-container {\n  flex-grow: 1;\n  overflow-y: auto;\n}\n\n.task {\n  background: #161b22;\n  color: #ccc;\n  border: 1px solid #4e4e4e;\n  border-radius: 10px;\n  overflow: hidden;\n  margin-bottom: 10px;\n  cursor: pointer;\n}\n\n.task:hover {\n  border: 1px solid #ccc;\n}\n\n.newTask {\n  color: #ccc;\n}\n\n.newTask ion-item {\n  --color: #ccc;\n  cursor: pointer;\n}\n\n.newTask ion-item:hover {\n  background: #161b22;\n  border-radius: 10px;\n}\n\n.cdk-drag-preview {\n  box-sizing: border-box;\n  border-radius: 10px;\n  color: #ccc;\n  border: 1px solid #0fbcf9;\n}\n\n.cdk-drag-placeholder {\n  opacity: 0;\n}\n\n.cdk-drag-animating {\n  transition: transform 250ms cubic-bezier(0, 0, 0.2, 1);\n}\n\n.tasks-container.cdk-drop-list-dragging .task:not(.cdk-drag-placeholder) {\n  transition: transform 250ms cubic-bezier(0, 0, 0.2, 1);\n}\n\nion-menu-button {\n  color: var(--ion-color-primary);\n}\n\n#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n\n.demo-chart {\n  width: 100%;\n  height: 300px;\n}\n\nion-grid {\n  --ion-grid-column-padding: 10px;\n  border-collapse: collapse;\n  border-style: hidden;\n  margin-top: 0px;\n  padding-top: 0px;\n}\n\nion-grid ion-row {\n  margin: 5px 0px;\n}\n\nion-grid ion-row:first-child {\n  background-color: #2980b9;\n  border-radius: 5px;\n  color: #fff;\n  font-weight: bold;\n}\n\nion-grid ion-col {\n  border-bottom: 0;\n  border-right: 0;\n}\n\nselect {\n  width: 100%;\n  padding: 7px;\n  background: var(--ion-color-gray);\n  color: #fff;\n  border: none;\n  outline: none;\n}\n\nselect:active,\nselect:hover {\n  outline: none;\n}\n\nselect:focus {\n  border-color: gray;\n  outline: none;\n}\n\n:host ::ng-deep .ngx-datatable .datatable-body .datatable-scroll {\n  display: inherit;\n}\n\n.odd {\n  background-color: #fff;\n  color: #222;\n  border-radius: 5px;\n}\n\n.even {\n  background-color: #fff;\n  border-radius: 5px;\n}\n\nion-item {\n  --background: transparent;\n}\n\nion-grid ion-col {\n  border-bottom: 0;\n  border-right: 0;\n  font-size: 14px;\n}\n\n.selected {\n  border: 0px solid #fff !important;\n  background-color: #fff;\n  color: #222;\n}\n\n.notSelected {\n  background-color: #161b22;\n  border: 0px solid #20bf6b !important;\n}\n\n.box {\n  background-color: #0d1116;\n  height: 50px;\n  border-bottom: 1px solid #fff;\n  border-top: 0.3px solid #0d1116;\n  line-height: 60px;\n  padding: 0px 10px;\n  font-size: 16px;\n}\n\n.colHeader {\n  background-color: #0d1116;\n  height: 70px;\n  border-bottom: 0.8px solid #000;\n  border-top: 0.8px solid #0d1116;\n  margin-bottom: 0.5px;\n}\n\n.box div:nth-child(even) {\n  fill: #161c22 !important;\n  stroke: #0d1116 !important;\n}\n\n.wrapper1,\n.wrapper2 {\n  border: none 0px RED;\n  overflow-x: scroll;\n  overflow-y: hidden;\n}\n\n.wrapper1 {\n  height: 20px;\n  margin-top: -10px;\n  position: sticky;\n  top: 0px;\n  z-index: 999999999;\n  background: #3d3d3d;\n}\n\n.wrapper2 {\n  height: 200px;\n}\n\n.div1 {\n  width: 25000px;\n  height: 20px;\n}\n\n.div2 {\n  width: 1000px;\n  height: 200px;\n  background-color: #88FF88;\n  overflow: auto;\n}\n\n.selected {\n  background-color: #34495e;\n  cursor: pointer;\n  margin-bottom: 5px;\n  color: #fff;\n  border-radius: 5px;\n}\n\n.notSelected {\n  cursor: pointer;\n  background-color: transparent;\n  color: #fff;\n  border: 0.5px solid rgb(101, 101, 101);\n  margin-bottom: 5px;\n  border-radius: 5px;\n}\n\n.notSelected ion-item {\n  color: #fff;\n}\n\n.scroll {\n  width: 200px;\n  height: 400px;\n  overflow: scroll;\n}\n\n.scroll::-webkit-scrollbar {\n  width: 12px;\n}\n\n.scroll::-webkit-scrollbar-track {\n  border-radius: 10px;\n}\n\n.scroll::-webkit-scrollbar-thumb {\n  background-color: #656565;\n  width: 3px;\n  border: 0.5px solid #656565;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2plY3QtbWFuYWdlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlCQUFBO0VBQ0EsaUNBQUE7RUFDQSxrQ0FBQTtFQUNBLG9DQUFBO0VBQ0EsK0JBQUE7RUFDQSw4QkFBQTtBQUNGOztBQUVBO0VBQ0UsdUNBQUE7RUFDQSwrQ0FBQTtFQUNBLG9EQUFBO0VBQ0EsNERBQUE7RUFDQSw4Q0FBQTtFQUNBLDRDQUFBO0FBQ0Y7O0FBRUE7RUFDRSxpREFBQTtBQUNGOztBQUtBO0VBQ0ksYUFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtBQUZKOztBQUtFO0VBQ0UsV0FBQTtFQUNFLFlBQUE7RUFDQSxlQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtFQUNBLGFBQUE7RUFJQSxnQkFBQTtFQUVBLFlBQUEsRUFBQSwrQ0FBQTtBQUpOOztBQVFFO0VBQ0UsZUFBQTtFQUNBLCtCQUFBO0VBQ0EsaUJBQUE7QUFMSjs7QUFRRTtFQUNFLHFEQUFBO0VBQ0EsNkJBQUE7RUFDQSxvQ0FBQTtBQUxKOztBQVNFO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtFQUlBLFlBQUE7RUFDQSxhQUFBO0FBVEo7O0FBV0k7RUFDSSxvQ0FBQTtFQUNBLGlCQUFBO0FBVFI7O0FBV1E7RUFDSSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0FBVFo7O0FBYUk7RUFDSSxhQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBWFI7O0FBYVE7RUFDSSxhQUFBO0VBQ0EsWUFBQTtBQVhaOztBQWFZO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUFYZDs7QUFhZ0I7RUFDSSxjQUFBO0FBWHBCOztBQWNnQjtFQUNJLGVBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSwrQkFBQTtFQUNBLHlCQUFBO0FBWnBCOztBQXFCRTtFQUNFLFlBQUE7RUFDQSxnQkFBQTtBQWxCSjs7QUFxQkU7RUFHRSxtQkFBQTtFQUNBLFdBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFFQSxtQkFBQTtFQUNBLGVBQUE7QUFyQko7O0FBMkJFO0VBQ0Usc0JBQUE7QUF4Qko7O0FBMkJFO0VBR0UsV0FBQTtBQTFCSjs7QUErQkk7RUFDRSxhQUFBO0VBQ0EsZUFBQTtBQTdCTjs7QUErQkk7RUFDRSxtQkFBQTtFQUNBLG1CQUFBO0FBN0JOOztBQWlDRTtFQUNFLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0VBQ0EseUJBQUE7QUE5Qko7O0FBb0NFO0VBQ0UsVUFBQTtBQWpDSjs7QUFvQ0U7RUFDRSxzREFBQTtBQWpDSjs7QUFvQ0U7RUFDRSxzREFBQTtBQWpDSjs7QUFzQ0U7RUFDRSwrQkFBQTtBQW5DSjs7QUFzQ0U7RUFDRSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSxRQUFBO0VBQ0EsMkJBQUE7QUFuQ0o7O0FBc0NFO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0FBbkNKOztBQXNDRTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxTQUFBO0FBbkNKOztBQXNDRTtFQUNFLHFCQUFBO0FBbkNKOztBQXNDRTtFQUNFLFdBQUE7RUFDQSxhQUFBO0FBbkNKOztBQXNDRTtFQUNFLCtCQUFBO0VBQ0EseUJBQUE7RUFDQSxvQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQW5DSjs7QUF1Q0k7RUFDRSxlQUFBO0FBckNOOztBQXdDSTtFQUNFLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7QUF0Q047O0FBeUNJO0VBRUUsZ0JBQUE7RUFDQSxlQUFBO0FBeENOOztBQW9ERTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsaUNBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUlBLGFBQUE7QUFwREo7O0FBd0RFOztFQUVFLGFBQUE7QUFyREo7O0FBd0RFO0VBQ0Usa0JBQUE7RUFDQSxhQUFBO0FBckRKOztBQXdERTtFQUNFLGdCQUFBO0FBckRKOztBQXdERTtFQUNFLHNCQUFBO0VBRUEsV0FBQTtFQUNBLGtCQUFBO0FBdERKOztBQXlERTtFQUNFLHNCQUFBO0VBRUEsa0JBQUE7QUF2REo7O0FBMERFO0VBQ0UseUJBQUE7QUF2REo7O0FBMERFO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsZUFBQTtBQXZESjs7QUEwREU7RUFDRSxpQ0FBQTtFQUNBLHNCQUFBO0VBQ0EsV0FBQTtBQXZESjs7QUEwREU7RUFDRSx5QkFBQTtFQUNBLG9DQUFBO0FBdkRKOztBQTBEQTtFQUNJLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLDZCQUFBO0VBQ0EsK0JBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtBQXZESjs7QUEwREE7RUFDSSx5QkFBQTtFQUNBLFlBQUE7RUFDQSwrQkFBQTtFQUNBLCtCQUFBO0VBQ0Esb0JBQUE7QUF2REo7O0FBMERBO0VBQ0ksd0JBQUE7RUFDQSwwQkFBQTtBQXZESjs7QUE4REE7O0VBR0ksb0JBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FBNURKOztBQStEQTtFQUNJLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsUUFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUE1REo7O0FBK0RBO0VBQ0ksYUFBQTtBQTVESjs7QUErREE7RUFDSSxjQUFBO0VBQ0EsWUFBQTtBQTVESjs7QUErREE7RUFDSSxhQUFBO0VBQ0EsYUFBQTtFQUNBLHlCQUFBO0VBQ0EsY0FBQTtBQTVESjs7QUFnRUE7RUFDSSx5QkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUdBLFdBQUE7RUFDQSxrQkFBQTtBQS9ESjs7QUFrRUU7RUFDRSxlQUFBO0VBQ0EsNkJBQUE7RUFDQSxXQUFBO0VBQ0Esc0NBQUE7RUFDQSxrQkFBQTtFQUVBLGtCQUFBO0FBaEVKOztBQWtFSTtFQUNFLFdBQUE7QUFoRU47O0FBb0VFO0VBQ0UsWUFBQTtFQUNBLGFBQUE7RUFDQSxnQkFBQTtBQWpFSjs7QUFtRUM7RUFDSSxXQUFBO0FBaEVMOztBQW1FQztFQUVJLG1CQUFBO0FBakVMOztBQW9FQztFQUVJLHlCQUFBO0VBQ0EsVUFBQTtFQUNBLDJCQUFBO0FBbEVMIiwiZmlsZSI6InByb2plY3QtbWFuYWdlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpyb290IHtcbiAgLS1pb24tY29sb3Itcm9zZTogI2ZlY2RkMztcbiAgLS1pb24tY29sb3Itcm9zZS1yZ2I6IDI1NCwyMDUsMjExO1xuICAtLWlvbi1jb2xvci1yb3NlLWNvbnRyYXN0OiAjMDAwMDAwO1xuICAtLWlvbi1jb2xvci1yb3NlLWNvbnRyYXN0LXJnYjogMCwwLDA7XG4gIC0taW9uLWNvbG9yLXJvc2Utc2hhZGU6ICNlMGI0YmE7XG4gIC0taW9uLWNvbG9yLXJvc2UtdGludDogI2ZlZDJkNztcbn1cblxuLmlvbi1jb2xvci1yb3NlIHtcbiAgLS1pb24tY29sb3ItYmFzZTogdmFyKC0taW9uLWNvbG9yLXJvc2UpO1xuICAtLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0taW9uLWNvbG9yLXJvc2UtcmdiKTtcbiAgLS1pb24tY29sb3ItY29udHJhc3Q6IHZhcigtLWlvbi1jb2xvci1yb3NlLWNvbnRyYXN0KTtcbiAgLS1pb24tY29sb3ItY29udHJhc3QtcmdiOiB2YXIoLS1pb24tY29sb3Itcm9zZS1jb250cmFzdC1yZ2IpO1xuICAtLWlvbi1jb2xvci1zaGFkZTogdmFyKC0taW9uLWNvbG9yLXJvc2Utc2hhZGUpO1xuICAtLWlvbi1jb2xvci10aW50OiB2YXIoLS1pb24tY29sb3Itcm9zZS10aW50KTtcbn1cblxuZGl2W3Nsb3Q9XCJjb250ZW50XCJdIHtcbiAgYmFja2dyb3VuZDogcmdiYSh2YXIoLS1pb24tY29sb3Itcm9zZS1yZ2IpLCAwLjI1KVxufVxuXG5cblxuXG4ucm9vdCB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIGhlaWdodDogMTAwJTtcbiAgfVxuICBcbiAgdGV4dGFyZWEgeyBcbiAgICB3aWR0aDogMTAwJTtcbiAgICAgIGJvcmRlcjogbm9uZTtcbiAgICAgIGZvbnQtc2l6ZTogMTVweDtcbiAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAgICAgYm9yZGVyOiBub25lO1xuICAgICAgb3ZlcmZsb3c6IGF1dG87XG4gICAgICBvdXRsaW5lOiBub25lO1xuICBcbiAgICAgIC13ZWJraXQtYm94LXNoYWRvdzogbm9uZTtcbiAgICAgIC1tb3otYm94LXNoYWRvdzogbm9uZTtcbiAgICAgIGJveC1zaGFkb3c6IG5vbmU7XG4gIFxuICAgICAgcmVzaXplOiBub25lOyAvKnJlbW92ZSB0aGUgcmVzaXplIGhhbmRsZSBvbiB0aGUgYm90dG9tIHJpZ2h0Ki9cbiAgXG4gIH1cbiAgXG4gIC5hcHAtbmFtZSB7XG4gICAgZm9udC1zaXplOiAyOHB4O1xuICAgIGZvbnQtZmFtaWx5OiAnTGF0bycsIHNhbnMtc2VyaWY7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIH1cbiAgXG4gIC5oYXMtZ3JhZGllbnQtdGV4dCB7XG4gICAgYmFja2dyb3VuZDogLXdlYmtpdC1saW5lYXItZ3JhZGllbnQoIzEzZjdmNCwgIzJhZjU5OCk7XG4gICAgLXdlYmtpdC1iYWNrZ3JvdW5kLWNsaXA6IHRleHQ7XG4gICAgLXdlYmtpdC10ZXh0LWZpbGwtY29sb3I6IHRyYW5zcGFyZW50O1xuICB9XG4gIFxuICBcbiAgLmJvYXJkIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgZmxleC1ncm93OiAxO1xuICBcbiAgICAvLyBPdmVycmlkZSBBdXRvbWF0aWMgTWluaW11bSBTaXplXG4gICAgLy8gaHR0cHM6Ly9zdGFja292ZXJmbG93LmNvbS9xdWVzdGlvbnMvMzYyNDcxNDAvd2h5LWRvbnQtZmxleC1pdGVtcy1zaHJpbmstcGFzdC1jb250ZW50LXNpemVcbiAgICBtaW4td2lkdGg6IDA7XG4gICAgbWluLWhlaWdodDogMDtcbiAgXG4gICAgLmJvYXJkLWJhciB7XG4gICAgICAgIGJhY2tncm91bmQ6IHJnYmEoZ3JheSwgMC41KTtcbiAgICAgICAgcGFkZGluZzogOHB4IDE1cHg7XG4gICAgXG4gICAgICAgIC5ib2FyZC1uYW1lIHtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICAgICAgY29sb3I6IHdoaXRlO1xuICAgICAgICB9XG4gICAgfVxuICBcbiAgICAuYm9hcmQtd3JhcHBlciB7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGZsZXgtZ3JvdzogMTtcbiAgICAgICAgb3ZlcmZsb3cteDogYXV0bztcbiAgXG4gICAgICAgIC5ib2FyZC1jb2x1bW5zIHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBmbGV4LWdyb3c6IDE7XG4gIFxuICAgICAgICAgICAgLmJvYXJkLWNvbHVtbiB7XG4gICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgICAgICAgICAgIGZsZXgtZ3JvdzogMTtcbiAgICAgICAgICAgICAgZmxleC1iYXNpczogMDtcbiAgICAgICAgICAgICAgbWF4LXdpZHRoOiAzMDBweDtcbiAgICAgICAgICAgICAgbWFyZ2luOiAwcHggMTBweDtcbiAgICAgICAgICAgICAgcGFkZGluZzogNXB4O1xuICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA0cHg7XG4gICAgICAgICAgICAgIGJhY2tncm91bmQ6ICMxNjFiMjI7XG4gIFxuICAgICAgICAgICAgICAgICY6bm90KDpmaXJzdC1jaGlsZCkge1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogMDtcbiAgICAgICAgICAgICAgICB9XG4gIFxuICAgICAgICAgICAgICAgIC5jb2x1bW4tdGl0bGUge1xuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgICAgICAgICAgICAgICBmb250LXdlaWdodDogODAwO1xuICAgICAgICAgICAgICAgICAgICBmb250LWZhbWlseTogJ0xhdG8nLCBzYW5zLXNlcmlmO1xuICAgICAgICAgICAgICAgICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICAgICAgICAgICAgICAgICAgICAvLyBtYXJnaW4tYm90dG9tOiAyMHB4O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgfVxuICBcbiAgXG4gIC50YXNrcy1jb250YWluZXIge1xuICAgIGZsZXgtZ3JvdzogMTtcbiAgICBvdmVyZmxvdy15OiBhdXRvOyBcbiAgfVxuICBcbiAgLnRhc2sge1xuICAgIC8vIGRpc3BsYXk6IGZsZXg7XG4gICAgLy8gcGFkZGluZzogMHB4IDVweDtcbiAgICBiYWNrZ3JvdW5kOiAjMTYxYjIyO1xuICAgIGNvbG9yOiAjY2NjO1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICAjNGU0ZTRlO1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgXG4gICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIFxuICAgIC8vIGJveC1zaGFkb3c6IDAgNXB4IDVweCAtM3B4IHJnYmEoMCwgMCwgMCwgMC4wNSksXG4gICAgLy8gMCAzcHggMTRweCAycHggcmdiYSgwLCAwLCAwLCAwLjA1KTtcbiAgfVxuICBcbiAgLnRhc2s6aG92ZXIge1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICAjY2NjO1xuICB9XG4gIFxuICAubmV3VGFzayB7XG4gICAgLy8gZGlzcGxheTogZmxleDtcbiAgICAvLyBwYWRkaW5nOiAxNXB4IDEycHg7XG4gICAgY29sb3I6ICNjY2M7XG4gICAgLy8gYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICAvLyB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgLy8gbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgXG4gICAgaW9uLWl0ZW0ge1xuICAgICAgLS1jb2xvcjogI2NjYztcbiAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICB9XG4gICAgaW9uLWl0ZW06aG92ZXIge1xuICAgICAgYmFja2dyb3VuZDogIzE2MWIyMjtcbiAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgfVxuICB9XG4gIFxuICAuY2RrLWRyYWctcHJldmlldyB7XG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIGNvbG9yOiAjY2NjO1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICMwZmJjZjk7XG4gICAgLy8gYm94LXNoYWRvdzogMCA1cHggNXB4IC0zcHggcmdiYSgwLCAwLCAwLCAwLjIpLFxuICAgIC8vICAgICAgICAgICAgIDAgOHB4IDEwcHggMXB4IHJnYmEoMCwgMCwgMCwgMC4xNCksXG4gICAgLy8gICAgICAgICAgICAgMCAzcHggMTRweCAycHggcmdiYSgwLCAwLCAwLCAwLjEyKTtcbiAgfVxuICBcbiAgLmNkay1kcmFnLXBsYWNlaG9sZGVyIHtcbiAgICBvcGFjaXR5OiAwO1xuICB9XG4gIFxuICAuY2RrLWRyYWctYW5pbWF0aW5nIHtcbiAgICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMjUwbXMgY3ViaWMtYmV6aWVyKDAsIDAsIDAuMiwgMSk7XG4gIH1cbiAgXG4gIC50YXNrcy1jb250YWluZXIuY2RrLWRyb3AtbGlzdC1kcmFnZ2luZyAudGFzazpub3QoLmNkay1kcmFnLXBsYWNlaG9sZGVyKSB7XG4gICAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDI1MG1zIGN1YmljLWJlemllcigwLCAwLCAwLjIsIDEpO1xuICB9XG4gIFxuICBcbiAgXG4gIGlvbi1tZW51LWJ1dHRvbiB7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgfVxuICBcbiAgI2NvbnRhaW5lciB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBsZWZ0OiAwO1xuICAgIHJpZ2h0OiAwO1xuICAgIHRvcDogNTAlO1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNTAlKTtcbiAgfVxuICBcbiAgI2NvbnRhaW5lciBzdHJvbmcge1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBsaW5lLWhlaWdodDogMjZweDtcbiAgfVxuICBcbiAgI2NvbnRhaW5lciBwIHtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgbGluZS1oZWlnaHQ6IDIycHg7XG4gICAgY29sb3I6ICM4YzhjOGM7XG4gICAgbWFyZ2luOiAwO1xuICB9XG4gIFxuICAjY29udGFpbmVyIGEge1xuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbiAgfVxuICBcbiAgLmRlbW8tY2hhcnQge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogMzAwcHg7XG4gIH1cbiAgXG4gIGlvbi1ncmlkIHtcbiAgICAtLWlvbi1ncmlkLWNvbHVtbi1wYWRkaW5nOiAxMHB4O1xuICAgIGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7XG4gICAgYm9yZGVyLXN0eWxlOiBoaWRkZW47XG4gICAgbWFyZ2luLXRvcDogMHB4O1xuICAgIHBhZGRpbmctdG9wOiAwcHg7XG4gICAgLy8gcGFkZGluZzogMTBweDtcbiAgICAvLyBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICBcbiAgICBpb24tcm93IHtcbiAgICAgIG1hcmdpbjogNXB4IDBweDtcbiAgICB9XG4gIFxuICAgIGlvbi1yb3c6Zmlyc3QtY2hpbGQge1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjogIzI5ODBiOTtcbiAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgfVxuICBcbiAgICBpb24tY29sIHtcbiAgICAgIC8vIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XG4gICAgICBib3JkZXItYm90dG9tOiAwO1xuICAgICAgYm9yZGVyLXJpZ2h0OiAwO1xuICAgIH1cbiAgXG4gICAgLy8gaW9uLWNvbDpsYXN0LWNoaWxkIHtcbiAgICAgIC8vIGJvcmRlci1yaWdodDogMXB4IHNvbGlkIGJsYWNrO1xuICAgIC8vIH1cbiAgXG4gICAgLy8gaW9uLXJvdzpsYXN0LWNoaWxkIHtcbiAgICAgIC8vIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBibGFjaztcbiAgICAvLyB9XG4gIH1cbiAgICBcbiAgc2VsZWN0IHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBwYWRkaW5nOiA3cHg7XG4gICAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWdyYXkpOyBcbiAgICBjb2xvcjogI2ZmZjsgXG4gICAgYm9yZGVyOiBub25lO1xuICAgIC8vIGJvcmRlcjogMC41cHggc29saWQgcmdiKDgzLCA4MywgODMpO1xuICAgIC8vIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgLy8gYm94LXNoYWRvdzogMCAwIDEwcHggMTAwcHggI2ZmZiBpbnNldDtcbiAgICBvdXRsaW5lOiBub25lO1xuXG4gIH1cbiAgXG4gIHNlbGVjdDphY3RpdmUsXG4gIHNlbGVjdDpob3ZlciB7XG4gICAgb3V0bGluZTogbm9uZVxuICB9XG4gIFxuICBzZWxlY3Q6Zm9jdXMge1xuICAgIGJvcmRlci1jb2xvcjogZ3JheTtcbiAgICBvdXRsaW5lOiBub25lO1xuICB9XG4gIFxuICA6aG9zdCA6Om5nLWRlZXAgLm5neC1kYXRhdGFibGUgLmRhdGF0YWJsZS1ib2R5IC5kYXRhdGFibGUtc2Nyb2xsIHtcbiAgICBkaXNwbGF5OiBpbmhlcml0O1xuICB9XG4gIFxuICAub2RkIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICAgIC8vIGJveC1zaGFkb3c6IDAgMXB4IDJweCAwIHJnYig2MCA2NCA2NyAvIDMwJSksIDAgMXB4IDNweCAxcHggcmdiKDYwIDY0IDY3IC8gMTUlKTtcbiAgICBjb2xvcjogIzIyMjtcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIH1cbiAgXG4gIC5ldmVuIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICAgIC8vIGJveC1zaGFkb3c6IDAgMXB4IDJweCAwIHJnYig2MCA2NCA2NyAvIDMwJSksIDAgMXB4IDNweCAxcHggcmdiKDYwIDY0IDY3IC8gMTUlKTtcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIH1cbiAgXG4gIGlvbi1pdGVtIHtcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICB9XG4gIFxuICBpb24tZ3JpZCBpb24tY29sIHtcbiAgICBib3JkZXItYm90dG9tOiAwO1xuICAgIGJvcmRlci1yaWdodDogMDtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gIH1cbiAgXG4gIC5zZWxlY3RlZCB7XG4gICAgYm9yZGVyOiAwcHggc29saWQgI2ZmZiAhaW1wb3J0YW50O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gICAgY29sb3I6ICMyMjI7XG4gIH1cbiAgXG4gIC5ub3RTZWxlY3RlZCB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzE2MWIyMjtcbiAgICBib3JkZXI6IDBweCBzb2xpZCAjMjBiZjZiICFpbXBvcnRhbnQ7XG4gIH1cblxuLmJveCB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzBkMTExNjtcbiAgICBoZWlnaHQ6IDUwcHg7XG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNmZmY7XG4gICAgYm9yZGVyLXRvcDogMC4zcHggc29saWQgIzBkMTExNjtcbiAgICBsaW5lLWhlaWdodDogNjBweDtcbiAgICBwYWRkaW5nOiAwcHggMTBweDtcbiAgICBmb250LXNpemU6IDE2cHg7XG59XG5cbi5jb2xIZWFkZXIge1xuICAgIGJhY2tncm91bmQtY29sb3I6ICMwZDExMTY7XG4gICAgaGVpZ2h0OiA3MHB4O1xuICAgIGJvcmRlci1ib3R0b206IDAuOHB4IHNvbGlkICMwMDA7XG4gICAgYm9yZGVyLXRvcDogMC44cHggc29saWQgIzBkMTExNjtcbiAgICBtYXJnaW4tYm90dG9tOiAwLjVweDtcbn1cblxuLmJveCBkaXY6bnRoLWNoaWxkKGV2ZW4pIHtcbiAgICBmaWxsOiAjMTYxYzIyICFpbXBvcnRhbnQ7XG4gICAgc3Ryb2tlOiAjMGQxMTE2ICFpbXBvcnRhbnQ7XG59XG5cbi5nYW50dFRlc3Qge1xuICAgIC8vIHBvaW50ZXItZXZlbnRzOiBub25lO1xufVxuXG4ud3JhcHBlcjEsXG4ud3JhcHBlcjIge1xuICAgIC8vIHdpZHRoOiAzMDBweDtcbiAgICBib3JkZXI6IG5vbmUgMHB4IFJFRDtcbiAgICBvdmVyZmxvdy14OiBzY3JvbGw7XG4gICAgb3ZlcmZsb3cteTogaGlkZGVuO1xufVxuXG4ud3JhcHBlcjEge1xuICAgIGhlaWdodDogMjBweDtcbiAgICBtYXJnaW4tdG9wOiAtMTBweDtcbiAgICBwb3NpdGlvbjogc3RpY2t5O1xuICAgIHRvcDogMHB4O1xuICAgIHotaW5kZXg6IDk5OTk5OTk5OTtcbiAgICBiYWNrZ3JvdW5kOiAjM2QzZDNkO1xufVxuXG4ud3JhcHBlcjIge1xuICAgIGhlaWdodDogMjAwcHg7XG59XG5cbi5kaXYxIHtcbiAgICB3aWR0aDogMjUwMDBweDtcbiAgICBoZWlnaHQ6IDIwcHg7XG59XG5cbi5kaXYyIHtcbiAgICB3aWR0aDogMTAwMHB4O1xuICAgIGhlaWdodDogMjAwcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzg4RkY4ODtcbiAgICBvdmVyZmxvdzogYXV0bztcbn1cblxuXG4uc2VsZWN0ZWQge1xuICAgIGJhY2tncm91bmQtY29sb3I6ICMzNDQ5NWU7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIG1hcmdpbi1ib3R0b206IDVweDtcbiAgICAvLyBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2NjYztcbiAgICAvLyBib3gtc2hhZG93OiAwIDFweCAycHggMCByZ2IoNjAgNjQgNjcgLyAzMCUpLCAwIDFweCAzcHggMXB4IHJnYig2MCA2NCA2NyAvIDE1JSk7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICB9XG4gIFxuICAubm90U2VsZWN0ZWQge1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICBib3JkZXI6IDAuNXB4IHNvbGlkIHJnYigxMDEsIDEwMSwgMTAxKTtcbiAgICBtYXJnaW4tYm90dG9tOiA1cHg7XG4gICAgLy8gYm94LXNoYWRvdzogMCAxcHggMnB4IDAgcmdiKDYwIDY0IDY3IC8gMzAlKSwgMCAxcHggM3B4IDFweCByZ2IoNjAgNjQgNjcgLyAxNSUpO1xuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgXG4gICAgaW9uLWl0ZW0ge1xuICAgICAgY29sb3I6ICNmZmY7XG4gICAgfVxuICB9XG5cbiAgLnNjcm9sbCB7XG4gICAgd2lkdGg6IDIwMHB4O1xuICAgIGhlaWdodDogNDAwcHg7XG4gICAgb3ZlcmZsb3c6IHNjcm9sbDtcbiB9XG4gLnNjcm9sbDo6LXdlYmtpdC1zY3JvbGxiYXIge1xuICAgICB3aWR0aDogMTJweDtcbiB9XG4gXG4gLnNjcm9sbDo6LXdlYmtpdC1zY3JvbGxiYXItdHJhY2sge1xuICAgIC8vICAtd2Via2l0LWJveC1zaGFkb3c6IGluc2V0IDAgMCA2cHggcmdiYSgwLDAsMCwwLjMpOyBcbiAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiB9XG4gXG4gLnNjcm9sbDo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xuICAgIC8vICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjNjU2NTY1O1xuICAgICB3aWR0aDogM3B4O1xuICAgICBib3JkZXI6IDAuNXB4IHNvbGlkICM2NTY1NjU7XG4gICAgLy8gIC13ZWJraXQtYm94LXNoYWRvdzogaW5zZXQgMCAwIDZweCByZ2JhKDI1NSwgMCwgMCk7IFxuIH0iXX0= */";

/***/ }),

/***/ 4883:
/*!**************************************************************************!*\
  !*** ./src/app/pages/project-manage/project-manage.page.html?ngResource ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar color=\"gray\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>SpotYourDeal</ion-title>\n  </ion-toolbar>\n  <ion-toolbar color=\"gray\">\n    <ion-segment [(ngModel)]=\"segment\">\n      <ion-segment-button value=\"roadmap\">\n        <ion-text>\n          Roadmap\n        </ion-text>\n      </ion-segment-button>\n      <ion-segment-button value='backlog'>\n        <ion-text>\n          Backlog\n        </ion-text>\n      </ion-segment-button>\n      <ion-segment-button value='board'>\n        <ion-text>\n          Board\n        </ion-text>\n      </ion-segment-button>\n      <ion-segment-button value='notes'>\n        <ion-text>\n          Notes\n        </ion-text>\n      </ion-segment-button>\n      <ion-segment-button value='members'>\n        <ion-text>\n          Members\n        </ion-text>\n      </ion-segment-button>\n    </ion-segment>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div style=\"height: 100%;\" [style.display]=\"segment == 'roadmap' ? 'block' : 'none'\">\n    <ion-row style=\"height: 100%;\">\n      <ion-col size=\"2.5\" style=\"padding-right: 0px;border-right: 0.5px solid #747474;\">\n        <div class=\"colHeader\">\n          <ion-item lines=\"none\">\n            <ion-label style=\"color: #ccc;\">\n              <!-- Members -->\n            </ion-label>\n            <ion-icon (click)=\"addEpic()\" slot=\"end\" name=\"add\">\n            </ion-icon>\n            <ion-icon slot=\"end\" name=\"options\">\n            </ion-icon>\n          </ion-item>\n        </div>\n        <div class=\"box\" *ngFor=\"let epic of projectEpics\">\n          <ion-item lines=\"none\">\n            <ion-icon slot=\"start\" name=\"flash\" style=\"color:#575fcf;margin-left: -20px;\">\n            </ion-icon>\n            <ion-label style=\"color: #ccc;height: 30px;line-height: 30px;cursor: pointer;\" (click)=\"viewEpicDetails(epic)\">\n              {{epic.name}}\n            </ion-label>\n          </ion-item>\n        </div>\n      </ion-col>\n      <ion-col size=\"9.5\" style=\"padding-left: 0px;\">\n        <div class=\"wrapper1\" id=\"topScroller\">\n          <div class=\"div1\" [style.width]=\"ganttWidth+'px'\"></div>\n        </div>\n        <svg id=\"gantt\" style=\"min-height: 100%\" [ngClass]=\"1 == 1 ? 'ganttTest': 'null'\"></svg>\n      </ion-col>\n    </ion-row>\n  </div>\n  <div *ngIf=\"segment == 'backlog'\">\n    <ion-row style=\"height: 100%;\">\n      <ion-col size=\"2.5\" style=\"padding-right: 0px;border-right: 0.5px solid #747474;overflow-y:scroll\"\n        [style.height]=\"windowHeight\" class=\"scroll\">\n        <!-- [style.overflow-y]=\"windowHeight > 0? 'scroll': 'hidden'\"  -->\n        <ion-row>\n          <ion-col size=\"12\">\n            <ion-item lines=\"none\">\n              <ion-label style=\"color: #ccc;\">\n                Epics\n              </ion-label>\n              <ion-button (click)=\"addEpic()\" slot=\"end\" fill=\"clear\">\n                <ion-icon name=\"add\" color=\"dark\"></ion-icon>\n              </ion-button>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngFor=\"let epic of projectEpics; index as i\" style=\"margin-left: 10px;\">\n          <ion-col size=\"12\" style=\"padding: 0px;\" [ngClass]=\"(i == selectedEpicIndex) ? 'selected' : 'notSelected'\">\n            <ion-item lines=\"none\">\n              <ion-icon slot=\"start\" name=\"flash\" style=\"margin-left: -10px;margin-right: 5px;\" color=\"tertiary\" (click)=\"selectEpic(epic, i)\">\n              </ion-icon>\n              <ion-label class=\"ion-text-wrap\" style=\"color: #fff;\" (click)=\"selectEpic(epic, i)\">\n                {{epic.name}}\n              </ion-label>\n              <ion-icon slot=\"end\" name=\"ellipsis-vertical-outline\" style=\"margin-right: -5px;font-size: 20px;\" (click)=\"viewEpicDetails(epic)\">\n              </ion-icon>\n            </ion-item>\n            <ion-progress-bar value=\"0.3\" color=\"tertiary\"></ion-progress-bar>\n          </ion-col>\n        </ion-row>\n      </ion-col>\n      <ion-col size=\"2.5\" style=\"padding-right: 0px;border-right: 0.5px solid #747474;overflow-y:scroll\"\n        [style.height]=\"windowHeight\" class=\"scroll\">\n        <!-- [style.overflow-y]=\"windowHeight > 0? 'scroll': 'hidden'\"  -->\n        <ion-row>\n          <ion-col size=\"12\">\n            <ion-item lines=\"none\">\n              <ion-label style=\"color: #ccc;\">\n                Stories\n              </ion-label>\n              <ion-button (click)=\"addStory()\" slot=\"end\" fill=\"clear\">\n                <ion-icon name=\"add\" color=\"dark\"></ion-icon>\n              </ion-button>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngFor=\"let story of epicStories; index as i\" style=\"margin: 0px 10px;\">\n          <ion-col size=\"12\" style=\"padding: 0px;\" [ngClass]=\"(i == selectedStoryIndex) ? 'selected' : 'notSelected'\">\n            <ion-item lines=\"none\" (click)=\"selectStory(story, i)\">\n              <ion-icon slot=\"start\" name=\"bookmark\" style=\"margin-left: -10px;margin-right: 5px;\" color=\"success\">\n              </ion-icon>\n              <ion-label class=\"ion-text-wrap\" style=\"color: #fff;\">\n                {{story.name}}\n              </ion-label>\n              <ion-icon slot=\"end\" name=\"ellipsis-vertical-outline\" style=\"margin-right: -5px;font-size: 20px;\" (click)=\"viewStoryDetails(story)\">\n              </ion-icon>\n            </ion-item>\n            <ion-progress-bar value=\"0.3\" color=\"success\"></ion-progress-bar>\n          </ion-col>\n        </ion-row>\n      </ion-col>\n      <ion-col size=\"7\" style=\"padding-right: 0px;border-right: 0.5px solid #747474;overflow-y:scroll\"\n        [style.height]=\"windowHeight\" class=\"scroll\">\n        <!-- [style.overflow-y]=\"windowHeight > 0? 'scroll': 'hidden'\"  -->\n        <ion-row>\n          <ion-col size=\"12\">\n            <ion-item lines=\"none\">\n              <ion-label style=\"color: #ccc;\">\n                Tasks\n              </ion-label>\n              <ion-button (click)=\"addStoryTask()\" slot=\"end\" fill=\"clear\">\n                <ion-icon name=\"add\" color=\"dark\"></ion-icon>\n              </ion-button>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngFor=\"let task of storyTasks; index as i\" style=\"margin: 0px 10px;\">\n          <ion-col size=\"12\" style=\"padding: 0px;\">\n            <ion-item lines=\"none\" style=\"border-bottom: 0.5px solid rgb(102, 102, 102);\">\n              <ion-icon slot=\"start\" name=\"checkbox\" style=\"margin-left: -10px;margin-right: 5px;\" color=\"secondary\">\n              </ion-icon>\n              <ion-label class=\"ion-text-wrap\" style=\"color: #fff;font-weight: 600;\">\n                {{task.taskName}}\n              </ion-label>\n              <ion-avatar slot=\"end\">\n                <img\n                  [src]=\"getAssigneeDetails(task, 'image') || 'https://t3.ftcdn.net/jpg/03/46/83/96/360_F_346839683_6nAPzbhpSkIpb8pmAwufkC7c5eD7wYws.jpg'\">\n              </ion-avatar>\n              <ion-icon slot=\"end\" name=\"ellipsis-vertical-outline\" style=\"margin-right: -5px;font-size: 20px;\" (click)=\"viewTaskDetails(task)\">\n              </ion-icon>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n      </ion-col>\n      <!-- <ion-col size=\"7.5\" style=\"padding-left: 0px;\">\n\n      </ion-col> -->\n    </ion-row>\n  </div>\n  <div *ngIf=\"segment == 'board'\">\n    <div class=\"root\">\n\n      <div class=\"board\">\n\n        <div class=\"board-wrapper\">\n\n          <div class=\"board-columns\" cdkDropListGroup>\n            <div class=\"board-column\" *ngFor=\"let column of teamBoardColumns; let c = index;\" #boards id=\"boards\"\n              style=\"background: #0d1116;\">\n\n              <div class=\"column-title\" style=\"position: sticky;top:0px\">\n                <ion-item lines=\"none\" (click)=\"addTask()\" style=\"background: #161b22;\">\n                  <ion-label style=\"color: #fff;font-size: 16px;\">\n                    {{ column.columnName }}\n                  </ion-label>\n                </ion-item>\n              </div>\n\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n\n    <ion-accordion-group [value]=\"k\" [multiple]=\"true\" style=\"margin-bottom: 5px;\" *ngFor=\"let story of epicStories;let k = index\">\n      <ion-accordion [value]=\"k\">\n        <ion-item slot=\"header\" lines=\"none\" color=\"gray\">\n          <ion-icon slot=\"start\" name=\"bookmark\" style=\"margin-left: -10px;margin-right: 5px;\" color=\"success\">\n          </ion-icon>\n          <ion-label style=\"font-size: 18px !important;\">{{story.name}}</ion-label>\n        </ion-item>\n        <div slot=\"content\" style=\"margin-bottom: 20px;\">\n\n          <div class=\"root\">\n            <div class=\"board\">\n              <div class=\"board-wrapper\">\n\n                <div class=\"board-columns\" cdkDropListGroup>\n                  <div class=\"board-column\" *ngFor=\"let column of story.columnTasks; let c = index;\">\n\n                    <div class=\"tasks-container\" cdkDropList id=\"{{column.columnId}}\" [cdkDropListData]=\"column.tasks\"\n                      (cdkDropListDropped)=\"drop($event)\">\n                      <div class=\"task\" *ngFor=\"let item of column.tasks; let i = index;\" cdkDrag\n                        [style.border]=\"item.status == '1'? '1px solid green': ''\">\n                        <ion-item lines=\"none\" style=\"background: var(--ion-color-gray);border-radius: 0px;\">\n                          <!-- <ion-icon slot=\"start\" color=\"dark\" style=\"font-size:20px\" cdkDragHandle name=\"apps-outline\">\n                  </ion-icon> -->\n                          <ion-avatar slot=\"start\" (click)=\"assignTaskOverlay(item,i)\" cdkOverlayOrigin #trigger=\"cdkOverlayOrigin\">\n                            <img\n                              [src]=\"getAssigneeDetails(item, 'image') || 'https://t3.ftcdn.net/jpg/03/46/83/96/360_F_346839683_6nAPzbhpSkIpb8pmAwufkC7c5eD7wYws.jpg'\">\n                          </ion-avatar>\n                          <ng-template *ngIf=\"i == item.index\" cdkConnectedOverlay [cdkConnectedOverlayOrigin]=\"trigger\"\n                          [cdkConnectedOverlayOpen]=\"item.isOpen\" (overlayOutsideClick)=\"item.isOpen = false\">\n                          <div class=\"example-overlay\">\n                            <ion-item lines=\"none\">\n                              <ion-label style=\"color: #ccc;\">\n                                Assignee\n                              </ion-label>\n                              <ion-icon name=\"close\" (click)=\"item.isOpen = !item.isOpen\">\n\n                              </ion-icon>\n                            </ion-item>\n                            <ion-toolbar color=\"gray\">\n                              <ion-searchbar placeholder=\"Search Name\" debounce=\"1000\">\n                              </ion-searchbar>\n                            </ion-toolbar>\n                            <ion-row *ngFor=\"let user of projectMembers; index as i\" [ngClass]=\"(i % 2 == 0) ? 'odd' : 'even'\" style=\"background: #252628; border-radius: 10px;margin: 10px;\" (click)=\"assignTask(item, user)\">\n                              <ion-item lines=\"none\" style=\"width: 100%;cursor: pointer;\">\n                                <ion-avatar slot=\"start\">\n                                  <img\n                                    [src]=\"user.image\">\n                                </ion-avatar>\n                                <ion-label style=\"color: #fff;\">\n                                  {{user.firstName || ''}} {{user.lastName || ''}}\n                                </ion-label>\n                              </ion-item>\n                            </ion-row>\n                          </div>\n                        </ng-template>\n\n                          <ion-label style=\"color: #4bcffa;\" cdkDragHandle>\n                            {{getAssigneeDetails(item, 'firstName')}} \n                            <!-- {{getAssigneeDetails(item, 'lastName')}} -->\n                          </ion-label>\n                          <ion-note slot=\"end\" style=\"font-size: 12px;font-weight: bold;\" color=\"warning\">\n                            {{item.dueDate | date:'dd MMM'}}\n                          </ion-note>\n                          <ion-icon slot=\"end\" name=\"checkmark-circle-outline\" (click)=\"updateTaskStatus(item)\" [color]=\"item.status? 'success': 'light'\">\n                          </ion-icon>\n\n                        </ion-item>\n\n                        <div style=\"width: 100%;padding: 10px;font-size: 16px;color: #fff;font-weight: 200;\"\n                          (click)=\"viewTaskDetails(item)\" cdkDragHandle>\n                          {{item.taskName}}\n                        </div>\n                      </div>\n                    </div>\n\n                  </div>\n                </div>\n              </div>\n            </div>\n          </div>\n        </div>\n      </ion-accordion>\n    </ion-accordion-group>\n  </div>\n  <div *ngIf=\"segment == 'notes'\">\n    <quill-editor [styles]=\"{height: '100%'}\" placeholder=\"Enter Text\" [modules]=\"quillConfig\"></quill-editor>\n  </div>\n  <div *ngIf=\"segment == 'members'\">\n\n\n  <ion-row>\n    <ion-col sizeLg=\"10\" offsetLg=\"1\" *ngIf=\"segment=='members'\">\n      <div>\n        <ion-row *ngFor=\"let user of projectMembers; index as i\" [ngClass]=\"(i % 2 == 0) ? 'odd' : 'even'\" style=\"background: #161b22;\n        border-radius: 10px;margin: 10px;\">\n          <!-- <ion-item lines=\"none\" style=\"width: 100%;\"> -->\n          <!-- <ion-row> -->\n          <ion-col size=\"3\" style=\"border-right: 1px solid rgb(63 68 73)\">\n            <ion-item lines=\"none\" style=\"width: 100%;\">\n              <ion-avatar slot=\"start\">\n                <img\n                  [src]=\"user.image\">\n              </ion-avatar>\n              <ion-label style=\"color: #fff;\">\n                {{user.firstName}} {{user.lastName}}\n              </ion-label>\n            </ion-item>\n          </ion-col>\n          <ion-col size=\"2\" style=\"border-right: 1px solid rgb(63 68 73)\">\n            <ion-item lines=\"none\" style=\"width: 100%;\">\n              <ion-checkbox style=\"color: #fff;\" [(ngModel)]=\"user.billable\"></ion-checkbox>\n              <ion-label style=\"color: #fff;\">Billable</ion-label>\n            </ion-item>\n          </ion-col>\n          <ion-col size=\"2\" style=\"border-right: 1px solid rgb(63 68 73)\">\n            <ion-item lines=\"none\" style=\"width: 100%;\">\n              <ion-input type=\"number\" placeholder=\"Hrs Assigned\" [(ngModel)]=\"user.hoursAssign\" style=\"border: none;background: #161b22;\"></ion-input>\n            </ion-item>\n          </ion-col>\n          <ion-col size=\"4\" style=\"border-right: 1px solid rgb(63 68 73)\">\n            <ion-select style=\"color: #fff;\" interface=\"popover\" [(ngModel)]=\"user.type\"\n            placeholder=\"Select Role\">\n            <ion-select-option value=\"Frontend\">Frontend Developer</ion-select-option>\n            <ion-select-option value=\"Backend\">Backend Developer</ion-select-option>\n            <ion-select-option value=\"Functional\">Functional Consultant</ion-select-option>\n            <ion-select-option value=\"Tester\">Tester</ion-select-option>\n            <ion-select-option value=\"Manager\">Project Manager</ion-select-option>\n          </ion-select>\n            </ion-col>\n          <!-- <ion-col size=\"1\">\n            <ion-item lines=\"none\" style=\"width: 100%;\">\n              <ion-button *ngIf=\"checkInTeam(user)\" slot=\"end\" fill=\"clear\" (click)=\"addEmployeeTeam(user)\">\n                <ion-icon color=\"success\" name=\"add\"></ion-icon>\n              </ion-button>\n              <ion-button *ngIf=\"!checkInTeam(user)\" slot=\"end\" fill=\"clear\" (click)=\"removeProjectMember(user)\">\n                <ion-icon color=\"danger\" name=\"close\"></ion-icon>\n              </ion-button>\n            </ion-item>\n          </ion-col> -->\n        </ion-row>\n        <!-- </ion-item> -->\n        <!-- </ion-row> -->\n      </div>\n    </ion-col>\n  </ion-row>\n</div>\n</ion-content>\n<ion-footer *ngIf=\"segment == 'board'\">\n  <ion-toolbar color=\"gray\">\n    <ion-buttons slot=\"start\">\n      <ion-button color=\"dark\" (click)=\"toggleMenuButton()\">\n        <ion-icon *ngIf=\"toggleMenu\" name=\"arrow-back-circle-outline\"></ion-icon>\n        <ion-icon *ngIf=\"!toggleMenu\" name=\"arrow-forward-circle-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n      <ion-button color=\"gray\">\n        <ion-icon name=\"arrow-back-circle-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    \n    <ion-avatar slot=\"end\" style=\"height: 40px;width: 40px;padding: 2px;margin: 2px;cursor: pointer;\" *ngFor=\"let member of projectMembers\" (click)=\"selectMemberTasks(member)\" [style.border]=\"member.selected ? '2px solid red': '0px solid red'\">\n      <img\n        [src]=\"member.image\" [title]=\"member.firstName\">\n    </ion-avatar>\n\n  </ion-toolbar>\n</ion-footer>\n<ion-footer *ngIf=\"segment == 'roadmap'\">\n  <ion-toolbar color=\"gray\">\n    <ion-buttons slot=\"start\">\n      <ion-button color=\"dark\" (click)=\"toggleMenuButton()\">\n        <ion-icon *ngIf=\"toggleMenu\" name=\"arrow-back-circle-outline\"></ion-icon>\n        <ion-icon *ngIf=\"!toggleMenu\" name=\"arrow-forward-circle-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n      <ion-button color=\"gray\">\n        <ion-icon name=\"arrow-back-circle-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-segment [(ngModel)]=\"ganttMode\" (ngModelChange)=\"change_view_mode(ganttMode)\">\n      <ion-segment-button value=\"Day\">\n        <ion-text>\n          Day\n        </ion-text>\n      </ion-segment-button>\n      <ion-segment-button value=\"Week\">\n        <ion-text>\n          Week\n        </ion-text>\n      </ion-segment-button>\n      <ion-segment-button value=\"Month\">\n        <ion-text>\n          Month\n        </ion-text>\n      </ion-segment-button>\n    </ion-segment>\n\n    <!-- <ion-button (click)=\"change_view_mode('Day')\" size=\"small\" slot=\"end\" fill=\"outline\" color=\"dark\">\n      Day\n    </ion-button>\n    <ion-button (click)=\"change_view_mode('Week')\" size=\"small\" slot=\"end\" fill=\"outline\" color=\"dark\">\n      Week\n    </ion-button>\n    <ion-button (click)=\"change_view_mode('Month')\" size=\"small\" slot=\"end\" fill=\"outline\" color=\"dark\">\n      Month\n    </ion-button> -->\n  </ion-toolbar>\n</ion-footer>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_project-manage_project-manage_module_ts.js.map