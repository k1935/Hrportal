"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_tasks_tasks_module_ts"],{

/***/ 6026:
/*!*****************************************************!*\
  !*** ./src/app/pages/tasks/tasks-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TasksPageRoutingModule": () => (/* binding */ TasksPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _tasks_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tasks.page */ 232);




const routes = [
    {
        path: '',
        component: _tasks_page__WEBPACK_IMPORTED_MODULE_0__.TasksPage
    }
];
let TasksPageRoutingModule = class TasksPageRoutingModule {
};
TasksPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], TasksPageRoutingModule);



/***/ }),

/***/ 7694:
/*!*********************************************!*\
  !*** ./src/app/pages/tasks/tasks.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TasksPageModule": () => (/* binding */ TasksPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _tasks_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tasks-routing.module */ 6026);
/* harmony import */ var _tasks_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tasks.page */ 232);
/* harmony import */ var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/cdk/drag-drop */ 7727);








let TasksPageModule = class TasksPageModule {
};
TasksPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_5__.DragDropModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _tasks_routing_module__WEBPACK_IMPORTED_MODULE_0__.TasksPageRoutingModule
        ],
        declarations: [_tasks_page__WEBPACK_IMPORTED_MODULE_1__.TasksPage]
    })
], TasksPageModule);



/***/ }),

/***/ 232:
/*!*******************************************!*\
  !*** ./src/app/pages/tasks/tasks.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TasksPage": () => (/* binding */ TasksPage)
/* harmony export */ });
/* harmony import */ var _Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _tasks_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tasks.page.html?ngResource */ 85);
/* harmony import */ var _tasks_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tasks.page.scss?ngResource */ 7813);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/cdk/drag-drop */ 7727);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/common.service */ 5620);
/* harmony import */ var _services_tasks_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/tasks.service */ 2632);
/* harmony import */ var _services_project_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/project.service */ 354);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/auth.service */ 7556);










let TasksPage = class TasksPage {
  constructor(commonService, projectService, authService, tasksService, renderer) {
    this.commonService = commonService;
    this.projectService = projectService;
    this.authService = authService;
    this.tasksService = tasksService;
    this.renderer = renderer;
    this.segment = 'boards';
    this.board = [];
    this.columns = [];
    this.myTeams = [];
    this.connectedTo = [];
    this.teamBoardColumns = [];
    this.memberProjects = [];
    this.previousDays = [];
    this.daysInWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  }

  clickedOutside() {
    console.log("clickedOutside");
  }

  ngOnInit() {
    this.teamBoardColumns = [];
    this.taskDate = this.commonService.formatDate(new Date());
    let month = new Date().getMonth(); // this.selectBoxDate = this.commonService.formatDate(new Date());

    this.previousDays = this.LastNDays(24);
    this.previousDays[23].selected = true; // console.log(this.LastNDays(20));

    this.authService.userLogin.subscribe(resp => {
      if (resp && Object.keys(resp).length > 0) {
        this.tasksService.getUserTeams().then(resp => {
          this.myTeams = resp;
          this.selectedTeam = resp[0].teamId;
          this.tasksService.fetchTeamColumns(this.selectedTeam).then(columns => {
            columns.forEach(c => {
              c.tasks = [];
              this.connectedTo.push("box" + c.columnId);
              this.getTasks(c);
            });
            this.teamBoardColumns = columns;
          });
          this.projectService.getMemberProjects().then(resp => {
            this.memberProjects = resp;
          }); // this.tasksService.filterDsr({month: month+1}).then( resp => {
          //   console.log("resp filterDsr ",resp);
          // })
        });
      }
    });
  }

  getDayOfWeek(taskDate) {
    let date = new Date(taskDate);
    let day = date.getDay();
    return this.daysInWeek[day];
  }

  updateTaskProject(item) {
    this.updateTask(item);
  }

  selectBoxDate(date) {
    this.taskDate = date.date;
    this.changeDate(null);
    this.previousDays.forEach(date => {
      date.selected = false;
    });
    date.selected = true;
    console.log("date ", this.previousDays);
  }

  changeDate(ev) {
    this.teamBoardColumns.forEach(c => {
      c.tasks = [];
      this.connectedTo.push("box" + c.columnId);
      this.getTasks(c);
    });
  }

  deleteTask(item, columnIndex, itemIndex) {
    this.teamBoardColumns[columnIndex].tasks.splice(itemIndex, 1);
    this.tasksService.deleteUserTasks(item).then(resp => {}, error => {});
  }

  getTasks(column) {
    // console.log("getTasks column  ", column);
    column.date = this.taskDate; // this.commonService.presentLoading();

    this.tasksService.getUserTasks(column).then(tasks => {
      // this.commonService.loadingDismiss();
      tasks.forEach(task => {
        let fromTime = new Date(task.from);
        task.fromDisplay = this.addLeadingZeros(fromTime.getHours(), 2) + ":" + this.addLeadingZeros(fromTime.getMinutes(), 2);
        let toTime = new Date(task.to);
        task.toDisplay = this.addLeadingZeros(toTime.getHours(), 2) + ":" + this.addLeadingZeros(toTime.getMinutes(), 2);
      });
      column.tasks = tasks;
      console.log("column ", column);
    }, error => {// this.commonService.loadingDismiss();
    });
  }

  addLeadingZeros(num, totalLength) {
    return String(num).padStart(totalLength, '0');
  }

  addTask() {
    let newTask = {
      taskName: "",
      projectId: 0
    };
    this.teamBoardColumns[0].tasks.unshift(newTask);
    this.editTask(newTask, 0, 0); // console.log("addTask  ");
  }

  updateProject(task) {
    console.log("this.memberProjects ", this.memberProjects);
    console.log("task.projectId ", task.projectId);
    let filteredProjects = this.memberProjects.filter(p => p.projectId == task.projectId);
    console.log("filteredProjects ", filteredProjects);
    task.billable = filteredProjects[0].billable;
    console.log("task ", task);
    this.tasksService.updateTask(task).then(resp => {});
  }

  taskNameUpdated(ev, item, c, i) {
    item['taskName'] = ev.target.value; // console.log("taskNameUpdated  ");/

    if (item.taskId) {
      this.updateTask(item);
    } else {
      item.teamId = this.selectedTeam;
      item.date = this.taskDate;
      item.columnId = this.teamBoardColumns[c].columnId;
      this.tasksService.createTask(item).then(resp => {
        item.taskId = resp.taskId;
      });
    }
  }

  taskFromUpdated(ev, item) {
    let time = ev.target.value.split(":");
    let date = new Date(this.taskDate);
    date.setHours(time[0]);
    date.setMinutes(time[1]);
    item['from'] = date.getTime();

    if (item['to']) {
      item['to'] = new Date(item['to']).getTime();
      var differenceSec = (item['to'] - item['from']) / 1000;
      item['hours'] = (differenceSec / 3600).toFixed(2);
    }

    this.updateTask(item);
  }

  taskToUpdated(ev, item) {
    let time = ev.target.value.split(":");
    let date = new Date(this.taskDate);
    date.setHours(time[0]);
    date.setMinutes(time[1]);
    item['to'] = date.getTime();

    if (item['from']) {
      item['from'] = new Date(item['from']).getTime();
      var differenceSec = (item['to'] - item['from']) / 1000;
      item['hours'] = (differenceSec / 3600).toFixed(2);
    }

    this.updateTask(item);
  }

  onBlur(event, item, c, i) {
    item['edit'] = false;

    if (item.name == '') {
      this.teamBoardColumns[c].tasks.splice(i, 1);
    } else {} // console.log("onBlur  ");


    item.focus = false;
  }

  editTask(item, c, i) {
    if (!item.status || item.status == 0) {
      item['edit'] = true;
      let index = 'task' + c + i;
      let that = this;
      item.focus = true;
      console.log("focus ", true);
      setTimeout(() => {
        that.renderer.selectRootElement('#' + index).focus();
      }, 100);
    }
  }

  drop(event) {
    var _this = this;

    return (0,_Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // console.log("CdkDragDrop event", event)
      if (event.previousContainer === event.container) {
        (0,_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_7__.moveItemInArray)(event.container.data, event.previousIndex, event.currentIndex);
        event.container.data.forEach((task, index) => {
          task.order = index;

          _this.updateTask(task);
        });
      } else {
        (0,_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_7__.transferArrayItem)(event.previousContainer.data, event.container.data, event.previousIndex, event.currentIndex);
        event.container.data.forEach((task, index) => {
          task.order = index;
          task.columnId = event.container.id;

          _this.updateTask(task);
        });
      }
    })();
  }

  updateTask(task) {
    task.employeeId = this.authService.userId;
    this.tasksService.updateTask(task).then(resp => {});
  }

  disableBox(ev, item) {// item['edit'] = false;
    // console.log("disableBox ", this.inProgresTasks)
  }

  enableBox(ev, item) {// item['edit'] = true;
    // console.log("enableBox ")
  }

  LastNDays(n) {
    var result = [];

    for (var i = 0; i < n; i++) {
      var d = new Date();
      d.setDate(d.getDate() - i);
      let date = this.formatDate(d).split("#"); // console.log("formatDate ", date)

      result.push({
        date: date[0],
        day: date[1]
      });
    }

    return result.reverse();
  }

  formatDate(date) {
    var dd = date.getDate();
    var mm = date.getMonth() + 1;
    var yyyy = date.getFullYear();

    if (dd < 10) {
      dd = '0' + dd;
    }

    if (mm < 10) {
      mm = '0' + mm;
    }

    date = yyyy + '-' + mm + '-' + dd;
    return date + "#" + dd;
  }

};

TasksPage.ctorParameters = () => [{
  type: _services_common_service__WEBPACK_IMPORTED_MODULE_3__.CommonService
}, {
  type: _services_project_service__WEBPACK_IMPORTED_MODULE_5__.ProjectService
}, {
  type: _services_auth_service__WEBPACK_IMPORTED_MODULE_6__.AuthService
}, {
  type: _services_tasks_service__WEBPACK_IMPORTED_MODULE_4__.TasksService
}, {
  type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Renderer2
}];

TasksPage.propDecorators = {
  boards: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild,
    args: ['boards']
  }],
  test: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild,
    args: ['test']
  }]
};
TasksPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
  selector: 'app-tasks',
  template: _tasks_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_tasks_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], TasksPage);


/***/ }),

/***/ 354:
/*!*********************************************!*\
  !*** ./src/app/services/project.service.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProjectService": () => (/* binding */ ProjectService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth.service */ 7556);




let ProjectService = class ProjectService {
    constructor(authService, http) {
        this.authService = authService;
        this.http = http;
    }
    createProject(projectObject) {
        projectObject.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'createProject', projectObject).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateProject(projectObject) {
        projectObject.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'updateProject', projectObject).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getOneProject(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getOneProject', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getProjectMembers(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getProjectMembers', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    addProjectMember(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'addProjectMember', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    removeProjectMember(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'removeProjectMember', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateProjectMember(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'updateProjectMember', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    fetchAllProjects(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'fetchAllProjects', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getMemberProjects() {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getMemberProjects', { employeeId: this.authService.userId }).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getTeamsReporting() {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getTeamsReporting', { userId: this.authService.userId }).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    createEpic(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'createEpic', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateProjectEpic(epicData) {
        let newEpic = Object.assign(epicData);
        newEpic['id'] = newEpic.id.replace('epic', '');
        console.log("updateProjectEpic epicData ", epicData);
        console.log("updateProjectEpic newEpic ", newEpic);
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'epicUpdate', newEpic).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getProjectEpics(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getProjectEpics', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    createStory(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'createStory', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateEpicStory(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'storyUpdate', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getEpicStories(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getStories', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    createStoryTask(taskData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'createStoryTask', taskData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getStoryTasks(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getStoryTasks', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getProjectColumns(projectData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getProjectColumns', projectData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateProjectTask(task) {
        return new Promise((resolve, reject) => {
            task.organisationId = this.authService.organisationId;
            this.http.post(this.authService.apiUrl + 'updateProjectTask', task).subscribe((resp) => {
                console.log("rsp", resp);
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
};
ProjectService.ctorParameters = () => [
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
ProjectService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], ProjectService);



/***/ }),

/***/ 2632:
/*!*******************************************!*\
  !*** ./src/app/services/tasks.service.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TasksService": () => (/* binding */ TasksService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth.service */ 7556);




let TasksService = class TasksService {
    constructor(authService, http) {
        this.authService = authService;
        this.http = http;
    }
    getUserTeams() {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getUserTeams', { userId: this.authService.userId }).subscribe((resp) => {
                console.log("rsp", resp);
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    fetchTeamColumns(teamId) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'fetchTeamColumns', { teamId }).subscribe((resp) => {
                console.log("rsp", resp);
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateTask(task) {
        return new Promise((resolve, reject) => {
            task.organisationId = this.authService.organisationId;
            this.http.post(this.authService.apiUrl + 'updateTask', task).subscribe((resp) => {
                console.log("rsp", resp);
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    createTask(task) {
        return new Promise((resolve, reject) => {
            task.organisationId = this.authService.organisationId;
            task.employeeId = this.authService.userId;
            this.http.post(this.authService.apiUrl + 'createTask', task).subscribe((resp) => {
                console.log("rsp", resp);
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getUserTasks(column) {
        return new Promise((resolve, reject) => {
            column.organisationId = this.authService.organisationId;
            column.employeeId = this.authService.userId;
            this.http.post(this.authService.apiUrl + 'getUserTasks', column).subscribe((resp) => {
                // console.log("rsp",resp)
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    deleteUserTasks(column) {
        return new Promise((resolve, reject) => {
            column.organisationId = this.authService.organisationId;
            column.employeeId = this.authService.userId;
            this.http.post(this.authService.apiUrl + 'deleteTask', column).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    filterDsr(params) {
        return new Promise((resolve, reject) => {
            params.organisationId = this.authService.organisationId;
            // if(!params.employeeIds)
            // params.employeeIds = [this.authService.userId];
            // params.employeeIds = [4,9,31];
            this.http.post(this.authService.apiUrl + 'filterDsr', params).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
};
TasksService.ctorParameters = () => [
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
TasksService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], TasksService);



/***/ }),

/***/ 7813:
/*!********************************************************!*\
  !*** ./src/app/pages/tasks/tasks.page.scss?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = ":root {\n  --ion-color-rose: #fecdd3;\n  --ion-color-rose-rgb: 254,205,211;\n  --ion-color-rose-contrast: #000000;\n  --ion-color-rose-contrast-rgb: 0,0,0;\n  --ion-color-rose-shade: #e0b4ba;\n  --ion-color-rose-tint: #fed2d7;\n}\n\n.ion-color-rose {\n  --ion-color-base: var(--ion-color-rose);\n  --ion-color-base-rgb: var(--ion-color-rose-rgb);\n  --ion-color-contrast: var(--ion-color-rose-contrast);\n  --ion-color-contrast-rgb: var(--ion-color-rose-contrast-rgb);\n  --ion-color-shade: var(--ion-color-rose-shade);\n  --ion-color-tint: var(--ion-color-rose-tint);\n}\n\ndiv[slot=content] {\n  background: rgba(var(--ion-color-rose-rgb), 0.25);\n}\n\n.root {\n  display: flex;\n  flex-direction: column;\n  height: 100%;\n}\n\ntextarea {\n  width: 100%;\n  border: none;\n  font-size: 15px;\n  background: transparent;\n  border: none;\n  overflow: auto;\n  outline: none;\n  box-shadow: none;\n  resize: none; /*remove the resize handle on the bottom right*/\n}\n\n.app-name {\n  font-size: 28px;\n  font-family: \"Lato\", sans-serif;\n  font-weight: bold;\n}\n\n.has-gradient-text {\n  background: -webkit-linear-gradient(#13f7f4, #2af598);\n  -webkit-background-clip: text;\n  -webkit-text-fill-color: transparent;\n}\n\n.board {\n  display: flex;\n  flex-direction: column;\n  flex-grow: 1;\n  min-width: 0;\n  min-height: 0;\n}\n\n.board .board-bar {\n  background: rgba(128, 128, 128, 0.5);\n  padding: 8px 15px;\n}\n\n.board .board-bar .board-name {\n  font-size: 20px;\n  font-weight: bold;\n  color: white;\n}\n\n.board .board-wrapper {\n  display: flex;\n  flex-grow: 1;\n  overflow-x: auto;\n}\n\n.board .board-wrapper .board-columns {\n  display: flex;\n  flex-grow: 1;\n}\n\n.board .board-wrapper .board-columns .board-column {\n  display: flex;\n  flex-direction: column;\n  flex-grow: 1;\n  flex-basis: 0;\n  max-width: 300px;\n  margin: 0px 10px;\n  padding: 5px;\n  border-radius: 4px;\n  background: #161b22;\n}\n\n.board .board-wrapper .board-columns .board-column:not(:first-child) {\n  margin-left: 0;\n}\n\n.board .board-wrapper .board-columns .board-column .column-title {\n  font-size: 16px;\n  color: #fff;\n  font-weight: 800;\n  font-family: \"Lato\", sans-serif;\n  text-transform: uppercase;\n}\n\n.tasks-container {\n  flex-grow: 1;\n  overflow-y: auto;\n}\n\n.task {\n  background: #161b22;\n  color: #ccc;\n  border: 1px solid #4e4e4e;\n  border-radius: 10px;\n  overflow: hidden;\n  margin-bottom: 10px;\n  cursor: pointer;\n}\n\n.task:hover {\n  border: 1px solid #ccc;\n}\n\n.newTask {\n  color: #ccc;\n}\n\n.newTask ion-item {\n  --color: #ccc;\n  cursor: pointer;\n}\n\n.newTask ion-item:hover {\n  background: #161b22;\n  border-radius: 10px;\n}\n\n.cdk-drag-preview {\n  box-sizing: border-box;\n  border-radius: 10px;\n  color: #ccc;\n  border: 1px solid #0fbcf9;\n}\n\n.cdk-drag-placeholder {\n  opacity: 0;\n}\n\n.cdk-drag-animating {\n  transition: transform 250ms cubic-bezier(0, 0, 0.2, 1);\n}\n\n.tasks-container.cdk-drop-list-dragging .task:not(.cdk-drag-placeholder) {\n  transition: transform 250ms cubic-bezier(0, 0, 0.2, 1);\n}\n\nion-menu-button {\n  color: var(--ion-color-primary);\n}\n\n#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n\n.demo-chart {\n  width: 100%;\n  height: 300px;\n}\n\nion-grid {\n  --ion-grid-column-padding: 10px;\n  border-collapse: collapse;\n  border-style: hidden;\n  margin-top: 0px;\n  padding-top: 0px;\n}\n\nion-grid ion-row {\n  margin: 5px 0px;\n}\n\nion-grid ion-row:first-child {\n  background-color: #2980b9;\n  border-radius: 5px;\n  color: #fff;\n  font-weight: bold;\n}\n\nion-grid ion-col {\n  border-bottom: 0;\n  border-right: 0;\n}\n\nselect {\n  width: 100%;\n  padding: 7px;\n  background: var(--ion-color-gray);\n  color: #fff;\n  border: none;\n  outline: none;\n}\n\nselect:active,\nselect:hover {\n  outline: none;\n}\n\nselect:focus {\n  border-color: gray;\n  outline: none;\n}\n\n:host ::ng-deep .ngx-datatable .datatable-body .datatable-scroll {\n  display: inherit;\n}\n\n.odd {\n  background-color: #fff;\n  border-bottom: 1px solid #ccc;\n  color: #222;\n  border-radius: 5px;\n}\n\n.even {\n  background-color: #fff;\n  border-bottom: 1px solid #ccc;\n  border-radius: 5px;\n}\n\nion-item {\n  --background: transparent;\n}\n\nion-grid ion-col {\n  border-bottom: 0;\n  border-right: 0;\n  font-size: 14px;\n}\n\n.selected {\n  border: 0px solid #fff !important;\n  background-color: #fff;\n  color: #222;\n}\n\n.notSelected {\n  background-color: #161b22;\n  border: 0px solid #20bf6b !important;\n}\n\n.box {\n  background-color: #0d1116;\n  height: 50px;\n  border-bottom: 1px solid #fff;\n  border-top: 0.3px solid #0d1116;\n  line-height: 60px;\n  padding: 0px 10px;\n  font-size: 16px;\n}\n\n.colHeader {\n  background-color: #0d1116;\n  height: 70px;\n  border-bottom: 0.8px solid #000;\n  border-top: 0.8px solid #0d1116;\n  margin-bottom: 0.5px;\n}\n\n.box div:nth-child(even) {\n  fill: #161c22 !important;\n  stroke: #0d1116 !important;\n}\n\n.wrapper1,\n.wrapper2 {\n  border: none 0px RED;\n  overflow-x: scroll;\n  overflow-y: hidden;\n}\n\n.wrapper1 {\n  height: 20px;\n  margin-top: -10px;\n  position: sticky;\n  top: 0px;\n  z-index: 999999999;\n  background: #3d3d3d;\n}\n\n.wrapper2 {\n  height: 200px;\n}\n\n.div1 {\n  width: 25000px;\n  height: 20px;\n}\n\n.div2 {\n  width: 1000px;\n  height: 200px;\n  background-color: #88FF88;\n  overflow: auto;\n}\n\n.selected {\n  background-color: #34495e;\n  cursor: pointer;\n  margin-bottom: 5px;\n  color: #fff;\n  border-radius: 5px;\n}\n\n.notSelected {\n  cursor: pointer;\n  background-color: transparent;\n  color: #fff;\n  border: 0.5px solid rgb(101, 101, 101);\n  margin-bottom: 5px;\n  border-radius: 5px;\n}\n\n.notSelected ion-item {\n  color: #fff;\n}\n\n.scroll {\n  width: 200px;\n  height: 400px;\n  overflow: scroll;\n}\n\n.scroll::-webkit-scrollbar {\n  width: 12px;\n}\n\n.scroll::-webkit-scrollbar-track {\n  border-radius: 10px;\n}\n\n.scroll::-webkit-scrollbar-thumb {\n  background-color: #656565;\n  width: 3px;\n  border: 0.5px solid #656565;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRhc2tzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlCQUFBO0VBQ0EsaUNBQUE7RUFDQSxrQ0FBQTtFQUNBLG9DQUFBO0VBQ0EsK0JBQUE7RUFDQSw4QkFBQTtBQUNGOztBQUVBO0VBQ0UsdUNBQUE7RUFDQSwrQ0FBQTtFQUNBLG9EQUFBO0VBQ0EsNERBQUE7RUFDQSw4Q0FBQTtFQUNBLDRDQUFBO0FBQ0Y7O0FBRUE7RUFDRSxpREFBQTtBQUNGOztBQUtBO0VBQ0ksYUFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtBQUZKOztBQUtFO0VBQ0UsV0FBQTtFQUNFLFlBQUE7RUFDQSxlQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtFQUNBLGFBQUE7RUFJQSxnQkFBQTtFQUVBLFlBQUEsRUFBQSwrQ0FBQTtBQUpOOztBQVFFO0VBQ0UsZUFBQTtFQUNBLCtCQUFBO0VBQ0EsaUJBQUE7QUFMSjs7QUFRRTtFQUNFLHFEQUFBO0VBQ0EsNkJBQUE7RUFDQSxvQ0FBQTtBQUxKOztBQVNFO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtFQUlBLFlBQUE7RUFDQSxhQUFBO0FBVEo7O0FBV0k7RUFDSSxvQ0FBQTtFQUNBLGlCQUFBO0FBVFI7O0FBV1E7RUFDSSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0FBVFo7O0FBYUk7RUFDSSxhQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBWFI7O0FBYVE7RUFDSSxhQUFBO0VBQ0EsWUFBQTtBQVhaOztBQWFZO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUFYZDs7QUFhZ0I7RUFDSSxjQUFBO0FBWHBCOztBQWNnQjtFQUNJLGVBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSwrQkFBQTtFQUNBLHlCQUFBO0FBWnBCOztBQXFCRTtFQUNFLFlBQUE7RUFDQSxnQkFBQTtBQWxCSjs7QUFxQkU7RUFHRSxtQkFBQTtFQUNBLFdBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFFQSxtQkFBQTtFQUNBLGVBQUE7QUFyQko7O0FBMkJFO0VBQ0Usc0JBQUE7QUF4Qko7O0FBMkJFO0VBR0UsV0FBQTtBQTFCSjs7QUErQkk7RUFDRSxhQUFBO0VBQ0EsZUFBQTtBQTdCTjs7QUErQkk7RUFDRSxtQkFBQTtFQUNBLG1CQUFBO0FBN0JOOztBQWlDRTtFQUNFLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0VBQ0EseUJBQUE7QUE5Qko7O0FBb0NFO0VBQ0UsVUFBQTtBQWpDSjs7QUFvQ0U7RUFDRSxzREFBQTtBQWpDSjs7QUFvQ0U7RUFDRSxzREFBQTtBQWpDSjs7QUFzQ0U7RUFDRSwrQkFBQTtBQW5DSjs7QUFzQ0U7RUFDRSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSxRQUFBO0VBQ0EsMkJBQUE7QUFuQ0o7O0FBc0NFO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0FBbkNKOztBQXNDRTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxTQUFBO0FBbkNKOztBQXNDRTtFQUNFLHFCQUFBO0FBbkNKOztBQXNDRTtFQUNFLFdBQUE7RUFDQSxhQUFBO0FBbkNKOztBQXNDRTtFQUNFLCtCQUFBO0VBQ0EseUJBQUE7RUFDQSxvQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQW5DSjs7QUF1Q0k7RUFDRSxlQUFBO0FBckNOOztBQXdDSTtFQUNFLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7QUF0Q047O0FBeUNJO0VBRUUsZ0JBQUE7RUFDQSxlQUFBO0FBeENOOztBQW9ERTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsaUNBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUlBLGFBQUE7QUFwREo7O0FBd0RFOztFQUVFLGFBQUE7QUFyREo7O0FBd0RFO0VBQ0Usa0JBQUE7RUFDQSxhQUFBO0FBckRKOztBQXdERTtFQUNFLGdCQUFBO0FBckRKOztBQXdERTtFQUNFLHNCQUFBO0VBQ0EsNkJBQUE7RUFFQSxXQUFBO0VBQ0Esa0JBQUE7QUF0REo7O0FBeURFO0VBQ0Usc0JBQUE7RUFDQSw2QkFBQTtFQUVBLGtCQUFBO0FBdkRKOztBQTBERTtFQUNFLHlCQUFBO0FBdkRKOztBQTBERTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7QUF2REo7O0FBMERFO0VBQ0UsaUNBQUE7RUFDQSxzQkFBQTtFQUNBLFdBQUE7QUF2REo7O0FBMERFO0VBQ0UseUJBQUE7RUFDQSxvQ0FBQTtBQXZESjs7QUEwREE7RUFDSSx5QkFBQTtFQUNBLFlBQUE7RUFDQSw2QkFBQTtFQUNBLCtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7QUF2REo7O0FBMERBO0VBQ0kseUJBQUE7RUFDQSxZQUFBO0VBQ0EsK0JBQUE7RUFDQSwrQkFBQTtFQUNBLG9CQUFBO0FBdkRKOztBQTBEQTtFQUNJLHdCQUFBO0VBQ0EsMEJBQUE7QUF2REo7O0FBOERBOztFQUdJLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtBQTVESjs7QUErREE7RUFDSSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLFFBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FBNURKOztBQStEQTtFQUNJLGFBQUE7QUE1REo7O0FBK0RBO0VBQ0ksY0FBQTtFQUNBLFlBQUE7QUE1REo7O0FBK0RBO0VBQ0ksYUFBQTtFQUNBLGFBQUE7RUFDQSx5QkFBQTtFQUNBLGNBQUE7QUE1REo7O0FBZ0VBO0VBQ0kseUJBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFHQSxXQUFBO0VBQ0Esa0JBQUE7QUEvREo7O0FBa0VFO0VBQ0UsZUFBQTtFQUNBLDZCQUFBO0VBQ0EsV0FBQTtFQUNBLHNDQUFBO0VBQ0Esa0JBQUE7RUFFQSxrQkFBQTtBQWhFSjs7QUFrRUk7RUFDRSxXQUFBO0FBaEVOOztBQW9FRTtFQUNFLFlBQUE7RUFDQSxhQUFBO0VBQ0EsZ0JBQUE7QUFqRUo7O0FBbUVDO0VBQ0ksV0FBQTtBQWhFTDs7QUFtRUM7RUFFSSxtQkFBQTtBQWpFTDs7QUFvRUM7RUFFSSx5QkFBQTtFQUNBLFVBQUE7RUFDQSwyQkFBQTtBQWxFTCIsImZpbGUiOiJ0YXNrcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6cm9vdCB7XG4gIC0taW9uLWNvbG9yLXJvc2U6ICNmZWNkZDM7XG4gIC0taW9uLWNvbG9yLXJvc2UtcmdiOiAyNTQsMjA1LDIxMTtcbiAgLS1pb24tY29sb3Itcm9zZS1jb250cmFzdDogIzAwMDAwMDtcbiAgLS1pb24tY29sb3Itcm9zZS1jb250cmFzdC1yZ2I6IDAsMCwwO1xuICAtLWlvbi1jb2xvci1yb3NlLXNoYWRlOiAjZTBiNGJhO1xuICAtLWlvbi1jb2xvci1yb3NlLXRpbnQ6ICNmZWQyZDc7XG59XG5cbi5pb24tY29sb3Itcm9zZSB7XG4gIC0taW9uLWNvbG9yLWJhc2U6IHZhcigtLWlvbi1jb2xvci1yb3NlKTtcbiAgLS1pb24tY29sb3ItYmFzZS1yZ2I6IHZhcigtLWlvbi1jb2xvci1yb3NlLXJnYik7XG4gIC0taW9uLWNvbG9yLWNvbnRyYXN0OiB2YXIoLS1pb24tY29sb3Itcm9zZS1jb250cmFzdCk7XG4gIC0taW9uLWNvbG9yLWNvbnRyYXN0LXJnYjogdmFyKC0taW9uLWNvbG9yLXJvc2UtY29udHJhc3QtcmdiKTtcbiAgLS1pb24tY29sb3Itc2hhZGU6IHZhcigtLWlvbi1jb2xvci1yb3NlLXNoYWRlKTtcbiAgLS1pb24tY29sb3ItdGludDogdmFyKC0taW9uLWNvbG9yLXJvc2UtdGludCk7XG59XG5cbmRpdltzbG90PVwiY29udGVudFwiXSB7XG4gIGJhY2tncm91bmQ6IHJnYmEodmFyKC0taW9uLWNvbG9yLXJvc2UtcmdiKSwgMC4yNSlcbn1cblxuXG5cblxuLnJvb3Qge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gIH1cbiAgXG4gIHRleHRhcmVhIHsgXG4gICAgd2lkdGg6IDEwMCU7XG4gICAgICBib3JkZXI6IG5vbmU7XG4gICAgICBmb250LXNpemU6IDE1cHg7XG4gICAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICAgIGJvcmRlcjogbm9uZTtcbiAgICAgIG92ZXJmbG93OiBhdXRvO1xuICAgICAgb3V0bGluZTogbm9uZTtcbiAgXG4gICAgICAtd2Via2l0LWJveC1zaGFkb3c6IG5vbmU7XG4gICAgICAtbW96LWJveC1zaGFkb3c6IG5vbmU7XG4gICAgICBib3gtc2hhZG93OiBub25lO1xuICBcbiAgICAgIHJlc2l6ZTogbm9uZTsgLypyZW1vdmUgdGhlIHJlc2l6ZSBoYW5kbGUgb24gdGhlIGJvdHRvbSByaWdodCovXG4gIFxuICB9XG4gIFxuICAuYXBwLW5hbWUge1xuICAgIGZvbnQtc2l6ZTogMjhweDtcbiAgICBmb250LWZhbWlseTogJ0xhdG8nLCBzYW5zLXNlcmlmO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICB9XG4gIFxuICAuaGFzLWdyYWRpZW50LXRleHQge1xuICAgIGJhY2tncm91bmQ6IC13ZWJraXQtbGluZWFyLWdyYWRpZW50KCMxM2Y3ZjQsICMyYWY1OTgpO1xuICAgIC13ZWJraXQtYmFja2dyb3VuZC1jbGlwOiB0ZXh0O1xuICAgIC13ZWJraXQtdGV4dC1maWxsLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgfVxuICBcbiAgXG4gIC5ib2FyZCB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIGZsZXgtZ3JvdzogMTtcbiAgXG4gICAgLy8gT3ZlcnJpZGUgQXV0b21hdGljIE1pbmltdW0gU2l6ZVxuICAgIC8vIGh0dHBzOi8vc3RhY2tvdmVyZmxvdy5jb20vcXVlc3Rpb25zLzM2MjQ3MTQwL3doeS1kb250LWZsZXgtaXRlbXMtc2hyaW5rLXBhc3QtY29udGVudC1zaXplXG4gICAgbWluLXdpZHRoOiAwO1xuICAgIG1pbi1oZWlnaHQ6IDA7XG4gIFxuICAgIC5ib2FyZC1iYXIge1xuICAgICAgICBiYWNrZ3JvdW5kOiByZ2JhKGdyYXksIDAuNSk7XG4gICAgICAgIHBhZGRpbmc6IDhweCAxNXB4O1xuICAgIFxuICAgICAgICAuYm9hcmQtbmFtZSB7XG4gICAgICAgICAgICBmb250LXNpemU6IDIwcHg7XG4gICAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgICAgICAgfVxuICAgIH1cbiAgXG4gICAgLmJvYXJkLXdyYXBwZXIge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LWdyb3c6IDE7XG4gICAgICAgIG92ZXJmbG93LXg6IGF1dG87XG4gIFxuICAgICAgICAuYm9hcmQtY29sdW1ucyB7XG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgZmxleC1ncm93OiAxO1xuICBcbiAgICAgICAgICAgIC5ib2FyZC1jb2x1bW4ge1xuICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICAgICAgICAgICBmbGV4LWdyb3c6IDE7XG4gICAgICAgICAgICAgIGZsZXgtYmFzaXM6IDA7XG4gICAgICAgICAgICAgIG1heC13aWR0aDogMzAwcHg7XG4gICAgICAgICAgICAgIG1hcmdpbjogMHB4IDEwcHg7XG4gICAgICAgICAgICAgIHBhZGRpbmc6IDVweDtcbiAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNHB4O1xuICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjMTYxYjIyO1xuICBcbiAgICAgICAgICAgICAgICAmOm5vdCg6Zmlyc3QtY2hpbGQpIHtcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDA7XG4gICAgICAgICAgICAgICAgfVxuICBcbiAgICAgICAgICAgICAgICAuY29sdW1uLXRpdGxlIHtcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNnB4O1xuICAgICAgICAgICAgICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICAgICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDgwMDtcbiAgICAgICAgICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdMYXRvJywgc2Fucy1zZXJpZjtcbiAgICAgICAgICAgICAgICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgICAgICAgICAgICAgICAgICAgLy8gbWFyZ2luLWJvdHRvbTogMjBweDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gIH1cbiAgXG4gIFxuICAudGFza3MtY29udGFpbmVyIHtcbiAgICBmbGV4LWdyb3c6IDE7XG4gICAgb3ZlcmZsb3cteTogYXV0bzsgXG4gIH1cbiAgXG4gIC50YXNrIHtcbiAgICAvLyBkaXNwbGF5OiBmbGV4O1xuICAgIC8vIHBhZGRpbmc6IDBweCA1cHg7XG4gICAgYmFja2dyb3VuZDogIzE2MWIyMjtcbiAgICBjb2xvcjogI2NjYztcbiAgICBib3JkZXI6IDFweCBzb2xpZCAgIzRlNGU0ZTtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gIFxuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICBcbiAgICAvLyBib3gtc2hhZG93OiAwIDVweCA1cHggLTNweCByZ2JhKDAsIDAsIDAsIDAuMDUpLFxuICAgIC8vIDAgM3B4IDE0cHggMnB4IHJnYmEoMCwgMCwgMCwgMC4wNSk7XG4gIH1cbiAgXG4gIC50YXNrOmhvdmVyIHtcbiAgICBib3JkZXI6IDFweCBzb2xpZCAgI2NjYztcbiAgfVxuICBcbiAgLm5ld1Rhc2sge1xuICAgIC8vIGRpc3BsYXk6IGZsZXg7XG4gICAgLy8gcGFkZGluZzogMTVweCAxMnB4O1xuICAgIGNvbG9yOiAjY2NjO1xuICAgIC8vIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgLy8gdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIC8vIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIFxuICAgIGlvbi1pdGVtIHtcbiAgICAgIC0tY29sb3I6ICNjY2M7XG4gICAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgfVxuICAgIGlvbi1pdGVtOmhvdmVyIHtcbiAgICAgIGJhY2tncm91bmQ6ICMxNjFiMjI7XG4gICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIH1cbiAgfVxuICBcbiAgLmNkay1kcmFnLXByZXZpZXcge1xuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICBjb2xvcjogI2NjYztcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjMGZiY2Y5O1xuICAgIC8vIGJveC1zaGFkb3c6IDAgNXB4IDVweCAtM3B4IHJnYmEoMCwgMCwgMCwgMC4yKSxcbiAgICAvLyAgICAgICAgICAgICAwIDhweCAxMHB4IDFweCByZ2JhKDAsIDAsIDAsIDAuMTQpLFxuICAgIC8vICAgICAgICAgICAgIDAgM3B4IDE0cHggMnB4IHJnYmEoMCwgMCwgMCwgMC4xMik7XG4gIH1cbiAgXG4gIC5jZGstZHJhZy1wbGFjZWhvbGRlciB7XG4gICAgb3BhY2l0eTogMDtcbiAgfVxuICBcbiAgLmNkay1kcmFnLWFuaW1hdGluZyB7XG4gICAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDI1MG1zIGN1YmljLWJlemllcigwLCAwLCAwLjIsIDEpO1xuICB9XG4gIFxuICAudGFza3MtY29udGFpbmVyLmNkay1kcm9wLWxpc3QtZHJhZ2dpbmcgLnRhc2s6bm90KC5jZGstZHJhZy1wbGFjZWhvbGRlcikge1xuICAgIHRyYW5zaXRpb246IHRyYW5zZm9ybSAyNTBtcyBjdWJpYy1iZXppZXIoMCwgMCwgMC4yLCAxKTtcbiAgfVxuICBcbiAgXG4gIFxuICBpb24tbWVudS1idXR0b24ge1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gIH1cbiAgXG4gICNjb250YWluZXIge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgbGVmdDogMDtcbiAgICByaWdodDogMDtcbiAgICB0b3A6IDUwJTtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSk7XG4gIH1cbiAgXG4gICNjb250YWluZXIgc3Ryb25nIHtcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgbGluZS1oZWlnaHQ6IDI2cHg7XG4gIH1cbiAgXG4gICNjb250YWluZXIgcCB7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIGxpbmUtaGVpZ2h0OiAyMnB4O1xuICAgIGNvbG9yOiAjOGM4YzhjO1xuICAgIG1hcmdpbjogMDtcbiAgfVxuICBcbiAgI2NvbnRhaW5lciBhIHtcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG4gIH1cbiAgXG4gIC5kZW1vLWNoYXJ0IHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDMwMHB4O1xuICB9XG4gIFxuICBpb24tZ3JpZCB7XG4gICAgLS1pb24tZ3JpZC1jb2x1bW4tcGFkZGluZzogMTBweDtcbiAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xuICAgIGJvcmRlci1zdHlsZTogaGlkZGVuO1xuICAgIG1hcmdpbi10b3A6IDBweDtcbiAgICBwYWRkaW5nLXRvcDogMHB4O1xuICAgIC8vIHBhZGRpbmc6IDEwcHg7XG4gICAgLy8gYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgXG4gICAgaW9uLXJvdyB7XG4gICAgICBtYXJnaW46IDVweCAwcHg7XG4gICAgfVxuICBcbiAgICBpb24tcm93OmZpcnN0LWNoaWxkIHtcbiAgICAgIGJhY2tncm91bmQtY29sb3I6ICMyOTgwYjk7XG4gICAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgICBjb2xvcjogI2ZmZjtcbiAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIH1cbiAgXG4gICAgaW9uLWNvbCB7XG4gICAgICAvLyBib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xuICAgICAgYm9yZGVyLWJvdHRvbTogMDtcbiAgICAgIGJvcmRlci1yaWdodDogMDtcbiAgICB9XG4gIFxuICAgIC8vIGlvbi1jb2w6bGFzdC1jaGlsZCB7XG4gICAgICAvLyBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCBibGFjaztcbiAgICAvLyB9XG4gIFxuICAgIC8vIGlvbi1yb3c6bGFzdC1jaGlsZCB7XG4gICAgICAvLyBib3JkZXItYm90dG9tOiAxcHggc29saWQgYmxhY2s7XG4gICAgLy8gfVxuICB9XG4gICAgXG4gIHNlbGVjdCB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgcGFkZGluZzogN3B4O1xuICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1ncmF5KTsgXG4gICAgY29sb3I6ICNmZmY7IFxuICAgIGJvcmRlcjogbm9uZTtcbiAgICAvLyBib3JkZXI6IDAuNXB4IHNvbGlkIHJnYig4MywgODMsIDgzKTtcbiAgICAvLyBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIC8vIGJveC1zaGFkb3c6IDAgMCAxMHB4IDEwMHB4ICNmZmYgaW5zZXQ7XG4gICAgb3V0bGluZTogbm9uZTtcblxuICB9XG4gIFxuICBzZWxlY3Q6YWN0aXZlLFxuICBzZWxlY3Q6aG92ZXIge1xuICAgIG91dGxpbmU6IG5vbmVcbiAgfVxuICBcbiAgc2VsZWN0OmZvY3VzIHtcbiAgICBib3JkZXItY29sb3I6IGdyYXk7XG4gICAgb3V0bGluZTogbm9uZTtcbiAgfVxuICBcbiAgOmhvc3QgOjpuZy1kZWVwIC5uZ3gtZGF0YXRhYmxlIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLXNjcm9sbCB7XG4gICAgZGlzcGxheTogaW5oZXJpdDtcbiAgfVxuICBcbiAgLm9kZCB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2NjYztcbiAgICAvLyBib3gtc2hhZG93OiAwIDFweCAycHggMCByZ2IoNjAgNjQgNjcgLyAzMCUpLCAwIDFweCAzcHggMXB4IHJnYig2MCA2NCA2NyAvIDE1JSk7XG4gICAgY29sb3I6ICMyMjI7XG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICB9XG4gIFxuICAuZXZlbiB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2NjYztcbiAgICAvLyBib3gtc2hhZG93OiAwIDFweCAycHggMCByZ2IoNjAgNjQgNjcgLyAzMCUpLCAwIDFweCAzcHggMXB4IHJnYig2MCA2NCA2NyAvIDE1JSk7XG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICB9XG4gIFxuICBpb24taXRlbSB7XG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgfVxuICBcbiAgaW9uLWdyaWQgaW9uLWNvbCB7XG4gICAgYm9yZGVyLWJvdHRvbTogMDtcbiAgICBib3JkZXItcmlnaHQ6IDA7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICB9XG4gIFxuICAuc2VsZWN0ZWQge1xuICAgIGJvcmRlcjogMHB4IHNvbGlkICNmZmYgIWltcG9ydGFudDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICAgIGNvbG9yOiAjMjIyO1xuICB9XG4gIFxuICAubm90U2VsZWN0ZWQge1xuICAgIGJhY2tncm91bmQtY29sb3I6ICMxNjFiMjI7XG4gICAgYm9yZGVyOiAwcHggc29saWQgIzIwYmY2YiAhaW1wb3J0YW50O1xuICB9XG5cbi5ib3gge1xuICAgIGJhY2tncm91bmQtY29sb3I6ICMwZDExMTY7XG4gICAgaGVpZ2h0OiA1MHB4O1xuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZmZmO1xuICAgIGJvcmRlci10b3A6IDAuM3B4IHNvbGlkICMwZDExMTY7XG4gICAgbGluZS1oZWlnaHQ6IDYwcHg7XG4gICAgcGFkZGluZzogMHB4IDEwcHg7XG4gICAgZm9udC1zaXplOiAxNnB4O1xufVxuXG4uY29sSGVhZGVyIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMGQxMTE2O1xuICAgIGhlaWdodDogNzBweDtcbiAgICBib3JkZXItYm90dG9tOiAwLjhweCBzb2xpZCAjMDAwO1xuICAgIGJvcmRlci10b3A6IDAuOHB4IHNvbGlkICMwZDExMTY7XG4gICAgbWFyZ2luLWJvdHRvbTogMC41cHg7XG59XG5cbi5ib3ggZGl2Om50aC1jaGlsZChldmVuKSB7XG4gICAgZmlsbDogIzE2MWMyMiAhaW1wb3J0YW50O1xuICAgIHN0cm9rZTogIzBkMTExNiAhaW1wb3J0YW50O1xufVxuXG4uZ2FudHRUZXN0IHtcbiAgICAvLyBwb2ludGVyLWV2ZW50czogbm9uZTtcbn1cblxuLndyYXBwZXIxLFxuLndyYXBwZXIyIHtcbiAgICAvLyB3aWR0aDogMzAwcHg7XG4gICAgYm9yZGVyOiBub25lIDBweCBSRUQ7XG4gICAgb3ZlcmZsb3cteDogc2Nyb2xsO1xuICAgIG92ZXJmbG93LXk6IGhpZGRlbjtcbn1cblxuLndyYXBwZXIxIHtcbiAgICBoZWlnaHQ6IDIwcHg7XG4gICAgbWFyZ2luLXRvcDogLTEwcHg7XG4gICAgcG9zaXRpb246IHN0aWNreTtcbiAgICB0b3A6IDBweDtcbiAgICB6LWluZGV4OiA5OTk5OTk5OTk7XG4gICAgYmFja2dyb3VuZDogIzNkM2QzZDtcbn1cblxuLndyYXBwZXIyIHtcbiAgICBoZWlnaHQ6IDIwMHB4O1xufVxuXG4uZGl2MSB7XG4gICAgd2lkdGg6IDI1MDAwcHg7XG4gICAgaGVpZ2h0OiAyMHB4O1xufVxuXG4uZGl2MiB7XG4gICAgd2lkdGg6IDEwMDBweDtcbiAgICBoZWlnaHQ6IDIwMHB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICM4OEZGODg7XG4gICAgb3ZlcmZsb3c6IGF1dG87XG59XG5cblxuLnNlbGVjdGVkIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzQ0OTVlO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICBtYXJnaW4tYm90dG9tOiA1cHg7XG4gICAgLy8gYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNjY2M7XG4gICAgLy8gYm94LXNoYWRvdzogMCAxcHggMnB4IDAgcmdiKDYwIDY0IDY3IC8gMzAlKSwgMCAxcHggM3B4IDFweCByZ2IoNjAgNjQgNjcgLyAxNSUpO1xuICAgIGNvbG9yOiAjZmZmO1xuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgfVxuICBcbiAgLm5vdFNlbGVjdGVkIHtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgYm9yZGVyOiAwLjVweCBzb2xpZCByZ2IoMTAxLCAxMDEsIDEwMSk7XG4gICAgbWFyZ2luLWJvdHRvbTogNXB4O1xuICAgIC8vIGJveC1zaGFkb3c6IDAgMXB4IDJweCAwIHJnYig2MCA2NCA2NyAvIDMwJSksIDAgMXB4IDNweCAxcHggcmdiKDYwIDY0IDY3IC8gMTUlKTtcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIFxuICAgIGlvbi1pdGVtIHtcbiAgICAgIGNvbG9yOiAjZmZmO1xuICAgIH1cbiAgfVxuXG4gIC5zY3JvbGwge1xuICAgIHdpZHRoOiAyMDBweDtcbiAgICBoZWlnaHQ6IDQwMHB4O1xuICAgIG92ZXJmbG93OiBzY3JvbGw7XG4gfVxuIC5zY3JvbGw6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcbiAgICAgd2lkdGg6IDEycHg7XG4gfVxuIFxuIC5zY3JvbGw6Oi13ZWJraXQtc2Nyb2xsYmFyLXRyYWNrIHtcbiAgICAvLyAgLXdlYmtpdC1ib3gtc2hhZG93OiBpbnNldCAwIDAgNnB4IHJnYmEoMCwwLDAsMC4zKTsgXG4gICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gfVxuIFxuIC5zY3JvbGw6Oi13ZWJraXQtc2Nyb2xsYmFyLXRodW1iIHtcbiAgICAvLyAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICAgYmFja2dyb3VuZC1jb2xvcjogIzY1NjU2NTtcbiAgICAgd2lkdGg6IDNweDtcbiAgICAgYm9yZGVyOiAwLjVweCBzb2xpZCAjNjU2NTY1O1xuICAgIC8vICAtd2Via2l0LWJveC1zaGFkb3c6IGluc2V0IDAgMCA2cHggcmdiYSgyNTUsIDAsIDApOyBcbiB9Il19 */";

/***/ }),

/***/ 85:
/*!********************************************************!*\
  !*** ./src/app/pages/tasks/tasks.page.html?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar color=\"gray\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>My Tasks</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button>\n       <ion-icon name=\"repeat-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n  <ion-toolbar color=\"tertiary\">\n    <ion-row style=\"padding: 0px;\">\n      <ion-col size=\"2\" style=\"padding: 0px;border-right: 1px solid #ccc;;\">\n        <ion-item lines=\"none\">\n          <ion-input [(ngModel)]=\"taskDate\" (change)=\"changeDate($event)\" type=\"date\"\n            style=\"color: #ccc;font-weight: bold;\"></ion-input>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"4\" style=\"padding: 0px;\">\n        <ion-item lines=\"none\">\n          {{getDayOfWeek(taskDate)}} - {{this.taskDate | date:'dd MMMM, yyyy'}}\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"6\" style=\"padding: 0px;\">\n        <ion-item lines=\"none\" style=\"text-align: right;\">\n          <ion-note slot=\"end\">\n            <!-- 2 Hours -->\n          </ion-note>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n  </ion-toolbar>\n  <ion-toolbar color=\"gray\">\n    <ion-row style=\"padding: 0px 10px;\">\n      <ion-col *ngFor=\"let date of previousDays\" size=\"0.5\" style=\"border-right: 0px solid rgb(37 38 40);\n      background-color: transparent;\">\n        <div disabled (click)=\"selectBoxDate(date)\"\n          style=\"text-align: center;line-height: 35px;font-size: 15px;font-weight:bold;padding: 0px;border-radius: 10px;cursor: pointer;\"\n          [ngClass]=\"date.selected ? 'selected': 'notSelected'\">\n          {{date.day}}\n        </div>\n      </ion-col>\n      <!-- <ion-col size=\"2\" style=\"border: 0px solid rgb(37 38 40);\n      background-color: transparent;\n      padding: 0px;\">\n        <ion-item lines=\"none\">\n          <ion-input [(ngModel)]=\"taskDate\" (change)=\"changeDate($event)\" type=\"date\"\n            style=\"color: #ccc;font-weight: bold;\"></ion-input>\n        </ion-item>\n      </ion-col> -->\n    </ion-row>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"root\">\n\n    <div class=\"board\">\n\n      <!-- <div class=\"board-bar\">\n        <p class=\"board-name\">{{ board.taskName }}</p>\n      </div> -->\n\n      <div class=\"board-wrapper\">\n\n        <div class=\"board-columns\" cdkDropListGroup>\n          <div class=\"board-column\" *ngFor=\"let column of teamBoardColumns; let c = index;\" #boards id=\"boards\">\n\n            <div class=\"column-title\">\n              <ion-item lines=\"none\" (click)=\"addTask()\">\n                <ion-label style=\"color: #fff;\">\n                  {{ column.columnName }}\n                </ion-label>\n                <ion-icon name=\"add-outline\" *ngIf=\"c == 0\" class=\"newTask\">Add task</ion-icon>\n\n              </ion-item>\n            </div>\n\n            <div class=\"tasks-container\" cdkDropList id=\"{{column.columnId}}\" [cdkDropListData]=\"column.tasks\"\n              (cdkDropListDropped)=\"drop($event)\">\n              <div class=\"task\" *ngFor=\"let item of column.tasks; let i = index;\" cdkDrag\n                (mousedown)=\"disableBox($event, item)\" [style.border]=\"item.status == '1'? '1px solid green': ''\">\n                <ion-item lines=\"none\" style=\"background: var(--ion-color-gray);border-radius: 0px;margin-top: -5px;height: 50px;\">\n                  <ion-icon slot=\"start\" color=\"dark\" style=\"font-size:20px\" cdkDragHandle name=\"apps-outline\">\n                  </ion-icon>\n                  <ion-label style=\"color: #4bcffa;\" cdkDragHandle>\n                    <select [disabled]=\"item.status == '1'\" [(ngModel)]=\"item.projectId\" (change)=\"updateProject(item)\">\n\n                      <option value=\"0\" disabled selected>Select project</option>\n                      <option *ngFor=\"let project of memberProjects\" [value]=\"project.projectId\">{{project.projectName}}\n                      </option>\n                    </select>\n                  </ion-label>\n                  <ion-icon *ngIf=\"item.status != '1'\" slot=\"end\" color=\"danger\" style=\"font-size:20px;text-align: right;\" name=\"close-outline\" (click)=\"deleteTask(item, c, i)\">\n                  </ion-icon>\n                </ion-item>\n\n                <div style=\"width: 100%;padding: 10px 5px;\" (click)=\"editTask(item, c, i)\">\n                  <textarea [disabled]=\"item.status == '1'\" [autofocus]=\"item.focus\" *ngIf=\"item.edit\" [attr.id]=\"'task' + c + i\"\n                    placeholder=\"Enter new task!\" [rows]=\"3\" auto-grow type=\"text\" [value]=\"item.taskName\"\n                    (blur)='onBlur($event, item, c, i)' (change)=\"taskNameUpdated($event, item, c, i)\">\n                  </textarea>\n                  <span *ngIf=\"!item.edit\" style=\"padding: 0px;font-size: 15px;\">{{item.taskName}}</span>\n                </div>\n                <div style=\"border-top: 1px solid #4e4e4e;color: #b4b4b4;font-size: 13px;\">\n                  <ion-row>\n                    <ion-col size=\"5\">\n                      <ion-input [disabled]=\"item.status == '1'\" type=\"time\" [name]=\"'from'+i\" [value]=\"item.fromDisplay\"\n                        (change)=\"taskFromUpdated($event, item)\"></ion-input>\n                    </ion-col>\n                    <ion-col size=\"2\" style=\"color: rgb(255, 255, 255);font-size: 40px;line-height: 38px;\">\n                      -\n                    </ion-col>\n                    <ion-col size=\"5\">\n                      <ion-input [disabled]=\"item.status == '1'\" type=\"time\" [name]=\"'to'+i\" [value]=\"item.toDisplay\"\n                        (change)=\"taskToUpdated($event, item)\"></ion-input>\n                    </ion-col>\n                  </ion-row>\n                </div>\n              </div>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</ion-content>\n<ion-footer>\n\n</ion-footer>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_tasks_tasks_module_ts.js.map