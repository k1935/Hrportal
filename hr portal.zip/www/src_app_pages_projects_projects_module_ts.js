"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_projects_projects_module_ts"],{

/***/ 6702:
/*!***********************************************************!*\
  !*** ./src/app/pages/projects/projects-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProjectsPageRoutingModule": () => (/* binding */ ProjectsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _projects_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./projects.page */ 5913);




const routes = [
    {
        path: '',
        component: _projects_page__WEBPACK_IMPORTED_MODULE_0__.ProjectsPage
    }
];
let ProjectsPageRoutingModule = class ProjectsPageRoutingModule {
};
ProjectsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ProjectsPageRoutingModule);



/***/ }),

/***/ 3206:
/*!***************************************************!*\
  !*** ./src/app/pages/projects/projects.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProjectsPageModule": () => (/* binding */ ProjectsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _projects_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./projects-routing.module */ 6702);
/* harmony import */ var _projects_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./projects.page */ 5913);







let ProjectsPageModule = class ProjectsPageModule {
};
ProjectsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _projects_routing_module__WEBPACK_IMPORTED_MODULE_0__.ProjectsPageRoutingModule
        ],
        declarations: [_projects_page__WEBPACK_IMPORTED_MODULE_1__.ProjectsPage]
    })
], ProjectsPageModule);



/***/ }),

/***/ 5913:
/*!*************************************************!*\
  !*** ./src/app/pages/projects/projects.page.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProjectsPage": () => (/* binding */ ProjectsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _projects_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./projects.page.html?ngResource */ 977);
/* harmony import */ var _projects_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./projects.page.scss?ngResource */ 8102);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/common.service */ 5620);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/auth.service */ 7556);
/* harmony import */ var _services_project_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/project.service */ 354);








let ProjectsPage = class ProjectsPage {
    constructor(commonService, authService, projectService, router) {
        this.commonService = commonService;
        this.authService = authService;
        this.projectService = projectService;
        this.router = router;
        this.allProjects = [];
        this.allProjectsArray = [];
        this.segment = 'Ongoing';
    }
    ngOnInit() {
        // this.fetchEmployee()
    }
    ionViewWillEnter() {
        this.authService.userLogin.subscribe(resp => {
            if (resp && Object.keys(resp).length > 0)
                this.fetchEmployee();
        });
    }
    fetchEmployee() {
        let formData = {
            organisationId: this.authService.organisationId
        };
        this.projectService.fetchAllProjects(formData).then((resp) => {
            console.log("fetchAllProjects", resp);
            this.allProjectsArray = resp;
            this.allProjects = this.allProjectsArray.filter(p => p.projectStatus == this.segment);
        });
    }
    statusChanged($event) {
        this.allProjects = this.allProjectsArray.filter(p => p.projectStatus == this.segment);
    }
    openProject(request) {
        this.router.navigate(['/project-details/' + request.projectId]);
    }
};
ProjectsPage.ctorParameters = () => [
    { type: _services_common_service__WEBPACK_IMPORTED_MODULE_2__.CommonService },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService },
    { type: _services_project_service__WEBPACK_IMPORTED_MODULE_4__.ProjectService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router }
];
ProjectsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-projects',
        template: _projects_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_projects_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ProjectsPage);



/***/ }),

/***/ 354:
/*!*********************************************!*\
  !*** ./src/app/services/project.service.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProjectService": () => (/* binding */ ProjectService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth.service */ 7556);




let ProjectService = class ProjectService {
    constructor(authService, http) {
        this.authService = authService;
        this.http = http;
    }
    createProject(projectObject) {
        projectObject.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'createProject', projectObject).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateProject(projectObject) {
        projectObject.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'updateProject', projectObject).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getOneProject(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getOneProject', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getProjectMembers(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getProjectMembers', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    addProjectMember(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'addProjectMember', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    removeProjectMember(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'removeProjectMember', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateProjectMember(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'updateProjectMember', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    fetchAllProjects(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'fetchAllProjects', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getMemberProjects() {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getMemberProjects', { employeeId: this.authService.userId }).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getTeamsReporting() {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getTeamsReporting', { userId: this.authService.userId }).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    createEpic(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'createEpic', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateProjectEpic(epicData) {
        let newEpic = Object.assign(epicData);
        newEpic['id'] = newEpic.id.replace('epic', '');
        console.log("updateProjectEpic epicData ", epicData);
        console.log("updateProjectEpic newEpic ", newEpic);
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'epicUpdate', newEpic).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getProjectEpics(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getProjectEpics', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    createStory(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'createStory', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateEpicStory(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'storyUpdate', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getEpicStories(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getStories', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    createStoryTask(taskData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'createStoryTask', taskData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getStoryTasks(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getStoryTasks', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getProjectColumns(projectData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getProjectColumns', projectData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateProjectTask(task) {
        return new Promise((resolve, reject) => {
            task.organisationId = this.authService.organisationId;
            this.http.post(this.authService.apiUrl + 'updateProjectTask', task).subscribe((resp) => {
                console.log("rsp", resp);
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
};
ProjectService.ctorParameters = () => [
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
ProjectService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], ProjectService);



/***/ }),

/***/ 8102:
/*!**************************************************************!*\
  !*** ./src/app/pages/projects/projects.page.scss?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "ion-menu ion-content {\n  --background: var(--ion-item-background, var(--ion-background-color, #fff));\n}\n\nion-menu.md ion-content {\n  --padding-start: 8px;\n  --padding-end: 8px;\n  --padding-top: 20px;\n  --padding-bottom: 20px;\n}\n\nion-menu.md ion-list {\n  padding: 20px 0;\n}\n\nion-menu.md ion-note {\n  margin-bottom: 30px;\n}\n\nion-menu.md ion-list-header,\nion-menu.md ion-note {\n  padding-left: 10px;\n}\n\nion-menu.md ion-list#inbox-list {\n  border-bottom: 1px solid var(--ion-color-step-150, #d7d8da);\n}\n\nion-menu.md ion-list#inbox-list ion-list-header {\n  font-size: 22px;\n  font-weight: 600;\n  min-height: 20px;\n}\n\nion-menu.md ion-list#labels-list ion-list-header {\n  font-size: 16px;\n  margin-bottom: 18px;\n  color: #757575;\n  min-height: 26px;\n}\n\nion-menu.md ion-item {\n  --padding-start: 10px;\n  --padding-end: 10px;\n  border-radius: 4px;\n}\n\nion-menu.md ion-item.selected {\n  --background: rgba(var(--ion-color-primary-rgb), 0.14);\n}\n\nion-menu.md ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.md ion-item ion-icon {\n  color: #616e7e;\n}\n\nion-menu.md ion-item ion-label {\n  font-weight: 500;\n}\n\nion-menu.ios ion-content {\n  --padding-bottom: 20px;\n}\n\nion-menu.ios ion-list {\n  padding: 20px 0 0 0;\n}\n\nion-menu.ios ion-note {\n  line-height: 24px;\n  margin-bottom: 20px;\n}\n\nion-menu.ios ion-item {\n  --padding-start: 16px;\n  --padding-end: 16px;\n  --min-height: 50px;\n}\n\nion-menu.ios ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.ios ion-item ion-icon {\n  font-size: 24px;\n  color: #73849a;\n}\n\nion-menu.ios ion-list#labels-list ion-list-header {\n  margin-bottom: 8px;\n}\n\nion-menu.ios ion-list-header,\nion-menu.ios ion-note {\n  padding-left: 16px;\n  padding-right: 16px;\n}\n\nion-menu.ios ion-note {\n  margin-bottom: 8px;\n}\n\nion-note {\n  display: inline-block;\n  font-size: 16px;\n  color: var(--ion-color-medium-shade);\n}\n\nion-item.selected {\n  --color: var(--ion-color-primary);\n}\n\nion-list {\n  background: #f7f7f7;\n  padding: 10px;\n}\n\nion-item {\n  --background: transparent;\n}\n\nion-input {\n  border: 0.5px solid rgb(83, 83, 83);\n  background: #2c2d2e;\n  border-radius: 10px;\n  padding: 0px 10px !important;\n  color: #fff;\n}\n\nion-accordion {\n  background: #112c44;\n  color: #fff;\n}\n\nion-accordion.accordion-expanding .ion-accordion-toggle-icon,\nion-accordion.accordion-expanded .ion-accordion-toggle-icon {\n  color: #fff !important;\n}\n\nion-accordion.accordion-animated .ion-accordion-toggle-icon {\n  color: #fff !important;\n}\n\nion-accordion.accordion-animated .ion-accordion-toggle-icon {\n  color: #fff !important;\n}\n\n/* The container must be positioned relative: */\n\nion-item .custom-select {\n  position: relative;\n  font-family: Arial;\n}\n\nion-item .custom-select select {\n  display: none;\n  /*hide original SELECT element: */\n}\n\nselect {\n  width: 100%;\n  background: white;\n  color: #222;\n  padding: 7px;\n  border: 0.5px solid #ddd;\n  border-radius: 10px;\n  outline: none;\n}\n\nselect:active,\nselect:hover {\n  outline: none;\n}\n\nselect:focus {\n  border-color: gray;\n  outline: none;\n}\n\n::-webkit-calendar-picker-indicator {\n  filter: invert(1) !important;\n}\n\nion-menu-button {\n  color: var(--ion-color-primary);\n}\n\n#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n\n.demo-chart {\n  width: 100%;\n  height: 300px;\n}\n\nion-grid {\n  --ion-grid-column-padding: 10px;\n  border-collapse: collapse;\n  border-style: hidden;\n  margin-top: 0px;\n  padding-top: 0px;\n}\n\nion-grid ion-row {\n  margin: 5px 0px;\n}\n\nion-grid ion-row:first-child {\n  background-color: #2980b9;\n  border-radius: 5px;\n  color: #fff;\n  font-weight: bold;\n}\n\nion-grid ion-col {\n  border-bottom: 0;\n  border-right: 0;\n}\n\n:host ::ng-deep .ngx-datatable .datatable-body .datatable-scroll {\n  display: inherit;\n}\n\n.odd {\n  background-color: #161b22;\n  color: #fff;\n  border-radius: 5px;\n}\n\n.even {\n  background-color: #161b22;\n  color: #fff;\n  border-radius: 5px;\n}\n\nion-item {\n  --background: transparent;\n}\n\nion-grid ion-col {\n  border-bottom: 0;\n  border-right: 0;\n  font-size: 14px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2plY3RzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLDJFQUFBO0FBQ0o7O0FBRUU7RUFDRSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtBQUNKOztBQUVFO0VBQ0UsZUFBQTtBQUNKOztBQUVFO0VBQ0UsbUJBQUE7QUFDSjs7QUFFRTs7RUFFRSxrQkFBQTtBQUNKOztBQUVFO0VBQ0UsMkRBQUE7QUFDSjs7QUFFRTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUVBLGdCQUFBO0FBQUo7O0FBR0U7RUFDRSxlQUFBO0VBRUEsbUJBQUE7RUFFQSxjQUFBO0VBRUEsZ0JBQUE7QUFISjs7QUFNRTtFQUNFLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQUhKOztBQU1FO0VBQ0Usc0RBQUE7QUFISjs7QUFNRTtFQUNFLCtCQUFBO0FBSEo7O0FBTUU7RUFDRSxjQUFBO0FBSEo7O0FBTUU7RUFDRSxnQkFBQTtBQUhKOztBQU1FO0VBQ0Usc0JBQUE7QUFISjs7QUFNRTtFQUNFLG1CQUFBO0FBSEo7O0FBTUU7RUFDRSxpQkFBQTtFQUNBLG1CQUFBO0FBSEo7O0FBTUU7RUFDRSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUFISjs7QUFNRTtFQUNFLCtCQUFBO0FBSEo7O0FBTUU7RUFDRSxlQUFBO0VBQ0EsY0FBQTtBQUhKOztBQU1FO0VBQ0Usa0JBQUE7QUFISjs7QUFNRTs7RUFFRSxrQkFBQTtFQUNBLG1CQUFBO0FBSEo7O0FBTUU7RUFDRSxrQkFBQTtBQUhKOztBQU1FO0VBQ0UscUJBQUE7RUFDQSxlQUFBO0VBRUEsb0NBQUE7QUFKSjs7QUFPRTtFQUNFLGlDQUFBO0FBSko7O0FBT0U7RUFDRSxtQkFBQTtFQUNBLGFBQUE7QUFKSjs7QUFRRTtFQUNFLHlCQUFBO0FBTEo7O0FBUUU7RUFDRSxtQ0FBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSw0QkFBQTtFQUNBLFdBQUE7QUFMSjs7QUFZRTtFQUNFLG1CQUFBO0VBQ0EsV0FBQTtBQVRKOztBQWNFOztFQUVFLHNCQUFBO0FBWEo7O0FBZUU7RUFDRSxzQkFBQTtBQVpKOztBQWVFO0VBQ0Usc0JBQUE7QUFaSjs7QUF3QkUsK0NBQUE7O0FBQ0E7RUFDRSxrQkFBQTtFQUNBLGtCQUFBO0FBckJKOztBQXdCRTtFQUNFLGFBQUE7RUFDQSxpQ0FBQTtBQXJCSjs7QUF3QkU7RUFDRSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHdCQUFBO0VBQ0EsbUJBQUE7RUFFQSxhQUFBO0FBdEJKOztBQXlCRTs7RUFFRSxhQUFBO0FBdEJKOztBQTBCRTtFQUNFLGtCQUFBO0VBQ0EsYUFBQTtBQXZCSjs7QUEyQkU7RUFDRSw0QkFBQTtBQXhCSjs7QUEyQkE7RUFDSSwrQkFBQTtBQXhCSjs7QUEyQkU7RUFDRSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSxRQUFBO0VBQ0EsMkJBQUE7QUF4Qko7O0FBMkJFO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0FBeEJKOztBQTJCRTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxTQUFBO0FBeEJKOztBQTJCRTtFQUNFLHFCQUFBO0FBeEJKOztBQTJCRTtFQUNFLFdBQUE7RUFDQSxhQUFBO0FBeEJKOztBQTJCRTtFQUNFLCtCQUFBO0VBQ0EseUJBQUE7RUFDQSxvQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQXhCSjs7QUEwQkk7RUFDRSxlQUFBO0FBeEJOOztBQTJCSTtFQUNFLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7QUF6Qk47O0FBNEJJO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0FBMUJOOztBQThCRTtFQUNFLGdCQUFBO0FBM0JKOztBQThCRTtFQUNFLHlCQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0FBM0JKOztBQThCRTtFQUNFLHlCQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0FBM0JKOztBQThCRTtFQUNFLHlCQUFBO0FBM0JKOztBQThCRTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7QUEzQkoiLCJmaWxlIjoicHJvamVjdHMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLW1lbnUgaW9uLWNvbnRlbnQge1xuICAgIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWl0ZW0tYmFja2dyb3VuZCwgdmFyKC0taW9uLWJhY2tncm91bmQtY29sb3IsICNmZmYpKTtcbiAgfVxuICBcbiAgaW9uLW1lbnUubWQgaW9uLWNvbnRlbnQge1xuICAgIC0tcGFkZGluZy1zdGFydDogOHB4O1xuICAgIC0tcGFkZGluZy1lbmQ6IDhweDtcbiAgICAtLXBhZGRpbmctdG9wOiAyMHB4O1xuICAgIC0tcGFkZGluZy1ib3R0b206IDIwcHg7XG4gIH1cbiAgXG4gIGlvbi1tZW51Lm1kIGlvbi1saXN0IHtcbiAgICBwYWRkaW5nOiAyMHB4IDA7XG4gIH1cbiAgXG4gIGlvbi1tZW51Lm1kIGlvbi1ub3RlIHtcbiAgICBtYXJnaW4tYm90dG9tOiAzMHB4O1xuICB9XG4gIFxuICBpb24tbWVudS5tZCBpb24tbGlzdC1oZWFkZXIsXG4gIGlvbi1tZW51Lm1kIGlvbi1ub3RlIHtcbiAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIH1cbiAgXG4gIGlvbi1tZW51Lm1kIGlvbi1saXN0I2luYm94LWxpc3Qge1xuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCB2YXIoLS1pb24tY29sb3Itc3RlcC0xNTAsICNkN2Q4ZGEpO1xuICB9XG4gIFxuICBpb24tbWVudS5tZCBpb24tbGlzdCNpbmJveC1saXN0IGlvbi1saXN0LWhlYWRlciB7XG4gICAgZm9udC1zaXplOiAyMnB4O1xuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgXG4gICAgbWluLWhlaWdodDogMjBweDtcbiAgfVxuICBcbiAgaW9uLW1lbnUubWQgaW9uLWxpc3QjbGFiZWxzLWxpc3QgaW9uLWxpc3QtaGVhZGVyIHtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gIFxuICAgIG1hcmdpbi1ib3R0b206IDE4cHg7XG4gIFxuICAgIGNvbG9yOiAjNzU3NTc1O1xuICBcbiAgICBtaW4taGVpZ2h0OiAyNnB4O1xuICB9XG4gIFxuICBpb24tbWVudS5tZCBpb24taXRlbSB7XG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAxMHB4O1xuICAgIC0tcGFkZGluZy1lbmQ6IDEwcHg7XG4gICAgYm9yZGVyLXJhZGl1czogNHB4O1xuICB9XG4gIFxuICBpb24tbWVudS5tZCBpb24taXRlbS5zZWxlY3RlZCB7XG4gICAgLS1iYWNrZ3JvdW5kOiByZ2JhKHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXJnYiksIDAuMTQpO1xuICB9XG4gIFxuICBpb24tbWVudS5tZCBpb24taXRlbS5zZWxlY3RlZCBpb24taWNvbiB7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgfVxuICBcbiAgaW9uLW1lbnUubWQgaW9uLWl0ZW0gaW9uLWljb24ge1xuICAgIGNvbG9yOiAjNjE2ZTdlO1xuICB9XG4gIFxuICBpb24tbWVudS5tZCBpb24taXRlbSBpb24tbGFiZWwge1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIH1cbiAgXG4gIGlvbi1tZW51LmlvcyBpb24tY29udGVudCB7XG4gICAgLS1wYWRkaW5nLWJvdHRvbTogMjBweDtcbiAgfVxuICBcbiAgaW9uLW1lbnUuaW9zIGlvbi1saXN0IHtcbiAgICBwYWRkaW5nOiAyMHB4IDAgMCAwO1xuICB9XG4gIFxuICBpb24tbWVudS5pb3MgaW9uLW5vdGUge1xuICAgIGxpbmUtaGVpZ2h0OiAyNHB4O1xuICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XG4gIH1cbiAgXG4gIGlvbi1tZW51LmlvcyBpb24taXRlbSB7XG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAxNnB4O1xuICAgIC0tcGFkZGluZy1lbmQ6IDE2cHg7XG4gICAgLS1taW4taGVpZ2h0OiA1MHB4O1xuICB9XG4gIFxuICBpb24tbWVudS5pb3MgaW9uLWl0ZW0uc2VsZWN0ZWQgaW9uLWljb24ge1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gIH1cbiAgXG4gIGlvbi1tZW51LmlvcyBpb24taXRlbSBpb24taWNvbiB7XG4gICAgZm9udC1zaXplOiAyNHB4O1xuICAgIGNvbG9yOiAjNzM4NDlhO1xuICB9XG4gIFxuICBpb24tbWVudS5pb3MgaW9uLWxpc3QjbGFiZWxzLWxpc3QgaW9uLWxpc3QtaGVhZGVyIHtcbiAgICBtYXJnaW4tYm90dG9tOiA4cHg7XG4gIH1cbiAgXG4gIGlvbi1tZW51LmlvcyBpb24tbGlzdC1oZWFkZXIsXG4gIGlvbi1tZW51LmlvcyBpb24tbm90ZSB7XG4gICAgcGFkZGluZy1sZWZ0OiAxNnB4O1xuICAgIHBhZGRpbmctcmlnaHQ6IDE2cHg7XG4gIH1cbiAgXG4gIGlvbi1tZW51LmlvcyBpb24tbm90ZSB7XG4gICAgbWFyZ2luLWJvdHRvbTogOHB4O1xuICB9XG4gIFxuICBpb24tbm90ZSB7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0tc2hhZGUpO1xuICB9XG4gIFxuICBpb24taXRlbS5zZWxlY3RlZCB7XG4gICAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICB9XG4gIFxuICBpb24tbGlzdCB7XG4gICAgYmFja2dyb3VuZDogI2Y3ZjdmNztcbiAgICBwYWRkaW5nOiAxMHB4O1xuICB9XG4gIFxuICBcbiAgaW9uLWl0ZW0ge1xuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIH1cbiAgXG4gIGlvbi1pbnB1dCB7XG4gICAgYm9yZGVyOiAwLjVweCBzb2xpZCByZ2IoODMsIDgzLCA4Myk7XG4gICAgYmFja2dyb3VuZDogIzJjMmQyZTtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIHBhZGRpbmc6IDBweCAxMHB4ICFpbXBvcnRhbnQ7XG4gICAgY29sb3I6ICNmZmY7XG4gIH1cbiAgXG4gIC8vIGlucHV0IHtcbiAgLy8gICBwYWRkaW5nOiAxMHB4ICFpbXBvcnRhbnQ7XG4gIC8vIH1cbiAgXG4gIGlvbi1hY2NvcmRpb24ge1xuICAgIGJhY2tncm91bmQ6ICMxMTJjNDQ7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgLy8gYmFja2dyb3VuZDogIzc0OGNiMjtcbiAgfVxuICBcbiAgXG4gIGlvbi1hY2NvcmRpb24uYWNjb3JkaW9uLWV4cGFuZGluZyAuaW9uLWFjY29yZGlvbi10b2dnbGUtaWNvbixcbiAgaW9uLWFjY29yZGlvbi5hY2NvcmRpb24tZXhwYW5kZWQgLmlvbi1hY2NvcmRpb24tdG9nZ2xlLWljb24ge1xuICAgIGNvbG9yOiAjZmZmICFpbXBvcnRhbnQ7XG4gIH1cbiAgXG4gIFxuICBpb24tYWNjb3JkaW9uLmFjY29yZGlvbi1hbmltYXRlZCAuaW9uLWFjY29yZGlvbi10b2dnbGUtaWNvbiB7XG4gICAgY29sb3I6ICNmZmYgIWltcG9ydGFudDtcbiAgfVxuICBcbiAgaW9uLWFjY29yZGlvbi5hY2NvcmRpb24tYW5pbWF0ZWQgLmlvbi1hY2NvcmRpb24tdG9nZ2xlLWljb24ge1xuICAgIGNvbG9yOiAjZmZmICFpbXBvcnRhbnQ7XG4gIH1cbiAgXG4gIC8vIC5teS1jdXN0b20tbW9kYWwtY3NzIC5tb2RhbC13cmFwcGVyIHtcbiAgLy8gICBoZWlnaHQ6IDIwJTtcbiAgLy8gICB3aWR0aDogMjAlO1xuICAvLyAgIHBvc2l0aW9uOiBhYnNvbHV0ZTsgXG4gIC8vICAgZGlzcGxheTogYmxvY2s7ICBcbiAgLy8gfVxuICBcbiAgXG4gIFxuICAvKiBUaGUgY29udGFpbmVyIG11c3QgYmUgcG9zaXRpb25lZCByZWxhdGl2ZTogKi9cbiAgaW9uLWl0ZW0gLmN1c3RvbS1zZWxlY3Qge1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICBmb250LWZhbWlseTogQXJpYWw7XG4gIH1cbiAgXG4gIGlvbi1pdGVtIC5jdXN0b20tc2VsZWN0IHNlbGVjdCB7XG4gICAgZGlzcGxheTogbm9uZTtcbiAgICAvKmhpZGUgb3JpZ2luYWwgU0VMRUNUIGVsZW1lbnQ6ICovXG4gIH1cbiAgXG4gIHNlbGVjdCB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgYmFja2dyb3VuZDogd2hpdGU7XG4gICAgY29sb3I6ICMyMjI7XG4gICAgcGFkZGluZzogN3B4O1xuICAgIGJvcmRlcjogMC41cHggc29saWQgI2RkZDtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIC8vIGJveC1zaGFkb3c6IDAgMCAxMHB4IDEwMHB4ICNmZmYgaW5zZXQ7XG4gICAgb3V0bGluZTogbm9uZVxuICB9XG4gIFxuICBzZWxlY3Q6YWN0aXZlLFxuICBzZWxlY3Q6aG92ZXIge1xuICAgIG91dGxpbmU6IG5vbmVcbiAgfVxuICBcbiAgXG4gIHNlbGVjdDpmb2N1cyB7XG4gICAgYm9yZGVyLWNvbG9yOiBncmF5O1xuICAgIG91dGxpbmU6IG5vbmU7XG4gIH1cbiAgXG4gIFxuICA6Oi13ZWJraXQtY2FsZW5kYXItcGlja2VyLWluZGljYXRvciB7XG4gICAgZmlsdGVyOiBpbnZlcnQoMSkgIWltcG9ydGFudDtcbiAgfVxuXG5pb24tbWVudS1idXR0b24ge1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gIH1cbiAgXG4gICNjb250YWluZXIge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgbGVmdDogMDtcbiAgICByaWdodDogMDtcbiAgICB0b3A6IDUwJTtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSk7XG4gIH1cbiAgXG4gICNjb250YWluZXIgc3Ryb25nIHtcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgbGluZS1oZWlnaHQ6IDI2cHg7XG4gIH1cbiAgXG4gICNjb250YWluZXIgcCB7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIGxpbmUtaGVpZ2h0OiAyMnB4O1xuICAgIGNvbG9yOiAjOGM4YzhjO1xuICAgIG1hcmdpbjogMDtcbiAgfVxuICBcbiAgI2NvbnRhaW5lciBhIHtcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG4gIH1cbiAgXG4gIC5kZW1vLWNoYXJ0IHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDMwMHB4O1xuICB9XG4gIFxuICBpb24tZ3JpZCB7XG4gICAgLS1pb24tZ3JpZC1jb2x1bW4tcGFkZGluZzogMTBweDtcbiAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xuICAgIGJvcmRlci1zdHlsZTogaGlkZGVuO1xuICAgIG1hcmdpbi10b3A6IDBweDtcbiAgICBwYWRkaW5nLXRvcDogMHB4O1xuICBcbiAgICBpb24tcm93IHtcbiAgICAgIG1hcmdpbjogNXB4IDBweDtcbiAgICB9XG4gIFxuICAgIGlvbi1yb3c6Zmlyc3QtY2hpbGQge1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjogIzI5ODBiOTtcbiAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgfVxuICBcbiAgICBpb24tY29sIHtcbiAgICAgIGJvcmRlci1ib3R0b206IDA7XG4gICAgICBib3JkZXItcmlnaHQ6IDA7XG4gICAgfVxuICB9XG4gIFxuICA6aG9zdCA6Om5nLWRlZXAgLm5neC1kYXRhdGFibGUgLmRhdGF0YWJsZS1ib2R5IC5kYXRhdGFibGUtc2Nyb2xsIHtcbiAgICBkaXNwbGF5OiBpbmhlcml0O1xuICB9XG4gIFxuICAub2RkIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMTYxYjIyO1xuICAgIGNvbG9yOiAjZmZmO1xuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgfVxuICBcbiAgLmV2ZW4ge1xuICAgIGJhY2tncm91bmQtY29sb3I6ICMxNjFiMjI7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICB9XG4gIFxuICBpb24taXRlbSB7XG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgfVxuICBcbiAgaW9uLWdyaWQgaW9uLWNvbCB7XG4gICAgYm9yZGVyLWJvdHRvbTogMDtcbiAgICBib3JkZXItcmlnaHQ6IDA7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICB9Il19 */";

/***/ }),

/***/ 977:
/*!**************************************************************!*\
  !*** ./src/app/pages/projects/projects.page.html?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "<ion-header class=\"ion-no-border\">\n  <ion-toolbar color=\"gray\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Projects</ion-title>\n    <ion-buttons slot=\"end\" class=\"hidden-sm-down\">\n      <ion-button [routerLink]=\"['/project-details/null']\" color=\"primary\" style=\"font-weight: 300;width: 100px;\">\n        <ion-icon name=\"add-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n  <ion-toolbar color=\"tertiary\">\n    <ion-segment [(ngModel)]=\"segment\" style=\"margin: 0;\" (ionChange)=\"statusChanged($event)\">\n      <ion-segment-button value=\"Ongoing\">\n        <ion-text>\n          Ongoing\n        </ion-text>\n      </ion-segment-button>\n      <ion-segment-button value=\"Upcoming\">\n        <ion-text>\n          Upcoming\n        </ion-text>\n      </ion-segment-button>\n      <ion-segment-button value=\"Completed\">\n        <ion-text>\n          Completed\n        </ion-text>\n      </ion-segment-button>\n      <ion-segment-button value=\"Suspended\">\n        <ion-text>\n          Suspended\n        </ion-text>\n      </ion-segment-button>\n    </ion-segment>\n  </ion-toolbar>\n  <ion-toolbar color=\"gray\" style=\"padding-top: 10px;\">\n    <ion-searchbar placeholder=\"Filter Projects\"></ion-searchbar>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <!-- Desktop View -->\n  <ion-grid class=\"ion-margin hidden-sm-down\">    \n    <ion-row style=\"\n    position: sticky;\n    top: 0px;\n    z-index: 999999999;\n    background-color: #000;\n    color: #fff;\n    margin: 0px;\n  \">\n      <ion-col size=\"3\">Project Name</ion-col>\n      <ion-col size=\"2\">Client Name</ion-col>\n      <ion-col size=\"2\">Project Stage</ion-col>\n      <ion-col size=\"2\">Project Type</ion-col>\n      <ion-col size=\"2\">Start Date</ion-col>\n      <ion-col size=\"1\"></ion-col>\n    </ion-row>\n    <ion-row *ngIf=\"allProjects.length == 0\">\n          <div id=\"container\">\n            <img width=\"100px\" src=\"assets/loader.gif\" alt=\"\">\n          </div>\n    </ion-row>\n    <ion-row *ngFor=\"let project of allProjects; index as i\" (click)=\"openProject(project)\" [ngClass]=\"(i % 2 == 0) ? 'odd' : 'even'\">\n      <ion-col size=\"3\">{{project.projectName}}</ion-col>\n      <ion-col size=\"2\">{{project.clientName}}</ion-col>\n      <ion-col size=\"2\">{{project.projectStage}}</ion-col>\n      <ion-col size=\"2\">{{project.projectType}}</ion-col>\n      <ion-col size=\"2\">{{project.startDate | date:'dd MMM, yyyy'}}</ion-col>\n      <ion-col style=\"padding: 0px;text-align: center;\" size=\"1\">\n        <ion-button style=\"text-align: center;\" size=\"small\" fill=\"clear\"\n          color=\"primary\">\n          <ion-icon slot=\"icon-only\" name=\"create-outline\"></ion-icon>\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n  <ion-infinite-scroll>\n    <ion-infinite-scroll-content loadingSpinner=\"bubbles\" loadingText=\"Loading more data...\">\n    </ion-infinite-scroll-content>\n  </ion-infinite-scroll>\n</ion-content>\n<!-- <ion-footer>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"showModal()\" fill=\"outline\" color=\"dark\" expand=\"block\" style=\"font-weight: 300;width: 80px;\">\n        Import\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-footer> -->\n\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_projects_projects_module_ts.js.map