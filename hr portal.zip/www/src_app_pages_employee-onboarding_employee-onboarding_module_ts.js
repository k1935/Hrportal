"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_employee-onboarding_employee-onboarding_module_ts"],{

/***/ 9330:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/employee-onboarding/employee-onboarding-routing.module.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmployeeOnboardingPageRoutingModule": () => (/* binding */ EmployeeOnboardingPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _employee_onboarding_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./employee-onboarding.page */ 1198);




const routes = [
    {
        path: '',
        component: _employee_onboarding_page__WEBPACK_IMPORTED_MODULE_0__.EmployeeOnboardingPage
    }
];
let EmployeeOnboardingPageRoutingModule = class EmployeeOnboardingPageRoutingModule {
};
EmployeeOnboardingPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], EmployeeOnboardingPageRoutingModule);



/***/ }),

/***/ 5362:
/*!*************************************************************************!*\
  !*** ./src/app/pages/employee-onboarding/employee-onboarding.module.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmployeeOnboardingPageModule": () => (/* binding */ EmployeeOnboardingPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _employee_onboarding_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./employee-onboarding-routing.module */ 9330);
/* harmony import */ var _employee_onboarding_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./employee-onboarding.page */ 1198);







let EmployeeOnboardingPageModule = class EmployeeOnboardingPageModule {
};
EmployeeOnboardingPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _employee_onboarding_routing_module__WEBPACK_IMPORTED_MODULE_0__.EmployeeOnboardingPageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule
        ],
        declarations: [_employee_onboarding_page__WEBPACK_IMPORTED_MODULE_1__.EmployeeOnboardingPage]
    })
], EmployeeOnboardingPageModule);



/***/ }),

/***/ 1198:
/*!***********************************************************************!*\
  !*** ./src/app/pages/employee-onboarding/employee-onboarding.page.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmployeeOnboardingPage": () => (/* binding */ EmployeeOnboardingPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _employee_onboarding_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./employee-onboarding.page.html?ngResource */ 1943);
/* harmony import */ var _employee_onboarding_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./employee-onboarding.page.scss?ngResource */ 9808);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/common.service */ 5620);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 2508);







let EmployeeOnboardingPage = class EmployeeOnboardingPage {
    constructor(commonService, activated, router, formBuilder) {
        this.commonService = commonService;
        this.activated = activated;
        this.router = router;
        this.formBuilder = formBuilder;
        this.segment = 'user';
        this.userGroups = [];
        this.updateFlag = false;
        this.basic = this.formBuilder.group({
            firstName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required],
            middleName: [''],
            lastName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required],
            designation: [''],
            gender: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required],
            phoneNo: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")
                ])],
            personalEmail: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
                ])],
            spouseName: [''],
            fatherName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required],
            // DOB: ['',Validators.required],
            emergencyContactNumber: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required],
            // emergencyContactName: ['',Validators.required],
            presentAddress: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required],
            permanentAddress: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required],
            // panNumber: ['',Validators.required],
            // adharNumber: ['',Validators.required]
        });
        this.company = this.formBuilder.group({
            employeeType: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required],
            basicSalary: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required],
            companyBranch: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required],
            totalSalary: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required],
            officialEmail: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required],
            password: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required],
            DOJ: [this.commonService.formatDate(new Date()), _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required],
            userGroup: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required]
        });
    }
    ngOnInit() {
        this.segment = 'user';
        this.id = this.activated.snapshot.params.id;
        console.log("id", this.id);
        if (this.id != "null") {
            this.fetchEmployee();
            this.updateFlag = true;
        }
        this.commonService.fetchAllUserGroups().then(resp => {
            this.userGroups = resp;
        });
    }
    register() {
        if (this.basic.valid && this.company.valid) {
            this.commonService.presentLoading();
            let formData = Object.assign(this.company.value, this.basic.value);
            // formData.organisationId = localStorage.getItem('organisationId')
            this.commonService.registerEmployee(formData).then((resp) => {
                this.commonService.loadingDismiss();
                this.commonService.showToast("success", "Employee Onboarded!");
                this.router.navigate(['/employee-list']);
            });
        }
    }
    ///update employee details
    updateEmployee() {
        if (this.basic.valid && this.company.valid) {
            this.commonService.presentLoading();
            let formData = Object.assign(this.basic.value, this.company.value, { employeeId: this.employeeId });
            this.commonService.updateEmployee(formData).then((resp) => {
                this.commonService.loadingDismiss();
                this.commonService.showToast("success", "Employee Updated!");
                this.router.navigate(['/employee-list']);
            });
        }
    }
    ///fetch employee details based on id
    fetchEmployee() {
        let formData = {
            employeeId: this.id
        };
        this.commonService.presentLoading();
        this.commonService.getOneEmployee(formData).then((resp) => {
            let user = resp[0];
            console.log("user ", user);
            this.basic.patchValue(user);
            this.company.patchValue(user);
            this.commonService.loadingDismiss();
            this.employeeId = user.employeeId;
        });
    }
    nextTab() {
        if (this.basic.valid)
            this.segment = "card";
        else
            this.commonService.showToast('error', "Please fill all mandatory fields!");
    }
    previousTab() {
        this.segment = "user";
    }
};
EmployeeOnboardingPage.ctorParameters = () => [
    { type: _services_common_service__WEBPACK_IMPORTED_MODULE_2__.CommonService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.ActivatedRoute },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormBuilder }
];
EmployeeOnboardingPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-employee-onboarding',
        template: _employee_onboarding_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_employee_onboarding_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], EmployeeOnboardingPage);



/***/ }),

/***/ 9808:
/*!************************************************************************************!*\
  !*** ./src/app/pages/employee-onboarding/employee-onboarding.page.scss?ngResource ***!
  \************************************************************************************/
/***/ ((module) => {

module.exports = "ion-menu ion-content {\n  --background: var(--ion-item-background, var(--ion-background-color, #fff));\n}\n\nion-menu.md ion-content {\n  --padding-start: 8px;\n  --padding-end: 8px;\n  --padding-top: 20px;\n  --padding-bottom: 20px;\n}\n\nion-menu.md ion-list {\n  padding: 20px 0;\n}\n\nion-menu.md ion-note {\n  margin-bottom: 30px;\n}\n\nion-menu.md ion-list-header,\nion-menu.md ion-note {\n  padding-left: 10px;\n}\n\nion-menu.md ion-list#inbox-list {\n  border-bottom: 1px solid var(--ion-color-step-150, #d7d8da);\n}\n\nion-menu.md ion-list#inbox-list ion-list-header {\n  font-size: 22px;\n  font-weight: 600;\n  min-height: 20px;\n}\n\nion-menu.md ion-list#labels-list ion-list-header {\n  font-size: 16px;\n  margin-bottom: 18px;\n  color: #757575;\n  min-height: 26px;\n}\n\nion-menu.md ion-item {\n  --padding-start: 10px;\n  --padding-end: 10px;\n  border-radius: 4px;\n}\n\nion-menu.md ion-item.selected {\n  --background: rgba(var(--ion-color-primary-rgb), 0.14);\n}\n\nion-menu.md ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.md ion-item ion-icon {\n  color: #616e7e;\n}\n\nion-menu.md ion-item ion-label {\n  font-weight: 500;\n}\n\nion-menu.ios ion-content {\n  --padding-bottom: 20px;\n}\n\nion-menu.ios ion-list {\n  padding: 20px 0 0 0;\n}\n\nion-menu.ios ion-note {\n  line-height: 24px;\n  margin-bottom: 20px;\n}\n\nion-menu.ios ion-item {\n  --padding-start: 16px;\n  --padding-end: 16px;\n  --min-height: 50px;\n}\n\nion-menu.ios ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.ios ion-item ion-icon {\n  font-size: 24px;\n  color: #73849a;\n}\n\nion-menu.ios ion-list#labels-list ion-list-header {\n  margin-bottom: 8px;\n}\n\nion-menu.ios ion-list-header,\nion-menu.ios ion-note {\n  padding-left: 16px;\n  padding-right: 16px;\n}\n\nion-menu.ios ion-note {\n  margin-bottom: 8px;\n}\n\nion-note {\n  display: inline-block;\n  font-size: 16px;\n  color: var(--ion-color-medium-shade);\n}\n\nion-item.selected {\n  --color: var(--ion-color-primary);\n}\n\nion-list {\n  background: #f7f7f7;\n  padding: 10px;\n}\n\nion-item {\n  --background: transparent;\n}\n\nion-input {\n  border: 0.5px solid rgb(83, 83, 83);\n  background: #2c2d2e;\n  border-radius: 10px;\n  padding: 0px 10px !important;\n  color: #fff;\n}\n\nion-accordion {\n  background: #112c44;\n  color: #fff;\n}\n\nion-accordion.accordion-expanding .ion-accordion-toggle-icon,\nion-accordion.accordion-expanded .ion-accordion-toggle-icon {\n  color: #fff !important;\n}\n\nion-accordion.accordion-animated .ion-accordion-toggle-icon {\n  color: #fff !important;\n}\n\nion-accordion.accordion-animated .ion-accordion-toggle-icon {\n  color: #fff !important;\n}\n\n/* The container must be positioned relative: */\n\nion-item .custom-select {\n  position: relative;\n  font-family: Arial;\n}\n\nion-item .custom-select select {\n  display: none;\n  /*hide original SELECT element: */\n}\n\nselect {\n  width: 100%;\n  background: white;\n  color: #222;\n  padding: 7px;\n  border: 0.5px solid #ddd;\n  border-radius: 10px;\n  outline: none;\n}\n\nselect:active,\nselect:hover {\n  outline: none;\n}\n\nselect:focus {\n  border-color: gray;\n  outline: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImVtcGxveWVlLW9uYm9hcmRpbmcucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksMkVBQUE7QUFDSjs7QUFFRTtFQUNFLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLHNCQUFBO0FBQ0o7O0FBRUU7RUFDRSxlQUFBO0FBQ0o7O0FBRUU7RUFDRSxtQkFBQTtBQUNKOztBQUVFOztFQUVFLGtCQUFBO0FBQ0o7O0FBRUU7RUFDRSwyREFBQTtBQUNKOztBQUVFO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBRUEsZ0JBQUE7QUFBSjs7QUFHRTtFQUNFLGVBQUE7RUFFQSxtQkFBQTtFQUVBLGNBQUE7RUFFQSxnQkFBQTtBQUhKOztBQU1FO0VBQ0UscUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FBSEo7O0FBTUU7RUFDRSxzREFBQTtBQUhKOztBQU1FO0VBQ0UsK0JBQUE7QUFISjs7QUFNRTtFQUNFLGNBQUE7QUFISjs7QUFNRTtFQUNFLGdCQUFBO0FBSEo7O0FBTUU7RUFDRSxzQkFBQTtBQUhKOztBQU1FO0VBQ0UsbUJBQUE7QUFISjs7QUFNRTtFQUNFLGlCQUFBO0VBQ0EsbUJBQUE7QUFISjs7QUFNRTtFQUNFLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQUhKOztBQU1FO0VBQ0UsK0JBQUE7QUFISjs7QUFNRTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FBSEo7O0FBTUU7RUFDRSxrQkFBQTtBQUhKOztBQU1FOztFQUVFLGtCQUFBO0VBQ0EsbUJBQUE7QUFISjs7QUFNRTtFQUNFLGtCQUFBO0FBSEo7O0FBTUU7RUFDRSxxQkFBQTtFQUNBLGVBQUE7RUFFQSxvQ0FBQTtBQUpKOztBQU9FO0VBQ0UsaUNBQUE7QUFKSjs7QUFPRTtFQUNFLG1CQUFBO0VBQ0EsYUFBQTtBQUpKOztBQVFFO0VBQ0UseUJBQUE7QUFMSjs7QUFRRTtFQUNFLG1DQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLDRCQUFBO0VBQ0EsV0FBQTtBQUxKOztBQVlFO0VBQ0UsbUJBQUE7RUFDQSxXQUFBO0FBVEo7O0FBY0U7O0VBRUUsc0JBQUE7QUFYSjs7QUFlRTtFQUNFLHNCQUFBO0FBWko7O0FBZUU7RUFDRSxzQkFBQTtBQVpKOztBQXdCRSwrQ0FBQTs7QUFDQTtFQUNFLGtCQUFBO0VBQ0Esa0JBQUE7QUFyQko7O0FBd0JFO0VBQ0UsYUFBQTtFQUNBLGlDQUFBO0FBckJKOztBQXdCRTtFQUNFLFdBQUE7RUFDQSxpQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esd0JBQUE7RUFDQSxtQkFBQTtFQUVBLGFBQUE7QUF0Qko7O0FBeUJFOztFQUVFLGFBQUE7QUF0Qko7O0FBMEJFO0VBQ0Usa0JBQUE7RUFDQSxhQUFBO0FBdkJKIiwiZmlsZSI6ImVtcGxveWVlLW9uYm9hcmRpbmcucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLW1lbnUgaW9uLWNvbnRlbnQge1xuICAgIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWl0ZW0tYmFja2dyb3VuZCwgdmFyKC0taW9uLWJhY2tncm91bmQtY29sb3IsICNmZmYpKTtcbiAgfVxuICBcbiAgaW9uLW1lbnUubWQgaW9uLWNvbnRlbnQge1xuICAgIC0tcGFkZGluZy1zdGFydDogOHB4O1xuICAgIC0tcGFkZGluZy1lbmQ6IDhweDtcbiAgICAtLXBhZGRpbmctdG9wOiAyMHB4O1xuICAgIC0tcGFkZGluZy1ib3R0b206IDIwcHg7XG4gIH1cbiAgXG4gIGlvbi1tZW51Lm1kIGlvbi1saXN0IHtcbiAgICBwYWRkaW5nOiAyMHB4IDA7XG4gIH1cbiAgXG4gIGlvbi1tZW51Lm1kIGlvbi1ub3RlIHtcbiAgICBtYXJnaW4tYm90dG9tOiAzMHB4O1xuICB9XG4gIFxuICBpb24tbWVudS5tZCBpb24tbGlzdC1oZWFkZXIsXG4gIGlvbi1tZW51Lm1kIGlvbi1ub3RlIHtcbiAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIH1cbiAgXG4gIGlvbi1tZW51Lm1kIGlvbi1saXN0I2luYm94LWxpc3Qge1xuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCB2YXIoLS1pb24tY29sb3Itc3RlcC0xNTAsICNkN2Q4ZGEpO1xuICB9XG4gIFxuICBpb24tbWVudS5tZCBpb24tbGlzdCNpbmJveC1saXN0IGlvbi1saXN0LWhlYWRlciB7XG4gICAgZm9udC1zaXplOiAyMnB4O1xuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgXG4gICAgbWluLWhlaWdodDogMjBweDtcbiAgfVxuICBcbiAgaW9uLW1lbnUubWQgaW9uLWxpc3QjbGFiZWxzLWxpc3QgaW9uLWxpc3QtaGVhZGVyIHtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gIFxuICAgIG1hcmdpbi1ib3R0b206IDE4cHg7XG4gIFxuICAgIGNvbG9yOiAjNzU3NTc1O1xuICBcbiAgICBtaW4taGVpZ2h0OiAyNnB4O1xuICB9XG4gIFxuICBpb24tbWVudS5tZCBpb24taXRlbSB7XG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAxMHB4O1xuICAgIC0tcGFkZGluZy1lbmQ6IDEwcHg7XG4gICAgYm9yZGVyLXJhZGl1czogNHB4O1xuICB9XG4gIFxuICBpb24tbWVudS5tZCBpb24taXRlbS5zZWxlY3RlZCB7XG4gICAgLS1iYWNrZ3JvdW5kOiByZ2JhKHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXJnYiksIDAuMTQpO1xuICB9XG4gIFxuICBpb24tbWVudS5tZCBpb24taXRlbS5zZWxlY3RlZCBpb24taWNvbiB7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgfVxuICBcbiAgaW9uLW1lbnUubWQgaW9uLWl0ZW0gaW9uLWljb24ge1xuICAgIGNvbG9yOiAjNjE2ZTdlO1xuICB9XG4gIFxuICBpb24tbWVudS5tZCBpb24taXRlbSBpb24tbGFiZWwge1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIH1cbiAgXG4gIGlvbi1tZW51LmlvcyBpb24tY29udGVudCB7XG4gICAgLS1wYWRkaW5nLWJvdHRvbTogMjBweDtcbiAgfVxuICBcbiAgaW9uLW1lbnUuaW9zIGlvbi1saXN0IHtcbiAgICBwYWRkaW5nOiAyMHB4IDAgMCAwO1xuICB9XG4gIFxuICBpb24tbWVudS5pb3MgaW9uLW5vdGUge1xuICAgIGxpbmUtaGVpZ2h0OiAyNHB4O1xuICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XG4gIH1cbiAgXG4gIGlvbi1tZW51LmlvcyBpb24taXRlbSB7XG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAxNnB4O1xuICAgIC0tcGFkZGluZy1lbmQ6IDE2cHg7XG4gICAgLS1taW4taGVpZ2h0OiA1MHB4O1xuICB9XG4gIFxuICBpb24tbWVudS5pb3MgaW9uLWl0ZW0uc2VsZWN0ZWQgaW9uLWljb24ge1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gIH1cbiAgXG4gIGlvbi1tZW51LmlvcyBpb24taXRlbSBpb24taWNvbiB7XG4gICAgZm9udC1zaXplOiAyNHB4O1xuICAgIGNvbG9yOiAjNzM4NDlhO1xuICB9XG4gIFxuICBpb24tbWVudS5pb3MgaW9uLWxpc3QjbGFiZWxzLWxpc3QgaW9uLWxpc3QtaGVhZGVyIHtcbiAgICBtYXJnaW4tYm90dG9tOiA4cHg7XG4gIH1cbiAgXG4gIGlvbi1tZW51LmlvcyBpb24tbGlzdC1oZWFkZXIsXG4gIGlvbi1tZW51LmlvcyBpb24tbm90ZSB7XG4gICAgcGFkZGluZy1sZWZ0OiAxNnB4O1xuICAgIHBhZGRpbmctcmlnaHQ6IDE2cHg7XG4gIH1cbiAgXG4gIGlvbi1tZW51LmlvcyBpb24tbm90ZSB7XG4gICAgbWFyZ2luLWJvdHRvbTogOHB4O1xuICB9XG4gIFxuICBpb24tbm90ZSB7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0tc2hhZGUpO1xuICB9XG4gIFxuICBpb24taXRlbS5zZWxlY3RlZCB7XG4gICAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICB9XG4gIFxuICBpb24tbGlzdCB7XG4gICAgYmFja2dyb3VuZDogI2Y3ZjdmNztcbiAgICBwYWRkaW5nOiAxMHB4O1xuICB9XG4gIFxuICBcbiAgaW9uLWl0ZW0ge1xuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIH1cbiAgXG4gIGlvbi1pbnB1dCB7XG4gICAgYm9yZGVyOiAwLjVweCBzb2xpZCByZ2IoODMsIDgzLCA4Myk7XG4gICAgYmFja2dyb3VuZDogIzJjMmQyZTtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIHBhZGRpbmc6IDBweCAxMHB4ICFpbXBvcnRhbnQ7XG4gICAgY29sb3I6ICNmZmY7XG4gIH1cbiAgXG4gIC8vIGlucHV0IHtcbiAgLy8gICBwYWRkaW5nOiAxMHB4ICFpbXBvcnRhbnQ7XG4gIC8vIH1cbiAgXG4gIGlvbi1hY2NvcmRpb24ge1xuICAgIGJhY2tncm91bmQ6ICMxMTJjNDQ7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgLy8gYmFja2dyb3VuZDogIzc0OGNiMjtcbiAgfVxuICBcbiAgXG4gIGlvbi1hY2NvcmRpb24uYWNjb3JkaW9uLWV4cGFuZGluZyAuaW9uLWFjY29yZGlvbi10b2dnbGUtaWNvbixcbiAgaW9uLWFjY29yZGlvbi5hY2NvcmRpb24tZXhwYW5kZWQgLmlvbi1hY2NvcmRpb24tdG9nZ2xlLWljb24ge1xuICAgIGNvbG9yOiAjZmZmICFpbXBvcnRhbnQ7XG4gIH1cbiAgXG4gIFxuICBpb24tYWNjb3JkaW9uLmFjY29yZGlvbi1hbmltYXRlZCAuaW9uLWFjY29yZGlvbi10b2dnbGUtaWNvbiB7XG4gICAgY29sb3I6ICNmZmYgIWltcG9ydGFudDtcbiAgfVxuICBcbiAgaW9uLWFjY29yZGlvbi5hY2NvcmRpb24tYW5pbWF0ZWQgLmlvbi1hY2NvcmRpb24tdG9nZ2xlLWljb24ge1xuICAgIGNvbG9yOiAjZmZmICFpbXBvcnRhbnQ7XG4gIH1cbiAgXG4gIC8vIC5teS1jdXN0b20tbW9kYWwtY3NzIC5tb2RhbC13cmFwcGVyIHtcbiAgLy8gICBoZWlnaHQ6IDIwJTtcbiAgLy8gICB3aWR0aDogMjAlO1xuICAvLyAgIHBvc2l0aW9uOiBhYnNvbHV0ZTsgXG4gIC8vICAgZGlzcGxheTogYmxvY2s7ICBcbiAgLy8gfVxuICBcbiAgXG4gIFxuICAvKiBUaGUgY29udGFpbmVyIG11c3QgYmUgcG9zaXRpb25lZCByZWxhdGl2ZTogKi9cbiAgaW9uLWl0ZW0gLmN1c3RvbS1zZWxlY3Qge1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICBmb250LWZhbWlseTogQXJpYWw7XG4gIH1cbiAgXG4gIGlvbi1pdGVtIC5jdXN0b20tc2VsZWN0IHNlbGVjdCB7XG4gICAgZGlzcGxheTogbm9uZTtcbiAgICAvKmhpZGUgb3JpZ2luYWwgU0VMRUNUIGVsZW1lbnQ6ICovXG4gIH1cbiAgXG4gIHNlbGVjdCB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgYmFja2dyb3VuZDogd2hpdGU7XG4gICAgY29sb3I6ICMyMjI7XG4gICAgcGFkZGluZzogN3B4O1xuICAgIGJvcmRlcjogMC41cHggc29saWQgI2RkZDtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIC8vIGJveC1zaGFkb3c6IDAgMCAxMHB4IDEwMHB4ICNmZmYgaW5zZXQ7XG4gICAgb3V0bGluZTogbm9uZVxuICB9XG4gIFxuICBzZWxlY3Q6YWN0aXZlLFxuICBzZWxlY3Q6aG92ZXIge1xuICAgIG91dGxpbmU6IG5vbmVcbiAgfVxuICBcbiAgXG4gIHNlbGVjdDpmb2N1cyB7XG4gICAgYm9yZGVyLWNvbG9yOiBncmF5O1xuICAgIG91dGxpbmU6IG5vbmU7XG4gIH1cbiJdfQ== */";

/***/ }),

/***/ 1943:
/*!************************************************************************************!*\
  !*** ./src/app/pages/employee-onboarding/employee-onboarding.page.html?ngResource ***!
  \************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar color=\"gray\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>Employee Onboarding</ion-title>\n  </ion-toolbar>\n  <ion-toolbar color=\"tertiary\">\n    <ion-segment [(ngModel)]=\"segment\" style=\"margin: 0;\">\n      <ion-segment-button value=\"user\" disabled=\"true\">\n        <ion-text>\n          Basic Details\n        </ion-text>\n      </ion-segment-button>\n      <ion-segment-button value=\"card\" disabled=\"true\">\n        <ion-text>\n          Company Details\n        </ion-text>\n      </ion-segment-button>\n    </ion-segment>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <!-- <div style=\"margin: 20px;\n  background-color: #3c40c6;\n  color: #fff;\n  font-size: 16px;\n  padding: 10px;\n  font-weight: bold;\n  border-radius: 10px;\">\n    The Add Employee wizard guides you through the process of adding a new employee. You have the flexibility to enter\n    comprehensive information about a new employee as soon as the person joins or first add salient details and update\n    remaining details later.\n  </div> -->\n\n  <div>\n    \n  </div>\n\n\n  <div>\n    <ion-row>\n      <ion-col sizeLg=\"10\" offsetLg=\"1\" *ngIf=\"segment=='user'\">\n        <!-- <ion-card> -->\n        <!-- <ion-card-header>\n        User Info\n      </ion-card-header>\n      <ion-card-content> -->\n        <form [formGroup]=\"basic\">\n          <!-- <ion-card> -->\n          <ion-list id=\"inbox-list\" lines=\"none\" style=\"background: transparent;padding:10px 20px;\">\n            <ion-row style=\"padding-bottom: 10px;\">\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">First Name*</ion-label>\n                  <ion-input formControlName=\"firstName\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Middle name</ion-label>\n                  <ion-input formControlName=\"middleName\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Last name*</ion-label>\n                  <ion-input formControlName=\"lastName\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"8\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Designation</ion-label>\n                  <ion-input formControlName=\"designation\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Gender*</ion-label>\n                  <select formControlName=\"gender\" style=\"width: 100%;\n                      background: #2c2d2e; color: #fff; padding: 7px;border: 0.5px solid rgb(83, 83, 83)\">\n                    <option value=\"Male\">Male</option>\n                    <option value=\"Female\">Female</option>\n                    <option value=\"Others\">Others</option>\n                  </select>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Phone Number*</ion-label>\n                  <ion-input type=\"number\" formControlName=\"phoneNo\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Personal Email*</ion-label>\n                  <ion-input formControlName=\"personalEmail\"></ion-input>\n                </ion-item>\n              </ion-col>\n            </ion-row>\n            <ion-row style=\"padding-bottom: 10px;\">\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Spouse Name</ion-label>\n                  <ion-input formControlName=\"spouseName\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Father Name*</ion-label>\n                  <ion-input type=\"text\" formControlName=\"fatherName\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <!-- <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Date of Birth*</ion-label>\n                  <ion-input type=\"date\" formControlName=\"DOB\"></ion-input>\n                </ion-item>\n              </ion-col> -->\n              <!-- <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Emergency Contact Name*</ion-label>\n                  <ion-input formControlName=\"emergencyContactName\"></ion-input>\n                </ion-item>\n              </ion-col> -->\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Emergency Contact Number*</ion-label>\n                  <ion-input type=\"number\" formControlName=\"emergencyContactNumber\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <!-- <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Pan Number*</ion-label>\n                  <ion-input formControlName=\"panNumber\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Aadhar Number*</ion-label>\n                  <ion-input formControlName=\"adharNumber\"></ion-input>\n                </ion-item>\n              </ion-col> -->\n            </ion-row>\n            <ion-row style=\"padding-bottom: 10px;\">\n              <ion-col size=\"6\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Present Address*</ion-label>\n                  <ion-input formControlName=\"presentAddress\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"6\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Permanent Address*</ion-label>\n                  <ion-input formControlName=\"permanentAddress\"></ion-input>\n                </ion-item>\n              </ion-col>\n            </ion-row>\n            <ion-row style=\"padding-bottom: 10px;\">\n            </ion-row>\n          </ion-list>\n          <!-- </ion-card-content> -->\n        </form>\n        <!-- </ion-card> -->\n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col sizeLg=\"10\" offsetLg=\"1\" *ngIf=\"segment=='card'\">\n        <!-- <ion-card> -->\n        <form [formGroup]=\"company\">\n          <!-- <ion-card> -->\n          <ion-list id=\"inbox-list\" lines=\"none\" style=\"background: transparent;padding:10px 20px;\">\n            <ion-row style=\"padding-bottom: 10px;\">\n              <!-- <ion-col size=\"4\">\n                  <ion-item>\n                    <ion-label position=\"stacked\">Employee Id*</ion-label>\n                    <ion-input [(ngModel)]=\"employeeId\"></ion-input>\n                  </ion-item>\n                </ion-col> -->\n              <!-- <ion-col size=\"4\">\n                  <ion-item>\n                    <ion-label position=\"stacked\">Appraisal Days*</ion-label>\n                    <ion-input formControlName=\"appraisalDays\"></ion-input>\n                  </ion-item>\n                </ion-col> -->\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Date of Joining*</ion-label>\n                  <ion-input type=\"date\" formControlName=\"DOJ\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <!-- <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Department*</ion-label>\n                  <ion-input formControlName=\"employeeType\"></ion-input>\n                </ion-item>\n              </ion-col> -->\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Employee Type*</ion-label>\n                  <select formControlName=\"employeeType\" style=\"width: 100%;\n                      background: #2c2d2e; color: #fff; padding: 7px;border: 0.5px solid rgb(83, 83, 83)\">\n                    <option value=\"1\">Full Time</option>\n                    <option value=\"2\">Part Time</option>\n                    <option value=\"3\">Contract</option>\n                    <option value=\"4\">Intern</option>\n                  </select>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Company Branch*</ion-label>\n                  <ion-input formControlName=\"companyBranch\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Official Email*</ion-label>\n                  <ion-input formControlName=\"officialEmail\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Password*</ion-label>\n                  <ion-input formControlName=\"password\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Basic Salary*</ion-label>\n                  <ion-input formControlName=\"basicSalary\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Total Salary*</ion-label>\n                  <ion-input formControlName=\"totalSalary\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">User Group*</ion-label>\n                  <select formControlName=\"userGroup\" style=\"width: 100%;\n                  background: #2c2d2e; color: #fff; padding: 7px;border: 0.5px solid rgb(83, 83, 83)\">\n                    <option *ngFor=\"let group of userGroups\" [value]=\"group.userGroupId\">{{group.groupName}}</option>\n                  </select>\n                </ion-item>\n              </ion-col>\n            </ion-row>\n          </ion-list>\n        </form>\n        <!-- </ion-card> -->\n      </ion-col>\n    </ion-row>\n  </div>\n</ion-content>\n<ion-footer class=\"ion-no-border\" color=\"gray\">\n  <ion-toolbar color=\"gray\">\n    <ion-buttons slot=\"end\">\n      <ion-button *ngIf=\"segment=='user'\" expand=\"block\" fill=\"solid\" color=\"success\"\n        style=\"font-weight: 300;width: 150px;\" (click)=\"nextTab()\">Next</ion-button>\n      <ion-button *ngIf=\"segment=='card'\" expand=\"block\" fill=\"clear\" color=\"dark\"\n        style=\"font-weight: 300;width: 150px;\" (click)=\"previousTab()\"><span style=\"color: #fff;\">Previous</span>\n      </ion-button>\n      <ion-button *ngIf=\"segment=='card' && !updateFlag\" expand=\"block\" fill=\"solid\" color=\"success\"\n        style=\"font-weight: 300;width: 150px;\" (click)=\"register()\">Create</ion-button>\n      <ion-button *ngIf=\"segment=='card' && updateFlag\" expand=\"block\" fill=\"solid\" color=\"success\"\n        style=\"font-weight: 300;width: 150px;\" (click)=\"updateEmployee()\">Update</ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-footer>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_employee-onboarding_employee-onboarding_module_ts.js.map