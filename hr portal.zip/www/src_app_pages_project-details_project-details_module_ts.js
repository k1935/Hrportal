"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_project-details_project-details_module_ts"],{

/***/ 1334:
/*!*************************************************************************!*\
  !*** ./src/app/pages/project-details/project-details-routing.module.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProjectDetailsPageRoutingModule": () => (/* binding */ ProjectDetailsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _project_details_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./project-details.page */ 3215);




const routes = [
    {
        path: '',
        component: _project_details_page__WEBPACK_IMPORTED_MODULE_0__.ProjectDetailsPage
    }
];
let ProjectDetailsPageRoutingModule = class ProjectDetailsPageRoutingModule {
};
ProjectDetailsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ProjectDetailsPageRoutingModule);



/***/ }),

/***/ 1906:
/*!*****************************************************************!*\
  !*** ./src/app/pages/project-details/project-details.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProjectDetailsPageModule": () => (/* binding */ ProjectDetailsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _project_details_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./project-details-routing.module */ 1334);
/* harmony import */ var _project_details_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./project-details.page */ 3215);
/* harmony import */ var ngx_quill__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-quill */ 3115);








let ProjectDetailsPageModule = class ProjectDetailsPageModule {
};
ProjectDetailsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            ngx_quill__WEBPACK_IMPORTED_MODULE_6__.QuillModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _project_details_routing_module__WEBPACK_IMPORTED_MODULE_0__.ProjectDetailsPageRoutingModule
        ],
        declarations: [_project_details_page__WEBPACK_IMPORTED_MODULE_1__.ProjectDetailsPage]
    })
], ProjectDetailsPageModule);



/***/ }),

/***/ 3215:
/*!***************************************************************!*\
  !*** ./src/app/pages/project-details/project-details.page.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProjectDetailsPage": () => (/* binding */ ProjectDetailsPage)
/* harmony export */ });
/* harmony import */ var _Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _project_details_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./project-details.page.html?ngResource */ 7600);
/* harmony import */ var _project_details_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./project-details.page.scss?ngResource */ 877);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/common.service */ 5620);
/* harmony import */ var _services_project_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/project.service */ 354);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);










 // import 'quill-mention';
// import 'quill-emoji';

let ProjectDetailsPage = class ProjectDetailsPage {
  constructor(commonService, projectService, activated, router, formBuilder, loadingController) {
    this.commonService = commonService;
    this.projectService = projectService;
    this.activated = activated;
    this.router = router;
    this.formBuilder = formBuilder;
    this.loadingController = loadingController;
    this.segment = 'details';
    this.userGroups = [];
    this.updateFlag = false;
    this.htmlText = "<p>Testing</p>";
    this.hasFocus = false;
    this.data = ['India', 'Sri Lanka'];
    this.allUsers = [];
    this.allProjectMembers = [];
    this.newProject = [];
    this.allEmployees = [];
    this.atValues = [{
      id: 1,
      value: 'Fredrik Sundqvist',
      link: 'https://google.com'
    }, {
      id: 2,
      value: 'Patrik Sjölin'
    }];
    this.hashValues = [{
      id: 3,
      value: 'Fredrik Sundqvist 2'
    }, {
      id: 4,
      value: 'Patrik Sjölin 2'
    }];
    this.quillConfig = {
      //toolbar: '.toolbar',
      toolbar: {
        container: [['bold', 'italic', 'underline', 'strike'], ['code-block'], [{
          'header': 1
        }, {
          'header': 2
        }], [{
          'list': 'ordered'
        }, {
          'list': 'bullet'
        }], [{
          'script': 'sub'
        }, {
          'script': 'super'
        }], [{
          'indent': '-1'
        }, {
          'indent': '+1'
        }], [{
          'direction': 'rtl'
        }], [{
          'size': ['small', false, 'large', 'huge']
        }], [{
          'header': [1, 2, 3, 4, 5, 6, false]
        }], [{
          'font': []
        }], [{
          'align': []
        }], ['clean'], ['link'] // ['link', 'image', 'video']  
        ]
      },
      "emoji-toolbar": false,
      "emoji-textarea": false,
      "emoji-shortname": false,
      keyboard: {
        bindings: {
          enter: {
            key: 13,
            handler: (range, context) => {
              console.log("enter");
              return true;
            }
          }
        }
      }
    };

    this.onSelectionChanged = event => {
      if (event.oldRange == null) {
        this.onFocus();
      }

      if (event.range == null) {
        this.onBlur();
      }
    };

    this.onContentChanged = event => {//console.log(event.html);
    };

    this.onFocus = () => {
      console.log("On Focus");
    };

    this.onBlur = () => {
      console.log("Blurred");
    };

    this.basic = this.formBuilder.group({
      projectName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      startDate: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      estimatedHours: [''],
      clientName: [''],
      projectStatus: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      // projectManager: ['', Validators.required],
      projectStage: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      projectType: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      projectDescription: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required]
    });
  }

  ngOnInit() {
    this.projectId = this.activated.snapshot.params.id;
    console.log("projectId", this.projectId);

    if (this.projectId != "null") {
      this.getOneProject();
      this.updateFlag = true;
    } else {
      this.commonService.getEmployeeList().then(resp => {
        this.allEmployees = resp;
      });
    }

    this.commonService.fetchAllUserGroups().then(resp => {
      this.userGroups = resp;
    });
  }

  saveProject() {
    if (this.basic.valid) {
      this.commonService.presentLoading();
      let formData = Object.assign(this.basic.value, {
        members: this.allProjectMembers
      });
      this.projectService.createProject(formData).then(resp => {
        this.commonService.loadingDismiss();
        this.segment = 'members';
        this.projectId = resp.projectId;
        this.commonService.showToast("success", "Project Created! Add Members.."); // this.router.navigate(['/projects']);
      });
    } else {
      this.commonService.showToast("error", "Fill all required details..");
    }
  }

  updateProject() {
    if (this.basic.valid) {
      this.commonService.presentLoading();
      let formData = Object.assign(this.basic.value, {
        projectId: this.projectId
      });
      formData.startDate = this.commonService.formatDate(formData.startDate);
      this.projectService.updateProject(formData).then(resp => {
        this.commonService.loadingDismiss();
        this.commonService.showToast("success", "Project Updated!");
        this.router.navigate(['/projects']);
      });
    }
  }

  getProjectMembers() {
    let formData = {
      projectId: this.projectId
    };
    this.projectService.getProjectMembers(formData).then(resp => {
      console.log("getProjectMembers", resp);
      this.allProjectMembers = resp;
      this.allUsers = resp;
    });
  }

  getOneProject() {
    let formData = {
      projectId: this.projectId
    };
    this.getProjectMembers();
    this.commonService.presentLoading();
    this.projectService.getOneProject(formData).then(resp => {
      console.log("getOneProject ", resp);
      this.basic.patchValue(resp);
      this.commonService.loadingDismiss();
    });
  }

  checkInTeam(user) {
    let employee = this.allProjectMembers.filter(r => r.employeeId == user.employeeId);
    if (employee.length > 0) return false;else return true;
  }

  addEmployeeTeam(user) {
    this.allProjectMembers.push(user);

    if (this.projectId) {
      user.projectId = this.projectId;
      this.projectService.addProjectMember(user).then(resp => {
        user.id = resp.id;
      });
    }
  }

  removeProjectMember(user) {
    let index = this.allProjectMembers.indexOf(user);
    this.allProjectMembers.splice(index, 1);

    if (this.projectId) {
      user.projectId = this.projectId;
      this.projectService.removeProjectMember(user).then(resp => {});
    }
  }

  searchEmployee(ev) {
    if (ev.target.value.length > 0) {
      this.commonService.searchEmployees(ev.target.value).then(resp => {
        this.allUsers = resp;
        let fieldData;

        for (let i = 0; i < this.allUsers.length; i++) {
          fieldData = this.allProjectMembers.filter(res => res.officialEmail == this.allUsers[i].officialEmail)[0];
          if (fieldData && fieldData.type) this.allUsers[i].type = fieldData.type;
          if (fieldData && fieldData.billable) this.allUsers[i].billable = fieldData.billable;
          if (fieldData && fieldData.hoursAssign) this.allUsers[i].hoursAssign = fieldData.hoursAssign;
        }
      });
    } else {
      this.allUsers = this.allProjectMembers;
    }
  }

  getEmployeesByIds(employeeIds) {
    console.log("employeeIds  ", employeeIds);
    this.commonService.getEmployeesByIds(employeeIds).then(resp => {
      this.allUsers = resp;
    });
  }

  selectRole(user) {
    console.log(user.type);
    let form = {
      memberId: user.id,
      type: user.type
    };
    this.projectService.updateProjectMember(form).then(resp => {});
  }

  selectBillable(user) {
    console.log(user.type);
    let form = {
      memberId: user.id,
      billable: user.billable
    };
    this.projectService.updateProjectMember(form).then(resp => {});
  }

  selectHours(user) {
    console.log(user.type);
    let form = {
      memberId: user.id,
      hoursAssign: user.hoursAssign
    };
    this.projectService.updateProjectMember(form).then(resp => {});
  }

  presentLoadingWithOptions() {
    var _this = this;

    return (0,_Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.loading = yield _this.loadingController.create({
        spinner: "circles",
        // duration: 1000,
        message: 'Please wait...',
        translucent: true,
        cssClass: 'custom-class custom-loading'
      });
      return yield _this.loading.present();
    })();
  }

};

ProjectDetailsPage.ctorParameters = () => [{
  type: _services_common_service__WEBPACK_IMPORTED_MODULE_3__.CommonService
}, {
  type: _services_project_service__WEBPACK_IMPORTED_MODULE_4__.ProjectService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.ActivatedRoute
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router
}, {
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.LoadingController
}];

ProjectDetailsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-project-details',
  template: _project_details_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_project_details_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], ProjectDetailsPage);


/***/ }),

/***/ 354:
/*!*********************************************!*\
  !*** ./src/app/services/project.service.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProjectService": () => (/* binding */ ProjectService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth.service */ 7556);




let ProjectService = class ProjectService {
    constructor(authService, http) {
        this.authService = authService;
        this.http = http;
    }
    createProject(projectObject) {
        projectObject.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'createProject', projectObject).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateProject(projectObject) {
        projectObject.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'updateProject', projectObject).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getOneProject(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getOneProject', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getProjectMembers(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getProjectMembers', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    addProjectMember(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'addProjectMember', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    removeProjectMember(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'removeProjectMember', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateProjectMember(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'updateProjectMember', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    fetchAllProjects(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'fetchAllProjects', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getMemberProjects() {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getMemberProjects', { employeeId: this.authService.userId }).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getTeamsReporting() {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getTeamsReporting', { userId: this.authService.userId }).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    createEpic(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'createEpic', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateProjectEpic(epicData) {
        let newEpic = Object.assign(epicData);
        newEpic['id'] = newEpic.id.replace('epic', '');
        console.log("updateProjectEpic epicData ", epicData);
        console.log("updateProjectEpic newEpic ", newEpic);
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'epicUpdate', newEpic).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getProjectEpics(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getProjectEpics', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    createStory(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'createStory', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateEpicStory(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'storyUpdate', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getEpicStories(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getStories', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    createStoryTask(taskData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'createStoryTask', taskData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getStoryTasks(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getStoryTasks', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getProjectColumns(projectData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getProjectColumns', projectData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateProjectTask(task) {
        return new Promise((resolve, reject) => {
            task.organisationId = this.authService.organisationId;
            this.http.post(this.authService.apiUrl + 'updateProjectTask', task).subscribe((resp) => {
                console.log("rsp", resp);
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
};
ProjectService.ctorParameters = () => [
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
ProjectService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], ProjectService);



/***/ }),

/***/ 877:
/*!****************************************************************************!*\
  !*** ./src/app/pages/project-details/project-details.page.scss?ngResource ***!
  \****************************************************************************/
/***/ ((module) => {

module.exports = "ion-menu ion-content {\n  --background: var(--ion-item-background, var(--ion-background-color, #fff));\n}\n\nion-menu.md ion-content {\n  --padding-start: 8px;\n  --padding-end: 8px;\n  --padding-top: 20px;\n  --padding-bottom: 20px;\n}\n\nion-menu.md ion-list {\n  padding: 20px 0;\n}\n\nion-menu.md ion-note {\n  margin-bottom: 30px;\n}\n\nion-menu.md ion-list-header,\nion-menu.md ion-note {\n  padding-left: 10px;\n}\n\nion-menu.md ion-list#inbox-list {\n  border-bottom: 1px solid var(--ion-color-step-150, #d7d8da);\n}\n\nion-menu.md ion-list#inbox-list ion-list-header {\n  font-size: 22px;\n  font-weight: 600;\n  min-height: 20px;\n}\n\nion-menu.md ion-list#labels-list ion-list-header {\n  font-size: 16px;\n  margin-bottom: 18px;\n  color: #757575;\n  min-height: 26px;\n}\n\nion-menu.md ion-item {\n  --padding-start: 10px;\n  --padding-end: 10px;\n  border-radius: 4px;\n}\n\nion-menu.md ion-item.selected {\n  --background: rgba(var(--ion-color-primary-rgb), 0.14);\n}\n\nion-menu.md ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.md ion-item ion-icon {\n  color: #616e7e;\n}\n\nion-menu.md ion-item ion-label {\n  font-weight: 500;\n}\n\nion-menu.ios ion-content {\n  --padding-bottom: 20px;\n}\n\nion-menu.ios ion-list {\n  padding: 20px 0 0 0;\n}\n\nion-menu.ios ion-note {\n  line-height: 24px;\n  margin-bottom: 20px;\n}\n\nion-menu.ios ion-item {\n  --padding-start: 16px;\n  --padding-end: 16px;\n  --min-height: 50px;\n}\n\nion-menu.ios ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.ios ion-item ion-icon {\n  font-size: 24px;\n  color: #73849a;\n}\n\nion-menu.ios ion-list#labels-list ion-list-header {\n  margin-bottom: 8px;\n}\n\nion-menu.ios ion-list-header,\nion-menu.ios ion-note {\n  padding-left: 16px;\n  padding-right: 16px;\n}\n\nion-menu.ios ion-note {\n  margin-bottom: 8px;\n}\n\nion-note {\n  display: inline-block;\n  font-size: 16px;\n  color: var(--ion-color-medium-shade);\n}\n\nion-item.selected {\n  --color: var(--ion-color-primary);\n}\n\nion-list {\n  background: #f7f7f7;\n  padding: 10px;\n}\n\nion-item {\n  --background: transparent;\n}\n\nion-input {\n  border: 0.5px solid rgb(83, 83, 83);\n  background: #161b22;\n  border-radius: 10px;\n  padding: 0px 10px !important;\n  color: #fff;\n}\n\nion-accordion {\n  background: #112c44;\n  color: #fff;\n}\n\nion-accordion.accordion-expanding .ion-accordion-toggle-icon,\nion-accordion.accordion-expanded .ion-accordion-toggle-icon {\n  color: #fff !important;\n}\n\nion-accordion.accordion-animated .ion-accordion-toggle-icon {\n  color: #fff !important;\n}\n\nion-accordion.accordion-animated .ion-accordion-toggle-icon {\n  color: #fff !important;\n}\n\n/* The container must be positioned relative: */\n\nion-item .custom-select {\n  position: relative;\n  font-family: Arial;\n}\n\nion-item .custom-select select {\n  display: none;\n  /*hide original SELECT element: */\n}\n\nselect {\n  width: 100%;\n  background: white;\n  color: #222;\n  padding: 7px;\n  border: 0.5px solid #ddd;\n  border-radius: 10px;\n  outline: none;\n}\n\nselect:active,\nselect:hover {\n  outline: none;\n}\n\nselect:focus {\n  border-color: gray;\n  outline: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2plY3QtZGV0YWlscy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSwyRUFBQTtBQUNGOztBQUVBO0VBQ0Usb0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0Esc0JBQUE7QUFDRjs7QUFFQTtFQUNFLGVBQUE7QUFDRjs7QUFFQTtFQUNFLG1CQUFBO0FBQ0Y7O0FBRUE7O0VBRUUsa0JBQUE7QUFDRjs7QUFFQTtFQUNFLDJEQUFBO0FBQ0Y7O0FBRUE7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFFQSxnQkFBQTtBQUFGOztBQUdBO0VBQ0UsZUFBQTtFQUVBLG1CQUFBO0VBRUEsY0FBQTtFQUVBLGdCQUFBO0FBSEY7O0FBTUE7RUFDRSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUFIRjs7QUFNQTtFQUNFLHNEQUFBO0FBSEY7O0FBTUE7RUFDRSwrQkFBQTtBQUhGOztBQU1BO0VBQ0UsY0FBQTtBQUhGOztBQU1BO0VBQ0UsZ0JBQUE7QUFIRjs7QUFNQTtFQUNFLHNCQUFBO0FBSEY7O0FBTUE7RUFDRSxtQkFBQTtBQUhGOztBQU1BO0VBQ0UsaUJBQUE7RUFDQSxtQkFBQTtBQUhGOztBQU1BO0VBQ0UscUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FBSEY7O0FBTUE7RUFDRSwrQkFBQTtBQUhGOztBQU1BO0VBQ0UsZUFBQTtFQUNBLGNBQUE7QUFIRjs7QUFNQTtFQUNFLGtCQUFBO0FBSEY7O0FBTUE7O0VBRUUsa0JBQUE7RUFDQSxtQkFBQTtBQUhGOztBQU1BO0VBQ0Usa0JBQUE7QUFIRjs7QUFNQTtFQUNFLHFCQUFBO0VBQ0EsZUFBQTtFQUVBLG9DQUFBO0FBSkY7O0FBT0E7RUFDRSxpQ0FBQTtBQUpGOztBQU9BO0VBQ0UsbUJBQUE7RUFDQSxhQUFBO0FBSkY7O0FBUUE7RUFDRSx5QkFBQTtBQUxGOztBQVFBO0VBQ0UsbUNBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsNEJBQUE7RUFDQSxXQUFBO0FBTEY7O0FBWUE7RUFDRSxtQkFBQTtFQUNBLFdBQUE7QUFURjs7QUFjQTs7RUFFRSxzQkFBQTtBQVhGOztBQWVBO0VBQ0Usc0JBQUE7QUFaRjs7QUFlQTtFQUNFLHNCQUFBO0FBWkY7O0FBd0JBLCtDQUFBOztBQUNBO0VBQ0Usa0JBQUE7RUFDQSxrQkFBQTtBQXJCRjs7QUF3QkE7RUFDRSxhQUFBO0VBQ0EsaUNBQUE7QUFyQkY7O0FBd0JBO0VBQ0UsV0FBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSx3QkFBQTtFQUNBLG1CQUFBO0VBRUEsYUFBQTtBQXRCRjs7QUF5QkE7O0VBRUUsYUFBQTtBQXRCRjs7QUEwQkE7RUFDRSxrQkFBQTtFQUNBLGFBQUE7QUF2QkYiLCJmaWxlIjoicHJvamVjdC1kZXRhaWxzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1tZW51IGlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24taXRlbS1iYWNrZ3JvdW5kLCB2YXIoLS1pb24tYmFja2dyb3VuZC1jb2xvciwgI2ZmZikpO1xufVxuXG5pb24tbWVudS5tZCBpb24tY29udGVudCB7XG4gIC0tcGFkZGluZy1zdGFydDogOHB4O1xuICAtLXBhZGRpbmctZW5kOiA4cHg7XG4gIC0tcGFkZGluZy10b3A6IDIwcHg7XG4gIC0tcGFkZGluZy1ib3R0b206IDIwcHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0IHtcbiAgcGFkZGluZzogMjBweCAwO1xufVxuXG5pb24tbWVudS5tZCBpb24tbm90ZSB7XG4gIG1hcmdpbi1ib3R0b206IDMwcHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0LWhlYWRlcixcbmlvbi1tZW51Lm1kIGlvbi1ub3RlIHtcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xufVxuXG5pb24tbWVudS5tZCBpb24tbGlzdCNpbmJveC1saXN0IHtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1zdGVwLTE1MCwgI2Q3ZDhkYSk7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0I2luYm94LWxpc3QgaW9uLWxpc3QtaGVhZGVyIHtcbiAgZm9udC1zaXplOiAyMnB4O1xuICBmb250LXdlaWdodDogNjAwO1xuICBcbiAgbWluLWhlaWdodDogMjBweDtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWxpc3QjbGFiZWxzLWxpc3QgaW9uLWxpc3QtaGVhZGVyIHtcbiAgZm9udC1zaXplOiAxNnB4O1xuXG4gIG1hcmdpbi1ib3R0b206IDE4cHg7XG5cbiAgY29sb3I6ICM3NTc1NzU7XG5cbiAgbWluLWhlaWdodDogMjZweDtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWl0ZW0ge1xuICAtLXBhZGRpbmctc3RhcnQ6IDEwcHg7XG4gIC0tcGFkZGluZy1lbmQ6IDEwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDRweDtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWl0ZW0uc2VsZWN0ZWQge1xuICAtLWJhY2tncm91bmQ6IHJnYmEodmFyKC0taW9uLWNvbG9yLXByaW1hcnktcmdiKSwgMC4xNCk7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtLnNlbGVjdGVkIGlvbi1pY29uIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWl0ZW0gaW9uLWljb24ge1xuICBjb2xvcjogIzYxNmU3ZTtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWl0ZW0gaW9uLWxhYmVsIHtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1jb250ZW50IHtcbiAgLS1wYWRkaW5nLWJvdHRvbTogMjBweDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1saXN0IHtcbiAgcGFkZGluZzogMjBweCAwIDAgMDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1ub3RlIHtcbiAgbGluZS1oZWlnaHQ6IDI0cHg7XG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XG59XG5cbmlvbi1tZW51LmlvcyBpb24taXRlbSB7XG4gIC0tcGFkZGluZy1zdGFydDogMTZweDtcbiAgLS1wYWRkaW5nLWVuZDogMTZweDtcbiAgLS1taW4taGVpZ2h0OiA1MHB4O1xufVxuXG5pb24tbWVudS5pb3MgaW9uLWl0ZW0uc2VsZWN0ZWQgaW9uLWljb24ge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuXG5pb24tbWVudS5pb3MgaW9uLWl0ZW0gaW9uLWljb24ge1xuICBmb250LXNpemU6IDI0cHg7XG4gIGNvbG9yOiAjNzM4NDlhO1xufVxuXG5pb24tbWVudS5pb3MgaW9uLWxpc3QjbGFiZWxzLWxpc3QgaW9uLWxpc3QtaGVhZGVyIHtcbiAgbWFyZ2luLWJvdHRvbTogOHB4O1xufVxuXG5pb24tbWVudS5pb3MgaW9uLWxpc3QtaGVhZGVyLFxuaW9uLW1lbnUuaW9zIGlvbi1ub3RlIHtcbiAgcGFkZGluZy1sZWZ0OiAxNnB4O1xuICBwYWRkaW5nLXJpZ2h0OiAxNnB4O1xufVxuXG5pb24tbWVudS5pb3MgaW9uLW5vdGUge1xuICBtYXJnaW4tYm90dG9tOiA4cHg7XG59XG5cbmlvbi1ub3RlIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBmb250LXNpemU6IDE2cHg7XG5cbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0tc2hhZGUpO1xufVxuXG5pb24taXRlbS5zZWxlY3RlZCB7XG4gIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn1cblxuaW9uLWxpc3Qge1xuICBiYWNrZ3JvdW5kOiAjZjdmN2Y3O1xuICBwYWRkaW5nOiAxMHB4O1xufVxuXG5cbmlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cblxuaW9uLWlucHV0IHtcbiAgYm9yZGVyOiAwLjVweCBzb2xpZCByZ2IoODMsIDgzLCA4Myk7XG4gIGJhY2tncm91bmQ6ICMxNjFiMjI7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gIHBhZGRpbmc6IDBweCAxMHB4ICFpbXBvcnRhbnQ7XG4gIGNvbG9yOiAjZmZmO1xufVxuXG4vLyBpbnB1dCB7XG4vLyAgIHBhZGRpbmc6IDEwcHggIWltcG9ydGFudDtcbi8vIH1cblxuaW9uLWFjY29yZGlvbiB7XG4gIGJhY2tncm91bmQ6ICMxMTJjNDQ7XG4gIGNvbG9yOiAjZmZmO1xuICAvLyBiYWNrZ3JvdW5kOiAjNzQ4Y2IyO1xufVxuXG5cbmlvbi1hY2NvcmRpb24uYWNjb3JkaW9uLWV4cGFuZGluZyAuaW9uLWFjY29yZGlvbi10b2dnbGUtaWNvbixcbmlvbi1hY2NvcmRpb24uYWNjb3JkaW9uLWV4cGFuZGVkIC5pb24tYWNjb3JkaW9uLXRvZ2dsZS1pY29uIHtcbiAgY29sb3I6ICNmZmYgIWltcG9ydGFudDtcbn1cblxuXG5pb24tYWNjb3JkaW9uLmFjY29yZGlvbi1hbmltYXRlZCAuaW9uLWFjY29yZGlvbi10b2dnbGUtaWNvbiB7XG4gIGNvbG9yOiAjZmZmICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1hY2NvcmRpb24uYWNjb3JkaW9uLWFuaW1hdGVkIC5pb24tYWNjb3JkaW9uLXRvZ2dsZS1pY29uIHtcbiAgY29sb3I6ICNmZmYgIWltcG9ydGFudDtcbn1cblxuLy8gLm15LWN1c3RvbS1tb2RhbC1jc3MgLm1vZGFsLXdyYXBwZXIge1xuLy8gICBoZWlnaHQ6IDIwJTtcbi8vICAgd2lkdGg6IDIwJTtcbi8vICAgcG9zaXRpb246IGFic29sdXRlOyBcbi8vICAgZGlzcGxheTogYmxvY2s7ICBcbi8vIH1cblxuXG5cbi8qIFRoZSBjb250YWluZXIgbXVzdCBiZSBwb3NpdGlvbmVkIHJlbGF0aXZlOiAqL1xuaW9uLWl0ZW0gLmN1c3RvbS1zZWxlY3Qge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGZvbnQtZmFtaWx5OiBBcmlhbDtcbn1cblxuaW9uLWl0ZW0gLmN1c3RvbS1zZWxlY3Qgc2VsZWN0IHtcbiAgZGlzcGxheTogbm9uZTtcbiAgLypoaWRlIG9yaWdpbmFsIFNFTEVDVCBlbGVtZW50OiAqL1xufVxuXG5zZWxlY3Qge1xuICB3aWR0aDogMTAwJTtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIGNvbG9yOiAjMjIyO1xuICBwYWRkaW5nOiA3cHg7XG4gIGJvcmRlcjogMC41cHggc29saWQgI2RkZDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgLy8gYm94LXNoYWRvdzogMCAwIDEwcHggMTAwcHggI2ZmZiBpbnNldDtcbiAgb3V0bGluZTogbm9uZVxufVxuXG5zZWxlY3Q6YWN0aXZlLFxuc2VsZWN0OmhvdmVyIHtcbiAgb3V0bGluZTogbm9uZVxufVxuXG5cbnNlbGVjdDpmb2N1cyB7XG4gIGJvcmRlci1jb2xvcjogZ3JheTtcbiAgb3V0bGluZTogbm9uZTtcbn1cbiJdfQ== */";

/***/ }),

/***/ 7600:
/*!****************************************************************************!*\
  !*** ./src/app/pages/project-details/project-details.page.html?ngResource ***!
  \****************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar color=\"gray\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>Project Details</ion-title>\n  </ion-toolbar>\n  <ion-toolbar color=\"tertiary\">\n    <ion-segment [(ngModel)]=\"segment\" style=\"margin: 0;\">\n      <ion-segment-button value=\"details\">\n        <ion-text>\n          Details\n        </ion-text>\n      </ion-segment-button>\n      <ion-segment-button [disabled]=\"projectId == 'null'\" value='members'>\n        <ion-text>\n          Members\n        </ion-text>\n      </ion-segment-button>\n    </ion-segment>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <ion-row>\n    <ion-col sizeLg=\"10\" offsetLg=\"1\" *ngIf=\"segment=='details'\">\n      <form [formGroup]=\"basic\">\n        <ion-list lines=\"none\" style=\"background: transparent;\">\n          <ion-row style=\"padding-bottom: 10px;\">\n            <ion-col size=\"6\">\n              <ion-item>\n                <ion-label position=\"stacked\" style=\"color: #fff;\">Project Name*</ion-label>\n                <ion-input formControlName=\"projectName\"></ion-input>\n              </ion-item>\n            </ion-col>\n            <ion-col size=\"6\">\n              <ion-item>\n                <ion-label position=\"stacked\" style=\"color: #fff;\">Client</ion-label>\n                <ion-input formControlName=\"clientName\"></ion-input>\n              </ion-item>\n            </ion-col>\n            <ion-col size=\"4\">\n              <ion-item>\n                <ion-label position=\"stacked\" style=\"color: #fff;\">Estimated Hours*</ion-label>\n                <ion-input type=\"number\" formControlName=\"estimatedHours\"></ion-input>\n              </ion-item>\n            </ion-col>\n            <ion-col size=\"4\">\n              <ion-item>\n                <ion-label position=\"stacked\" style=\"color: #fff;\">Start Date*</ion-label>\n                <ion-input type=\"date\" formControlName=\"startDate\"></ion-input>\n              </ion-item>\n            </ion-col>\n            <ion-col size=\"4\">\n              <ion-item>\n                <ion-label position=\"stacked\" style=\"color: #fff;\">Project Status</ion-label>\n                <select formControlName=\"projectStatus\" style=\"width: 100%;\n                      background: #161b22; color: #fff; padding: 7px;border: 0.5px solid rgb(83, 83, 83)\">\n                  <option value=\"Upcoming\">Upcoming</option>\n                  <option value=\"Ongoing\">Ongoing</option>\n                  <option value=\"Completed\">Completed</option>\n                  <option value=\"Suspended\">Suspended</option>\n                </select>\n              </ion-item>\n            </ion-col>\n            <ion-col size=\"4\">\n              <ion-item>\n                <ion-label position=\"stacked\" style=\"color: #fff;\">Project Stage</ion-label>\n                <select formControlName=\"projectStage\" style=\"width: 100%;\n                      background: #161b22; color: #fff; padding: 7px;border: 0.5px solid rgb(83, 83, 83)\">\n                  <option value=\"Initiate\">Initiate</option>\n                  <option value=\"Plan\">Plan</option>\n                  <option value=\"Execute\">Execute</option>\n                  <option value=\"Deliver\">Deliver</option>\n                  <option value=\"Close\">Close</option>\n                </select>\n              </ion-item>\n            </ion-col>\n            <ion-col size=\"4\">\n              <ion-item>\n                <ion-label position=\"stacked\" style=\"color: #fff;\">Project Type</ion-label>\n                <select formControlName=\"projectType\" style=\"width: 100%;\n                      background: #161b22; color: #fff; padding: 7px;border: 0.5px solid rgb(83, 83, 83)\">\n                  <option value=\"Billable\">Billable</option>\n                  <option value=\"Non-Billable\">Non-Billable</option>\n                </select>\n              </ion-item>\n            </ion-col>\n            <ion-col size=\"12\">\n              <ion-item>\n                <ion-label position=\"stacked\" style=\"color: #fff;\">Project Description*</ion-label>\n                <quill-editor [styles]=\"{height: '250px'}\" formControlName=\"projectDescription\" placeholder=\"Enter Text\"\n                  [modules]=\"quillConfig\" (onSelectionChanged)=\"onSelectionChanged($event)\"\n                  (onContentChanged)=\"onContentChanged($event)\"\n                  style=\"background-color: #161b22; min-height: 100px;border-radius: 10px;border: 0.5px solid rgb(83, 83, 83);width: 100%;\">\n                </quill-editor>\n              </ion-item>\n            </ion-col>\n          </ion-row>\n          <ion-row style=\"padding-bottom: 10px;\">\n          </ion-row>\n        </ion-list>\n      </form>\n    </ion-col>\n  </ion-row>\n\n  <ion-row>\n    <ion-col sizeLg=\"10\" offsetLg=\"1\" *ngIf=\"segment=='members'\">\n        <ion-row style=\"z-index: 999999999;background-color: transparent;color: #fff;margin: 0px;\">\n          <ion-col size=\"12\" style=\"background: #0d1116;\">\n            <ion-item lines=\"none\">\n              <ion-label style=\"color: #ccc;\">\n                Members\n              </ion-label>\n            </ion-item>\n            <ion-toolbar color=\"gray\">\n              <ion-searchbar placeholder=\"Search Employee\" debounce=\"500\" (ionChange)=\"searchEmployee($event)\">\n              </ion-searchbar>\n            </ion-toolbar>\n          </ion-col>\n        </ion-row>\n        <ion-row *ngFor=\"let user of allUsers; index as i\" [ngClass]=\"(i % 2 == 0) ? 'odd' : 'even'\" style=\"background: #161b22;\n        border-radius: 10px;margin: 10px;\">\n          <ion-col size=\"3\" style=\"border-right: 1px solid rgb(63 68 73)\">\n            <ion-item lines=\"none\" style=\"width: 100%;\">\n              <ion-avatar slot=\"start\">\n                <img [src]=\"user.image\">\n              </ion-avatar>\n              <ion-label style=\"color: #fff;\">\n                {{user.firstName}} {{user.lastName}}\n              </ion-label>\n            </ion-item>\n          </ion-col>\n          <ion-col size=\"2\" style=\"border-right: 1px solid rgb(63 68 73)\">\n            <ion-item *ngIf=\"!checkInTeam(user)\" lines=\"none\" style=\"width: 100%;\">\n              <ion-checkbox style=\"color: #fff;\" [(ngModel)]=\"user.billable\" (ionChange)=\"selectBillable(user)\">\n              </ion-checkbox>\n              <ion-label style=\"color: #fff;\">Billable</ion-label>\n            </ion-item>\n          </ion-col>\n          <ion-col size=\"2\" style=\"border-right: 1px solid rgb(63 68 73)\">\n            <ion-item *ngIf=\"!checkInTeam(user)\" lines=\"none\" style=\"width: 100%;\">\n              <ion-input type=\"number\" placeholder=\"Hrs Assigned\" [(ngModel)]=\"user.hoursAssign\"\n                (ionChange)=\"selectHours(user)\" style=\"border: none;background: #161b22;\"></ion-input>\n            </ion-item>\n          </ion-col>\n          <ion-col size=\"4\" style=\"border-right: 1px solid rgb(63 68 73)\">\n            <ion-select *ngIf=\"!checkInTeam(user)\" style=\"color: #fff;\" interface=\"popover\" [(ngModel)]=\"user.type\"\n              placeholder=\"Select Role\" (ionChange)=\"selectRole(user)\">\n              <ion-select-option value=\"Frontend\">Frontend Developer</ion-select-option>\n              <ion-select-option value=\"Backend\">Backend Developer</ion-select-option>\n              <ion-select-option value=\"Functional\">Functional Consultant</ion-select-option>\n              <ion-select-option value=\"Tester\">Tester/QA</ion-select-option>\n              <ion-select-option value=\"Manager\">Project Manager</ion-select-option>\n            </ion-select>\n          </ion-col>\n          <ion-col size=\"1\">\n            <ion-item lines=\"none\" style=\"width: 100%;\">\n              <ion-button *ngIf=\"checkInTeam(user)\" slot=\"end\" fill=\"clear\" (click)=\"addEmployeeTeam(user)\">\n                <ion-icon color=\"success\" name=\"add\"></ion-icon>\n              </ion-button>\n              <ion-button *ngIf=\"!checkInTeam(user)\" slot=\"end\" fill=\"clear\" (click)=\"removeProjectMember(user)\">\n                <ion-icon color=\"danger\" name=\"close\"></ion-icon>\n              </ion-button>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n    </ion-col>\n  </ion-row>\n</ion-content>\n<ion-footer>\n  <ion-toolbar color=\"gray\">\n    <ion-buttons slot=\"end\">\n      <ion-button *ngIf=\"projectId == 'null'\" expand=\"block\" fill=\"solid\" color=\"success\"\n        style=\"font-weight: 300;width: 150px;\" (click)=\"saveProject()\">\n        Next\n      </ion-button>\n      <ion-button *ngIf=\"projectId != 'null'\" expand=\"block\" fill=\"solid\" color=\"success\"\n        style=\"font-weight: 300;width: 150px;\" (click)=\"updateProject()\">\n        Save\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-footer>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_project-details_project-details_module_ts.js.map