"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_new-post_new-post_module_ts-src_app_services_project_service_ts"],{

/***/ 1142:
/*!***********************************************************!*\
  !*** ./src/app/pages/new-post/new-post-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewPostPageRoutingModule": () => (/* binding */ NewPostPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _new_post_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./new-post.page */ 8604);




const routes = [
    {
        path: '',
        component: _new_post_page__WEBPACK_IMPORTED_MODULE_0__.NewPostPage
    }
];
let NewPostPageRoutingModule = class NewPostPageRoutingModule {
};
NewPostPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], NewPostPageRoutingModule);



/***/ }),

/***/ 1222:
/*!***************************************************!*\
  !*** ./src/app/pages/new-post/new-post.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewPostPageModule": () => (/* binding */ NewPostPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _new_post_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./new-post-routing.module */ 1142);
/* harmony import */ var _new_post_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./new-post.page */ 8604);
/* harmony import */ var ngx_quill__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-quill */ 3115);








let NewPostPageModule = class NewPostPageModule {
};
NewPostPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            ngx_quill__WEBPACK_IMPORTED_MODULE_6__.QuillModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _new_post_routing_module__WEBPACK_IMPORTED_MODULE_0__.NewPostPageRoutingModule
        ],
        declarations: [_new_post_page__WEBPACK_IMPORTED_MODULE_1__.NewPostPage]
    })
], NewPostPageModule);



/***/ }),

/***/ 354:
/*!*********************************************!*\
  !*** ./src/app/services/project.service.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProjectService": () => (/* binding */ ProjectService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth.service */ 7556);




let ProjectService = class ProjectService {
    constructor(authService, http) {
        this.authService = authService;
        this.http = http;
    }
    createProject(projectObject) {
        projectObject.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'createProject', projectObject).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateProject(projectObject) {
        projectObject.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'updateProject', projectObject).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getOneProject(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getOneProject', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getProjectMembers(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getProjectMembers', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    addProjectMember(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'addProjectMember', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    removeProjectMember(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'removeProjectMember', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateProjectMember(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'updateProjectMember', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    fetchAllProjects(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'fetchAllProjects', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getMemberProjects() {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getMemberProjects', { employeeId: this.authService.userId }).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getTeamsReporting() {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getTeamsReporting', { userId: this.authService.userId }).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    createEpic(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'createEpic', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateProjectEpic(epicData) {
        let newEpic = Object.assign(epicData);
        newEpic['id'] = newEpic.id.replace('epic', '');
        console.log("updateProjectEpic epicData ", epicData);
        console.log("updateProjectEpic newEpic ", newEpic);
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'epicUpdate', newEpic).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getProjectEpics(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getProjectEpics', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    createStory(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'createStory', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateEpicStory(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'storyUpdate', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getEpicStories(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getStories', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    createStoryTask(taskData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'createStoryTask', taskData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getStoryTasks(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getStoryTasks', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getProjectColumns(projectData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getProjectColumns', projectData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateProjectTask(task) {
        return new Promise((resolve, reject) => {
            task.organisationId = this.authService.organisationId;
            this.http.post(this.authService.apiUrl + 'updateProjectTask', task).subscribe((resp) => {
                console.log("rsp", resp);
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
};
ProjectService.ctorParameters = () => [
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
ProjectService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], ProjectService);



/***/ })

}]);
//# sourceMappingURL=src_app_pages_new-post_new-post_module_ts-src_app_services_project_service_ts.js.map