"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_dsr_dsr_module_ts"],{

/***/ 5485:
/*!*************************************************!*\
  !*** ./src/app/pages/dsr/dsr-routing.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DsrPageRoutingModule": () => (/* binding */ DsrPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _dsr_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dsr.page */ 4803);




const routes = [
    {
        path: '',
        component: _dsr_page__WEBPACK_IMPORTED_MODULE_0__.DsrPage
    }
];
let DsrPageRoutingModule = class DsrPageRoutingModule {
};
DsrPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], DsrPageRoutingModule);



/***/ }),

/***/ 8870:
/*!*****************************************!*\
  !*** ./src/app/pages/dsr/dsr.module.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DsrPageModule": () => (/* binding */ DsrPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _dsr_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dsr-routing.module */ 5485);
/* harmony import */ var _dsr_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dsr.page */ 4803);







let DsrPageModule = class DsrPageModule {
};
DsrPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _dsr_routing_module__WEBPACK_IMPORTED_MODULE_0__.DsrPageRoutingModule
        ],
        declarations: [_dsr_page__WEBPACK_IMPORTED_MODULE_1__.DsrPage]
    })
], DsrPageModule);



/***/ }),

/***/ 4803:
/*!***************************************!*\
  !*** ./src/app/pages/dsr/dsr.page.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DsrPage": () => (/* binding */ DsrPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _dsr_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dsr.page.html?ngResource */ 1921);
/* harmony import */ var _dsr_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dsr.page.scss?ngResource */ 280);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/common.service */ 5620);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_tasks_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/tasks.service */ 2632);







let DsrPage = class DsrPage {
    constructor(tasksService, commonService, modalCtrl) {
        this.tasksService = tasksService;
        this.commonService = commonService;
        this.modalCtrl = modalCtrl;
        this.team = "1";
        this.status = "1";
        this.dsrEmployees = [];
        this.employees = [];
    }
    ngOnInit() {
        this.date = this.commonService.formatDate(new Date());
        this.commonService.getDSR({ employeeId: [9, 4, 31], from: "2022-08-1", to: "2022-08-20" }).then((dsrs) => {
            let dsrArray = [];
            dsrs.forEach(dsr => {
                dsrArray.push(dsr.details);
            });
            this.dsrEmployees = dsrArray;
            console.log("dsrArray ", dsrArray);
        });
    }
    parseFloat(number) {
        return parseFloat(number).toFixed(2);
    }
    acceptTask(task) {
        task.status = 1;
        this.tasksService.updateTask(task).then(resp => {
        });
    }
    rejectTask(task) {
        task.status = 2;
        this.tasksService.updateTask(task).then(resp => {
        });
    }
};
DsrPage.ctorParameters = () => [
    { type: _services_tasks_service__WEBPACK_IMPORTED_MODULE_3__.TasksService },
    { type: _services_common_service__WEBPACK_IMPORTED_MODULE_2__.CommonService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController }
];
DsrPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-dsr',
        template: _dsr_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_dsr_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], DsrPage);



/***/ }),

/***/ 2632:
/*!*******************************************!*\
  !*** ./src/app/services/tasks.service.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TasksService": () => (/* binding */ TasksService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth.service */ 7556);




let TasksService = class TasksService {
    constructor(authService, http) {
        this.authService = authService;
        this.http = http;
    }
    getUserTeams() {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getUserTeams', { userId: this.authService.userId }).subscribe((resp) => {
                console.log("rsp", resp);
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    fetchTeamColumns(teamId) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'fetchTeamColumns', { teamId }).subscribe((resp) => {
                console.log("rsp", resp);
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateTask(task) {
        return new Promise((resolve, reject) => {
            task.organisationId = this.authService.organisationId;
            this.http.post(this.authService.apiUrl + 'updateTask', task).subscribe((resp) => {
                console.log("rsp", resp);
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    createTask(task) {
        return new Promise((resolve, reject) => {
            task.organisationId = this.authService.organisationId;
            task.employeeId = this.authService.userId;
            this.http.post(this.authService.apiUrl + 'createTask', task).subscribe((resp) => {
                console.log("rsp", resp);
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getUserTasks(column) {
        return new Promise((resolve, reject) => {
            column.organisationId = this.authService.organisationId;
            column.employeeId = this.authService.userId;
            this.http.post(this.authService.apiUrl + 'getUserTasks', column).subscribe((resp) => {
                // console.log("rsp",resp)
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    deleteUserTasks(column) {
        return new Promise((resolve, reject) => {
            column.organisationId = this.authService.organisationId;
            column.employeeId = this.authService.userId;
            this.http.post(this.authService.apiUrl + 'deleteTask', column).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    filterDsr(params) {
        return new Promise((resolve, reject) => {
            params.organisationId = this.authService.organisationId;
            // if(!params.employeeIds)
            // params.employeeIds = [this.authService.userId];
            // params.employeeIds = [4,9,31];
            this.http.post(this.authService.apiUrl + 'filterDsr', params).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
};
TasksService.ctorParameters = () => [
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
TasksService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], TasksService);



/***/ }),

/***/ 280:
/*!****************************************************!*\
  !*** ./src/app/pages/dsr/dsr.page.scss?ngResource ***!
  \****************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkc3IucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 1921:
/*!****************************************************!*\
  !*** ./src/app/pages/dsr/dsr.page.html?ngResource ***!
  \****************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar color=\"gray\">\n    <ion-title>Daily Status Reports</ion-title>\n  </ion-toolbar>\n  <ion-toolbar color=\"gray\">\n    <ion-searchbar placeholder=\"Search Employee\"></ion-searchbar>\n  </ion-toolbar>\n  <ion-toolbar color=\"gray\">\n    <ion-row>\n      <ion-col size=\"2\" style=\"border: 1px solid rgb(37 38 40);\n      background-color: rgb(30 31 33);\n      padding: 0px;\">\n        <ion-item lines=\"none\">\n          <ion-select placeholder=\"Select team\" [(ngModel)]=\"status\" style=\"color: #fff;width: 100%;\" multiple>\n            <!-- <ion-select-option style=\"color: #fff;font-weight: bold;\" value=\"1\">All Teams</ion-select-option> -->\n            <ion-select-option style=\"color: #fff;font-weight: bold;\" value=\"1\">New</ion-select-option>\n            <ion-select-option style=\"color: #fff;font-weight: bold;\" value=\"2\">Accepted</ion-select-option>\n            <ion-select-option style=\"color: #fff;font-weight: bold;\" value=\"3\">Rejected</ion-select-option>\n          </ion-select>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"6\" style=\"border: 1px solid rgb(37 38 40);\n      background-color: rgb(30 31 33);\n      padding: 0px;\">\n        <ion-item lines=\"none\">\n          <ion-select placeholder=\"Select team\" [(ngModel)]=\"team\" style=\"color: #fff;width: 100%;\" multiple>\n            <!-- <ion-select-option style=\"color: #fff;font-weight: bold;\" value=\"1\">All Teams</ion-select-option> -->\n            <ion-select-option style=\"color: #fff;font-weight: bold;\" value=\"1\">Development Team</ion-select-option>\n            <ion-select-option style=\"color: #fff;font-weight: bold;\" value=\"2\">Marketing Team</ion-select-option>\n            <ion-select-option style=\"color: #fff;font-weight: bold;\" value=\"3\">Sales Team</ion-select-option>\n            <ion-select-option style=\"color: #fff;font-weight: bold;\" value=\"4\">Leadership Team</ion-select-option>\n          </ion-select>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"4\" style=\"border: 1px solid rgb(37 38 40);\n      background-color: rgb(30 31 33);\n      padding: 0px;\">\n        <ion-item lines=\"none\">\n          <ion-button (click)=\"openCalendar()\" expand=\"block\" fill=\"clear\" color=\"light\">\n            {{date}}\n          </ion-button>\n          <!-- <ion-input [(ngModel)]=\"date\" (change)=\"getDate($event)\" type=\"date\" style=\"color: #ccc;font-weight: bold;\">\n          </ion-input> -->\n        </ion-item>\n      </ion-col>\n    </ion-row>\n  </ion-toolbar>\n\n</ion-header>\n\n<ion-content>\n  <div style=\"padding: 20px;\">\n    <ion-accordion-group *ngFor=\"let employee of dsrEmployees\" style=\"margin-bottom: 5px;\">\n      <ion-accordion value=\"first\">\n        <ion-item slot=\"header\" lines=\"none\">\n          <ion-avatar slot=\"start\">\n            <img src=\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRFMEVXuFb_tRXt584wK0LUfXhUWC5XkZyvyHV5LZBi4xzkbd4RNT_gSxr_337y8fZUccw&usqp=CAU\">\n          </ion-avatar>\n          <!-- <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373;\" slot=\"start\" name=\"close-circle-outline\"></ion-icon> -->\n          <!-- <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon> -->\n          <ion-label style=\"font-size: 18px !important;\">{{employee.firstName}} {{employee.lastName}}</ion-label>\n        </ion-item>\n        <div class=\"ion-padding\" slot=\"content\" class=\"expandedDSR\">\n          <ion-item lines=\"none\" class=\"ion-text-wrap\" *ngFor=\"let task of employee.task;let i = index;\">\n            <ion-note slot=\"start\" style=\"font-weight: 300;font-size: 12px;\">\n              {{i+1}}\n            </ion-note>\n            <ion-icon (click)=\"rejectTask(task)\" style=\"margin-right: 10px;cursor: pointer;\"  \n            [color]=\"task.status == 2 ? \n            'danger' : 'light'\" slot=\"start\" name=\"close-circle-outline\"></ion-icon>\n            <ion-icon (click)=\"acceptTask(task)\" style=\"margin-right: 10px;cursor: pointer;\" \n            [color]=\"task.status == 1 ? \n            'success' : 'light'\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon>\n            <ion-label class=\"ion-text-wrap\">{{task.taskName}}</ion-label>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;text-align: right;\">\n              SpotYourDeal <br> {{parseFloat(task.hours)}} hrs\n            </ion-note>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;\">\n              {{task.from | date:'HH:mm a'}} - {{task.to | date:'HH:mm a'}} <br> {{task.date | date:'dd MMM, yyyy'}}\n            </ion-note>\n          </ion-item>\n          <!-- <ion-item lines=\"none\">\n            <ion-note slot=\"start\" style=\"font-weight: 300;font-size: 12px;\">\n              2\n            </ion-note>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;\" slot=\"start\" name=\"close-circle-outline\"></ion-icon>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon>\n            <ion-label>Chat message date not showing</ion-label>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;text-align: right;\">\n              iDMX <br> 2 hrs\n            </ion-note>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;\">\n              1:30 PM - 4:30 PM <br> 2 Aug, 2022\n            </ion-note>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-note slot=\"start\" style=\"font-weight: 300;font-size: 12px;\">\n              3\n            </ion-note>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373;\" slot=\"start\" name=\"close-circle-outline\"></ion-icon>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon>\n            <ion-label>Feeds page not scrolling back to top when segment change</ion-label>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;text-align: right;\">\n              Hr Portal <br> 2 hrs\n            </ion-note>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;\">\n              1:30 PM - 4:30 PM <br> 2 Aug, 2022\n            </ion-note>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-note slot=\"start\" style=\"font-weight: 300;font-size: 12px;\">\n              4\n            </ion-note>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373;\" slot=\"start\" name=\"close-circle-outline\"></ion-icon>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon>\n            <ion-label>User chat not opening on receiving chat notification</ion-label>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;text-align: right;\">\n              SpotYourDeal <br> 2 hrs\n            </ion-note>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;\">\n              1:30 PM - 4:30 PM <br> 2 Aug, 2022\n            </ion-note>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-note slot=\"start\" style=\"font-weight: 300;font-size: 12px;\">\n              5\n            </ion-note>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373;\" slot=\"start\" name=\"close-circle-outline\"></ion-icon>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon>\n            <ion-label>Remove possible duplicate users</ion-label>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;text-align: right;\">\n              SpotYourDeal <br> 2 hrs\n            </ion-note>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;\">\n              1:30 PM - 4:30 PM <br> 2 Aug, 2022\n            </ion-note>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-note slot=\"start\" style=\"font-weight: 300;font-size: 12px;\">\n              6\n            </ion-note>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373;\" slot=\"start\" name=\"close-circle-outline\"></ion-icon>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon>\n            <ion-label>Blocked users cannot send message from anywhere</ion-label>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;text-align: right;\">\n              SpotYourDeal <br> 2 hrs\n            </ion-note>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;\">\n              1:30 PM - 4:30 PM <br> 2 Aug, 2022\n            </ion-note>\n          </ion-item> -->\n        </div>\n      </ion-accordion>\n    </ion-accordion-group>\n  </div>\n\n</ion-content>\n<ion-footer>\n  <ion-toolbar color=\"tertiary\">\n    <ion-item lines=\"none\">\n      <!-- <ion-note slot=\"start\" style=\"font-weight: 300;font-size: 12px;\">\n        6\n      </ion-note>\n      <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373;\" slot=\"start\" name=\"close-circle-outline\"></ion-icon>\n      <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon> -->\n      <ion-label></ion-label>\n      <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;text-align: right;\">\n        SpotYourDeal <br> 2 hrs\n      </ion-note>\n      <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;\">\n        1:30 PM - 4:30 PM <br> 2 Aug, 2022\n      </ion-note>\n    </ion-item>\n  </ion-toolbar>\n</ion-footer>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_dsr_dsr_module_ts.js.map