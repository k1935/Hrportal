"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_profile_profile_module_ts"],{

/***/ 1474:
/*!*********************************************************!*\
  !*** ./src/app/pages/profile/profile-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfilePageRoutingModule": () => (/* binding */ ProfilePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _profile_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profile.page */ 4629);




const routes = [
    {
        path: '',
        component: _profile_page__WEBPACK_IMPORTED_MODULE_0__.ProfilePage
    }
];
let ProfilePageRoutingModule = class ProfilePageRoutingModule {
};
ProfilePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ProfilePageRoutingModule);



/***/ }),

/***/ 8558:
/*!*************************************************!*\
  !*** ./src/app/pages/profile/profile.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfilePageModule": () => (/* binding */ ProfilePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _profile_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profile-routing.module */ 1474);
/* harmony import */ var _profile_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profile.page */ 4629);







let ProfilePageModule = class ProfilePageModule {
};
ProfilePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _profile_routing_module__WEBPACK_IMPORTED_MODULE_0__.ProfilePageRoutingModule
        ],
        declarations: [_profile_page__WEBPACK_IMPORTED_MODULE_1__.ProfilePage]
    })
], ProfilePageModule);



/***/ }),

/***/ 4629:
/*!***********************************************!*\
  !*** ./src/app/pages/profile/profile.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfilePage": () => (/* binding */ ProfilePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _profile_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profile.page.html?ngResource */ 7364);
/* harmony import */ var _profile_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profile.page.scss?ngResource */ 2581);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/common.service */ 5620);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 124);









let ProfilePage = class ProfilePage {
    constructor(fb, commonService, navController, menuController, 
    // private loadingService: LoadingService,
    platform, authService, 
    // private userService: UserService,
    // private helperService: HelperService,
    // private authService: AuthService,
    router) {
        this.fb = fb;
        this.commonService = commonService;
        this.navController = navController;
        this.menuController = menuController;
        this.platform = platform;
        this.authService = authService;
        this.router = router;
    }
    ngOnInit() {
        this.form = this.fb.group({
            organisationName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            organisationGST: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            organisationPAN: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            organisationEmail: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            organisationBranch: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            organisationPhone: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            organisationAddress: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            NumberofEmployee: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
        });
        this.commonService.getOrganisation(localStorage.getItem('organisationId')).then((resp) => {
            let keys = Object.keys(resp);
            keys.forEach(key => {
                console.log("key ", key);
                if (key != 'organisationCode')
                    this.form.controls[key].setValue(resp[key]);
            });
        });
    }
    update() {
        if (this.form.valid) {
            let formData = Object.assign(this.form.value, { organisationCode: localStorage.getItem('organisationId') });
            console.log("formData", formData);
            this.commonService.updateOrganisation(formData).then((resp) => {
                console.log("resp", resp);
            });
        }
    }
};
ProfilePage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder },
    { type: _services_common_service__WEBPACK_IMPORTED_MODULE_3__.CommonService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.MenuController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.Platform },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router }
];
ProfilePage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-profile',
        template: _profile_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_profile_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ProfilePage);



/***/ }),

/***/ 2581:
/*!************************************************************!*\
  !*** ./src/app/pages/profile/profile.page.scss?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = "ion-menu-button {\n  color: var(--ion-color-primary);\n}\n\n#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n\nion-item {\n  --background: #2c2d2e;\n  box-shadow: 1px 1px 4px 0px rgba(0, 0, 0, 0.5);\n  color: #fff;\n  height: 40px;\n  margin-top: 5px;\n  border-radius: 10px;\n  border: 0.5px solid rgb(83, 83, 83);\n}\n\nion-row {\n  padding: 0px !important;\n}\n\n.base {\n  background: white;\n  margin: 0px auto;\n  display: flex;\n  flex-direction: row;\n  justify-content: center;\n  overflow: hidden;\n}\n\n.terms {\n  text-align: left;\n  font-size: 11px;\n  padding: 10px;\n}\n\n.register-button {\n  background: #2261a1;\n  color: white;\n  padding: 5px;\n  width: 100%;\n  text-align: center;\n  margin: 5px;\n  cursor: pointer;\n}\n\n.login-button {\n  color: #222;\n  padding: 5px;\n  width: 100%;\n  text-align: center;\n  margin: 5px;\n  cursor: pointer;\n}\n\n.signinButton {\n  background: #2980b9;\n  border-radius: 10px;\n  text-align: center;\n  line-height: 2.5rem;\n  width: 100%;\n  margin: 0 auto;\n  margin-top: 20px;\n  font-weight: bold;\n  color: #fff;\n  cursor: pointer;\n  border: 1px solid #fff;\n}\n\n.signupButton {\n  border-radius: 10px;\n  text-align: center;\n  line-height: 2.5rem;\n  width: 100%;\n  margin: 0 auto;\n  margin-top: 20px;\n  font-weight: bold;\n  color: #222;\n  cursor: pointer;\n  border: 1px solid #fff;\n}\n\n.forgotButton {\n  background: #fff;\n  text-align: right;\n  margin: 0 auto;\n  margin-top: 20px;\n  margin-bottom: 10px;\n  font-weight: bold;\n  color: #2980b9;\n  cursor: pointer;\n}\n\nion-item {\n  box-shadow: none !important;\n}\n\n@media screen and (max-width: 480px) {\n  .box {\n    border-radius: 20px;\n  }\n  .container {\n    margin: 15px !important;\n    height: calc(100% - 30px) !important;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2ZpbGUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksK0JBQUE7QUFDSjs7QUFFRTtFQUNFLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxPQUFBO0VBQ0EsUUFBQTtFQUNBLFFBQUE7RUFDQSwyQkFBQTtBQUNKOztBQUVFO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0FBQ0o7O0FBRUU7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsU0FBQTtBQUNKOztBQUVFO0VBQ0UscUJBQUE7QUFDSjs7QUFFQTtFQUVJLHFCQUFBO0VBQ0YsOENBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNBLG1DQUFBO0FBQUY7O0FBWUE7RUFDSSx1QkFBQTtBQVRKOztBQVlBO0VBQ0ksaUJBQUE7RUFJQSxnQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsZ0JBQUE7QUFaSjs7QUFnQkE7RUFDSSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxhQUFBO0FBYko7O0FBZ0JBO0VBQ0ksbUJBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0FBYko7O0FBZ0JBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtBQWJKOztBQWdCQTtFQUNJLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxzQkFBQTtBQWJKOztBQWdCQTtFQUVJLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0Esc0JBQUE7QUFkSjs7QUFpQkE7RUFDSSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0FBZEo7O0FBaUJBO0VBQ0ksMkJBQUE7QUFkSjs7QUFpQkE7RUFDSTtJQUNJLG1CQUFBO0VBZE47RUFnQkU7SUFDSSx1QkFBQTtJQUNBLG9DQUFBO0VBZE47QUFDRiIsImZpbGUiOiJwcm9maWxlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1tZW51LWJ1dHRvbiB7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgfVxuICBcbiAgI2NvbnRhaW5lciB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBsZWZ0OiAwO1xuICAgIHJpZ2h0OiAwO1xuICAgIHRvcDogNTAlO1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNTAlKTtcbiAgfVxuICBcbiAgI2NvbnRhaW5lciBzdHJvbmcge1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBsaW5lLWhlaWdodDogMjZweDtcbiAgfVxuICBcbiAgI2NvbnRhaW5lciBwIHtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgbGluZS1oZWlnaHQ6IDIycHg7XG4gICAgY29sb3I6ICM4YzhjOGM7XG4gICAgbWFyZ2luOiAwO1xuICB9XG4gIFxuICAjY29udGFpbmVyIGEge1xuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbiAgfVxuXG5pb24taXRlbSB7XG4gICAgLy8gYmFja2dyb3VuZDogI2ZiZmJmYjtcbiAgICAtLWJhY2tncm91bmQ6ICMyYzJkMmU7XG4gIGJveC1zaGFkb3c6IDFweCAxcHggNHB4IDBweCByZ2JhKDAsIDAsIDAsIDAuNSk7XG4gIGNvbG9yOiAjZmZmO1xuICBoZWlnaHQ6IDQwcHg7XG4gIG1hcmdpbi10b3A6IDVweDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgYm9yZGVyOiAwLjVweCBzb2xpZCByZ2IoODMsIDgzLCA4Mylcbn1cblxuXG5cblxuLy8gaW9uLWNhcmQge1xuLy8gICAtLWJhY2tncm91bmQ6ICNmZmY7XG4vLyAgIG1hcmdpbjogMTVweCAyMHB4O1xuXG4vLyB9XG5cbmlvbi1yb3cge1xuICAgIHBhZGRpbmc6IDBweCAhaW1wb3J0YW50O1xufVxuXG4uYmFzZSB7XG4gICAgYmFja2dyb3VuZDogd2hpdGU7XG4gICAgLy8gYm94LXNoYWRvdzogMCAwIDIwcHggMCByZ2JhKDAsIDAsIDAsIDAuMTUpO1xuICAgIC8vIHdpZHRoOiA4NzhweDtcbiAgICAvLyBoZWlnaHQ6IDU2MXB4O1xuICAgIG1hcmdpbjogMHB4IGF1dG87XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgLy8gYm9yZGVyLXJhZGl1czogNXB4O1xufVxuXG4udGVybXMge1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgZm9udC1zaXplOiAxMXB4O1xuICAgIHBhZGRpbmc6IDEwcHg7XG59XG5cbi5yZWdpc3Rlci1idXR0b24ge1xuICAgIGJhY2tncm91bmQ6ICMyMjYxYTE7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIHBhZGRpbmc6IDVweDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgbWFyZ2luOiA1cHg7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xufVxuXG4ubG9naW4tYnV0dG9uIHtcbiAgICBjb2xvcjogIzIyMjtcbiAgICBwYWRkaW5nOiA1cHg7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIG1hcmdpbjogNXB4O1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbn1cblxuLnNpZ25pbkJ1dHRvbiB7XG4gICAgYmFja2dyb3VuZDogIzI5ODBiOTtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBsaW5lLWhlaWdodDogMi41cmVtO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIG1hcmdpbjogMCBhdXRvO1xuICAgIG1hcmdpbi10b3A6IDIwcHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIGJvcmRlcjoxcHggc29saWQgI2ZmZjtcbn1cblxuLnNpZ251cEJ1dHRvbiB7XG4gICAgLy8gYmFja2dyb3VuZDogIzI5ODBiOTtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBsaW5lLWhlaWdodDogMi41cmVtO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIG1hcmdpbjogMCBhdXRvO1xuICAgIG1hcmdpbi10b3A6IDIwcHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgY29sb3I6ICMyMjI7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIGJvcmRlcjoxcHggc29saWQgI2ZmZjtcbn1cblxuLmZvcmdvdEJ1dHRvbiB7XG4gICAgYmFja2dyb3VuZDogI2ZmZjtcbiAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgICBtYXJnaW46IDAgYXV0bztcbiAgICBtYXJnaW4tdG9wOiAyMHB4O1xuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgY29sb3I6ICMyOTgwYjk7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xufVxuXG5pb24taXRlbSB7XG4gICAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xufVxuXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA0ODBweCkge1xuICAgIC5ib3gge1xuICAgICAgICBib3JkZXItcmFkaXVzOiAyMHB4O1xuICAgIH1cbiAgICAuY29udGFpbmVyIHtcbiAgICAgICAgbWFyZ2luOiAxNXB4ICFpbXBvcnRhbnQ7XG4gICAgICAgIGhlaWdodDogY2FsYygxMDAlIC0gMzBweCkgIWltcG9ydGFudDtcbiAgICB9XG4gIH0iXX0= */";

/***/ }),

/***/ 7364:
/*!************************************************************!*\
  !*** ./src/app/pages/profile/profile.page.html?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = "<ion-header class=\"ion-no-border\">\n  <ion-toolbar  color=\"gray\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Organisation Profile</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n\n  <div>\n    <ion-row style=\"height: 100%;\">\n      <ion-col style=\"height: calc(100% - 100px);border-radius: 20px;margin: 50px;\" sizeLg=\"8\" offsetLg=\"2\" sizeMd=\"8\" offsetMd=\"2\" sizeSm=\"12\" sizeXs=\"12\" class=\"box\">\n        <div>\n          <form [formGroup]=\"form\">\n            <ion-list style=\"background: transparent;padding:10px 20px;\">\n              <ion-row>\n                <ion-col size=\"4\" style=\"padding: 10px;\">\n                  <ion-label style=\"color: #fff;\">Company Name</ion-label>\n                  <ion-item lines=\"none\">\n                    <ion-input type=\"text\" required formControlName=\"organisationName\"></ion-input>\n                  </ion-item>\n                </ion-col>\n                <ion-col size=\"4\" style=\"padding: 10px;\">\n                  <ion-label style=\"color: #fff;\">GST No.</ion-label>\n                  <ion-item lines=\"none\">\n                    <ion-input type=\"text\" required formControlName=\"organisationGST\"></ion-input>\n                  </ion-item>\n                </ion-col>\n                <ion-col size=\"4\" style=\"padding: 10px;\">\n                  <ion-label style=\"color: #fff;\">PAN No.</ion-label>\n                  <ion-item lines=\"none\">\n                    <ion-input type=\"text\" required formControlName=\"organisationPAN\"></ion-input>\n                  </ion-item>\n                </ion-col>\n              </ion-row>\n              <ion-row>\n                <ion-col size=\"4\" style=\"padding: 10px;\">\n                  <ion-label style=\"color: #fff;\">Phone*</ion-label>\n                  <ion-item lines=\"none\">\n                    <ion-input type=\"text\" required formControlName=\"organisationPhone\"></ion-input>\n                  </ion-item>\n                </ion-col>\n                <ion-col size=\"4\" style=\"padding: 10px;\">\n                  <ion-label style=\"color: #fff;\">Email*</ion-label>\n                  <ion-item lines=\"none\">\n                    <ion-input [disabled]=\"true\" type=\"text\" required formControlName=\"organisationEmail\"></ion-input>\n                  </ion-item>\n                </ion-col>\n                <ion-col size=\"4\" style=\"padding: 10px;\">\n                  <ion-label style=\"color: #fff;\">Branch*</ion-label>\n                  <ion-item lines=\"none\">\n                    <ion-input type=\"text\" required formControlName=\"organisationBranch\"></ion-input>\n                  </ion-item>\n                </ion-col>\n              </ion-row>\n              <ion-row> \n                <ion-col size=\"8\" style=\"padding: 10px;\">\n                    <ion-label style=\"color: #fff;\">Address*</ion-label>\n                    <ion-item lines=\"none\">\n                      <ion-input type=\"text\" required formControlName=\"organisationAddress\"></ion-input>\n                    </ion-item>\n                </ion-col>\n                <ion-col size=\"4\" style=\"padding: 10px;\">\n                  <ion-label style=\"color: #fff;\">No. of Employee*</ion-label>\n                  <ion-item lines=\"none\">\n                    <ion-input type=\"number\" required formControlName=\"NumberofEmployee\"></ion-input>\n                  </ion-item>\n                </ion-col>\n                <!-- <ion-col size=\"4\" style=\"padding: 10px;\">\n                  <ion-label style=\"color: #222;\">Password</ion-label>\n                  <ion-item lines=\"none\" style=\"border: 1px solid #222;margin-bottom: 10px;margin-top: 5px;background: #fff;border-radius: 10px;\">\n                    <ion-input style=\"\" type=\"password\" required formControlName=\"NumberofEmployee\"></ion-input>\n                  </ion-item>\n                </ion-col>\n                <ion-col size=\"4\" style=\"padding: 10px;\">\n                  <ion-label style=\"color: #222;\">Confirm Password</ion-label>\n                  <ion-item lines=\"none\" style=\"border: 1px solid #222;margin-bottom: 10px;margin-top: 5px;background: #fff;border-radius: 10px;\">\n                    <ion-input style=\"\" type=\"password\" required formControlName=\"NumberofEmployee\"></ion-input>\n                  </ion-item>\n                </ion-col> -->\n              </ion-row>\n              <!-- <ion-label style=\"color: #222;\">Organization name</ion-label>\n              <ion-item lines=\"none\" style=\"border: 1px solid #ccc;margin-bottom: 10px;margin-top: 5px;background: #fff;border-radius: 10px;\">\n                <ion-input style=\"\" type=\"text\" required formControlName=\"email\"></ion-input>\n              </ion-item>\n              <ion-label style=\"color: #222;\">Email address</ion-label>\n              <ion-item lines=\"none\" style=\"border: 1px solid #ccc;margin-bottom: 10px;margin-top: 5px;background: #fff;border-radius: 10px;\">\n                <ion-input style=\"\" type=\"text\" required formControlName=\"email\"></ion-input>\n              </ion-item>\n              <ion-label style=\"color: #222;\">Password</ion-label>\n              <ion-item lines=\"none\" style=\"border: 1px solid #ccc;margin-top: 5px;background: #fff;border-radius: 10px;\">\n                <ion-input style=\"\" type=\"password\" required formControlName=\"pwd\"></ion-input>\n              </ion-item> -->\n             \n            </ion-list>\n          </form>\n        </div>\n        <div>\n          <div style=\"text-align: left;width: 100%;color: #fff;margin-left: 20px;\">\n            {{errorMessage}}\n          </div>\n        </div>\n        <!-- <div style=\"position: absolute;bottom:0;\">\n          <img src=\"assets/sap.png\" style=\"border-radius: 20px;\">\n        </div> -->\n      </ion-col>\n    </ion-row>\n  </div>\n</ion-content>\n<ion-footer class=\"ion-no-border\" color=\"gray\">\n  <ion-toolbar color=\"gray\">\n  <ion-buttons slot=\"end\">\n    <ion-button expand=\"block\" fill=\"solid\" color=\"success\" style=\"font-weight: 300;width: 170px;\" (click)=\"update()\">Update</ion-button>\n  </ion-buttons>\n  </ion-toolbar>\n</ion-footer>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_profile_profile_module_ts.js.map