(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["main"],{

/***/ 158:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 124);



const routes = [
    {
        path: 'login',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_auth_login_login_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./auth/login/login.module */ 8990)).then(m => m.LoginPageModule)
    },
    {
        path: 'register',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_auth_register_register_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./auth/register/register.module */ 6108)).then(m => m.RegisterPageModule)
    },
    {
        path: 'dashboard',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_pages_dsr-monthly-preview_dsr-monthly-preview_page_ts"), __webpack_require__.e("default-src_app_pages_feedback_feedback_page_ts"), __webpack_require__.e("default-src_app_pages_new-post_new-post_page_ts"), __webpack_require__.e("src_app_pages_dashboard_dashboard_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/dashboard/dashboard.module */ 1659)).then(m => m.DashboardPageModule)
    },
    {
        path: 'employee-list',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_employee-list_employee-list_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/employee-list/employee-list.module */ 1782)).then(m => m.EmployeeListPageModule)
    },
    {
        path: 'user-groups',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_user-groups_user-groups_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/user-groups/user-groups.module */ 8183)).then(m => m.UserGroupsPageModule)
    },
    {
        path: 'teams',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_teams_teams_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/teams/teams.module */ 8573)).then(m => m.TeamsPageModule)
    },
    {
        path: 'tasks',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_tasks_tasks_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/tasks/tasks.module */ 7694)).then(m => m.TasksPageModule)
    },
    {
        path: 'projects',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_projects_projects_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/projects/projects.module */ 3206)).then(m => m.ProjectsPageModule)
    },
    {
        path: 'dsr',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_dsr_dsr_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/dsr/dsr.module */ 8870)).then(m => m.DsrPageModule)
    },
    {
        path: 'project-details/:id',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_project-details_project-details_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/project-details/project-details.module */ 1906)).then(m => m.ProjectDetailsPageModule)
    },
    {
        path: 'settings',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_settings_settings_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/settings/settings.module */ 7850)).then(m => m.SettingsPageModule)
    },
    {
        path: 'profile',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_profile_profile_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/profile/profile.module */ 8558)).then(m => m.ProfilePageModule)
    },
    {
        path: 'attendance',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_attendance_attendance_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/attendance/attendance.module */ 8818)).then(m => m.AttendancePageModule)
    },
    {
        path: 'salary',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_salary_salary_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/salary/salary.module */ 5859)).then(m => m.SalaryPageModule)
    },
    {
        path: 'employee-onboarding/:id',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_employee-onboarding_employee-onboarding_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/employee-onboarding/employee-onboarding.module */ 5362)).then(m => m.EmployeeOnboardingPageModule)
    },
    {
        path: 'project-manage/:id',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_project-manage_project-manage_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/project-manage/project-manage.module */ 7405)).then(m => m.ProjectManagePageModule)
    },
    {
        path: 'leaves',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_leaves_leaves_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/leaves/leaves.module */ 9006)).then(m => m.LeavesPageModule)
    },
    {
        path: 'expenses',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_expenses_expenses_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/expenses/expenses.module */ 6931)).then(m => m.ExpensesPageModule)
    },
    {
        path: 'feedback',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_pages_feedback_feedback_page_ts"), __webpack_require__.e("src_app_pages_feedback_feedback_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/feedback/feedback.module */ 7792)).then(m => m.FeedbackPageModule)
    },
    {
        path: 'dsr-monthly-preview',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_pages_dsr-monthly-preview_dsr-monthly-preview_page_ts"), __webpack_require__.e("src_app_pages_dsr-monthly-preview_dsr-monthly-preview_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/dsr-monthly-preview/dsr-monthly-preview.module */ 201)).then(m => m.DsrMonthlyPreviewPageModule)
    },
    {
        path: 'view-all-dsr',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_pages_dsr-monthly-preview_dsr-monthly-preview_page_ts"), __webpack_require__.e("src_app_pages_view-all-dsr_view-all-dsr_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/view-all-dsr/view-all-dsr.module */ 8689)).then(m => m.ViewAllDsrPageModule)
    },
    {
        path: 'employee-profile',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_employee-profile_employee-profile_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/employee-profile/employee-profile.module */ 3563)).then(m => m.EmployeeProfilePageModule)
    },
    {
        path: 'project-task-details',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_modals_project-task-details_project-task-details_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./modals/project-task-details/project-task-details.module */ 9838)).then(m => m.ProjectTaskDetailsPageModule)
    },
    {
        path: 'project-epic-details',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_modals_project-epic-details_project-epic-details_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./modals/project-epic-details/project-epic-details.module */ 7993)).then(m => m.ProjectEpicDetailsPageModule)
    },
    {
        path: 'project-story-details',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_modals_project-story-details_project-story-details_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./modals/project-story-details/project-story-details.module */ 5922)).then(m => m.ProjectStoryDetailsPageModule)
    },
    {
        path: 'new-post',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_pages_new-post_new-post_page_ts"), __webpack_require__.e("src_app_pages_new-post_new-post_module_ts-src_app_services_project_service_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/new-post/new-post.module */ 1222)).then(m => m.NewPostPageModule)
    }
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.NgModule)({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule.forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__.PreloadAllModules })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule]
    })
], AppRoutingModule);



/***/ }),

/***/ 5041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var _Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component.html?ngResource */ 3383);
/* harmony import */ var _app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app.component.scss?ngResource */ 9259);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./services/common.service */ 5620);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./services/auth.service */ 7556);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _pages_employee_profile_employee_profile_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages/employee-profile/employee-profile.page */ 9667);










let AppComponent = class AppComponent {
  constructor(commonService, modalController, router, authService) {
    this.commonService = commonService;
    this.modalController = modalController;
    this.router = router;
    this.authService = authService;
    this.user = {};
    this.modules = [];
    this.appPages = [{
      title: 'Dashboard',
      url: 'dashboard',
      icon: 'bar-chart',
      permission: 'Dashboard'
    }, {
      title: 'Employee List',
      url: 'employee-list',
      icon: 'people',
      permission: 'EmployeeList'
    }, {
      title: 'Attendance',
      url: 'attendance',
      icon: 'document',
      permission: 'Attendance'
    }, // { title: 'Salary', url: 'salary', icon: 'cash' },
    {
      title: 'My Tasks',
      url: 'tasks',
      icon: 'list',
      permission: 'Tasks'
    }, {
      title: "View All DSRs",
      url: 'view-all-dsr',
      icon: 'eye',
      permission: 'ViewAllDSR'
    }, {
      title: "Projects",
      url: 'projects',
      icon: 'grid',
      permission: 'Projects'
    }, // { title: "Minutes of Meeting", url: 'mom', icon: 'recording' },
    {
      title: 'Teams',
      url: 'teams',
      icon: 'people-circle',
      permission: 'Teams'
    }, {
      title: 'Leaves',
      url: 'leaves',
      icon: 'calendar',
      permission: 'Leaves'
    }, {
      title: 'Expenses',
      url: 'expenses',
      icon: 'cash',
      permission: 'Expenses'
    }, {
      title: 'User Groups',
      url: 'user-groups',
      icon: 'albums',
      permission: 'UserGroups'
    } // { title: 'Profile', url: 'profile', icon: 'person' },
    // { title: 'Settings', url: 'settings', icon: 'settings' },
    ];
    let userId = JSON.parse(localStorage.getItem('userId'));

    if (userId) {
      //console.log("userId ", userId);
      this.setupPermissions(userId);
      this.router.events.subscribe(event => {
        if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_6__.NavigationEnd) {
          //console.log(event.url);
          if (event.url == '/') {
            this.router.navigate(['/dashboard']);
          }
        }
      });
    } else {
      this.router.navigate(['/login']);
    }

    this.authService.userLogin.subscribe(resp => {
      //console.log("authService userLogin", resp);
      if (resp && resp.userId) {
        this.setupPermissions(resp.userId);
      }
    });
  }

  setupPermissions(userId) {
    this.authService.getUserDetails(userId).then(data => {
      if (data) {
        this.user = data;
        this.modules = [];
        let permissions = data['modules'];

        if (permissions) {
          this.appPages.forEach(module => {
            if (permissions[module.permission]) this.modules.push(module);
          });
        } else {
          this.modules = this.appPages;
        }

        console.log("router.url ", this.router.url);
        if (this.router.url == '/login') this.router.navigate(['/dashboard']);
      }
    });
  }

  openProfile() {
    var _this = this;

    return (0,_Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const popover = yield _this.modalController.create({
        component: _pages_employee_profile_employee_profile_page__WEBPACK_IMPORTED_MODULE_5__.EmployeeProfilePage,
        cssClass: 'profile-modal',
        // componentProps: {test: "123"},
        showBackdrop: true
      });
      yield popover.present();
    })();
  }

  logout() {
    localStorage.clear();
    this.router.navigate(['/login']);
  }

};

AppComponent.ctorParameters = () => [{
  type: _services_common_service__WEBPACK_IMPORTED_MODULE_3__.CommonService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router
}, {
  type: _services_auth_service__WEBPACK_IMPORTED_MODULE_4__.AuthService
}];

AppComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-root',
  template: _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], AppComponent);


/***/ }),

/***/ 6747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser */ 4497);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/cdk/drag-drop */ 7727);
/* harmony import */ var _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/cdk/overlay */ 5895);
/* harmony import */ var _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/cdk/scrolling */ 6328);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var ngx_image_cropper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ngx-image-cropper */ 649);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component */ 5041);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app-routing.module */ 158);
/* harmony import */ var ngx_quill__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-quill */ 3115);
/* harmony import */ var quill__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! quill */ 3786);
/* harmony import */ var quill__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(quill__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var quill_emoji__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! quill-emoji */ 7669);
/* harmony import */ var quill_emoji__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(quill_emoji__WEBPACK_IMPORTED_MODULE_3__);
















quill__WEBPACK_IMPORTED_MODULE_2___default().register('modules/emoji-shortname', (quill_emoji__WEBPACK_IMPORTED_MODULE_3___default().ShortNameEmoji));
let AppModule = class AppModule {
};
AppModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__.BrowserModule,
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClientModule,
            ngx_image_cropper__WEBPACK_IMPORTED_MODULE_8__.ImageCropperModule,
            _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_9__.DragDropModule,
            ngx_quill__WEBPACK_IMPORTED_MODULE_10__.QuillModule.forRoot(),
            _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_11__.OverlayModule,
            _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_12__.ScrollingModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_13__.IonicModule.forRoot({ mode: 'ios' }),
            _app_routing_module__WEBPACK_IMPORTED_MODULE_1__.AppRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_14__.ReactiveFormsModule
        ],
        providers: [{ provide: _angular_router__WEBPACK_IMPORTED_MODULE_15__.RouteReuseStrategy, useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_13__.IonicRouteStrategy }],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent],
    })
], AppModule);



/***/ }),

/***/ 9667:
/*!*****************************************************************!*\
  !*** ./src/app/pages/employee-profile/employee-profile.page.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmployeeProfilePage": () => (/* binding */ EmployeeProfilePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _employee_profile_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./employee-profile.page.html?ngResource */ 398);
/* harmony import */ var _employee_profile_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./employee-profile.page.scss?ngResource */ 4115);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/common.service */ 5620);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/auth.service */ 7556);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);










let EmployeeProfilePage = class EmployeeProfilePage {
    constructor(commonService, activated, authService, modalController, router, formBuilder) {
        this.commonService = commonService;
        this.activated = activated;
        this.authService = authService;
        this.modalController = modalController;
        this.router = router;
        this.formBuilder = formBuilder;
        this.imageChangedEvent = '';
        this.croppedImage = '';
        this.segment = 'user';
        this.userGroups = [];
        this.updateFlag = false;
        this.employeeDetails = {};
        this.basic = this.formBuilder.group({
            firstName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            middleName: [''],
            lastName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            designation: [''],
            gender: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            phoneNo: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")
                ])],
            personalEmail: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
                ])],
            spouseName: [''],
            fatherName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            // DOB: ['',Validators.required],
            emergencyContactNumber: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            // emergencyContactName: ['',Validators.required],
            presentAddress: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            permanentAddress: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            // panNumber: ['',Validators.required],
            // adharNumber: ['',Validators.required]
        });
    }
    ngOnInit() {
        this.segment = 'user';
        this.id = this.authService.userId;
        console.log("id", this.id);
        if (this.id != "null") {
            this.fetchEmployee();
            this.updateFlag = true;
        }
        this.commonService.fetchAllUserGroups().then(resp => {
            this.userGroups = resp;
        });
    }
    ///update employee details
    updateEmployee() {
        console.log(this.basic.value);
        if (this.basic.valid) {
            this.commonService.presentLoading();
            let formData = Object.assign(this.basic.value, { employeeId: this.employeeId });
            if (this.croppedImage)
                formData.image = this.croppedImage;
            this.commonService.updateEmployee(formData).then((resp) => {
                this.commonService.loadingDismiss();
                this.modalController.dismiss();
                this.commonService.showToast("success", "Profile Updated!");
            });
        }
    }
    ///fetch employee details based on id
    fetchEmployee() {
        let formData = {
            employeeId: this.id
        };
        this.commonService.presentLoading();
        this.commonService.getOneEmployee(formData).then((resp) => {
            let user = resp[0];
            this.employeeDetails = user;
            console.log("user ", user);
            this.basic.patchValue(user);
            this.commonService.loadingDismiss();
            this.employeeId = user.employeeId;
        });
    }
    fileChangeEvent(event) {
        this.imageChangedEvent = event;
    }
    imageCropped(event) {
        this.croppedImage = event.base64;
    }
    imageLoaded(image) {
        // show cropper
    }
    cropperReady() {
        // cropper ready
    }
    loadImageFailed() {
        // show message
    }
};
EmployeeProfilePage.ctorParameters = () => [
    { type: _services_common_service__WEBPACK_IMPORTED_MODULE_2__.CommonService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder }
];
EmployeeProfilePage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-employee-profile',
        template: _employee_profile_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_employee_profile_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], EmployeeProfilePage);



/***/ }),

/***/ 7556:
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthService": () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 6317);




let AuthService = class AuthService {
    // oragsanisationId
    constructor(http) {
        this.http = http;
        this.domainAndScreenPermissions = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject({});
        this.userDetails = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject({});
        this.userLogin = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject({});
        this.orgOnboarded = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject({});
        this.updatePermissions = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject(false);
        this.userGroup = {};
        // apiUrl: any = 'http://localhost:3000/';
        this.apiUrl = 'https://api.hr.timesofpeople.com/';
    }
    getUserDetails(userId) {
        return new Promise((resolve, reject) => {
            this.http.post(this.apiUrl + 'getUserDetails', { userId: userId }).subscribe((resp) => {
                console.log("getUserDetails ", resp);
                if (resp && resp.organisationEmail) {
                    this.userType = 'organisation';
                    this.organisationId = resp.organisationId;
                    this.userId = resp.organisationId;
                    this.userLogin.next(resp);
                }
                if (resp && resp.employeeId) {
                    this.userType = 'employee';
                    this.organisationId = resp.organisationId;
                    this.userId = resp.employeeId;
                    this.userLogin.next(resp);
                }
                console.log("this.organisationId ", this.organisationId);
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    organisationRegister(organisationData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.apiUrl + 'organisationRegister', organisationData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    organisationUpdate(organisationData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.apiUrl + 'organisationUpdate', organisationData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getRandomQuote() {
        return new Promise((resolve, reject) => {
            this.http.get('https://api.quotable.io/random').subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    login(data) {
        return new Promise((resolve, reject) => {
            this.http.post(this.apiUrl + 'login', data).subscribe(resp => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getNewsFeed() {
        return new Promise((resolve, reject) => {
            this.http.post(this.apiUrl + 'getNewsFeed', {}).subscribe(resp => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
};
AuthService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
AuthService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], AuthService);



/***/ }),

/***/ 5620:
/*!********************************************!*\
  !*** ./src/app/services/common.service.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommonService": () => (/* binding */ CommonService)
/* harmony export */ });
/* harmony import */ var _Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./auth.service */ 7556);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var toastr2__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! toastr2 */ 349);








let CommonService = class CommonService {
  constructor(http, loadingController, authService, alertController, actionSheetController, modalCtrl, router) {
    this.http = http;
    this.loadingController = loadingController;
    this.authService = authService;
    this.alertController = alertController;
    this.actionSheetController = actionSheetController;
    this.modalCtrl = modalCtrl;
    this.router = router; // apiUrl: any = 'https://03b3-103-49-235-139.in.ngrok.io/';
    // apiUrl: any = 'http://localhost:3000/';

    this.apiUrl = 'http://159.223.177.89:3000/';
    this.apiUrl = this.authService.apiUrl;
  }

  showToast(action, message) {
    var toastr = new toastr2__WEBPACK_IMPORTED_MODULE_2__["default"](); // toastr.options.closeMethod = 'fadeOut';

    toastr.options.closeDuration = 1000;
    toastr.options.progressBar = true;
    toastr.options.positionClass = "toast-bottom-right"; // toastr.options.closeEasing = 'swing';
    // if(action == 'success')

    toastr[action](message, action + "!", {
      timeOut: 3000
    });
  }

  presentLoading() {
    var _this = this;

    return (0,_Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.loading = yield _this.loadingController.create({
        spinner: "circles",
        duration: 3000,
        message: 'Please wait...',
        translucent: true,
        cssClass: 'custom-class custom-loading'
      });
      return yield _this.loading.present();
    })();
  }

  loadingDismiss() {
    this.loading.dismiss();
  }

  registerEmployee(formData) {
    return new Promise((resolve, reject) => {
      formData.organisationId = this.authService.organisationId;
      this.http.post(this.apiUrl + 'employeeOnboarding', formData).subscribe(resp => {
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  }

  getUniqueAfterMerge(arr1, arr2) {
    // merge two arrays
    let arr = arr1.concat(arr2);
    let uniqueArr = []; // loop through array

    for (let i of arr) {
      if (uniqueArr.indexOf(i) === -1) {
        uniqueArr.push(i);
      }
    }

    console.log(uniqueArr);
  } ////Create organisation api


  createOrg(formData) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + 'createOrganisation', formData).subscribe(resp => {
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  }

  login(formData) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + 'login', formData).subscribe(resp => {
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  }

  getOrganisation(organisationId) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + 'getOrganisation', {
        organisationId
      }).subscribe(resp => {
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  }

  updateOrganisation(organisationData) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + 'updateOrganisationDetails', organisationData).subscribe(resp => {
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  }

  updateEmployee(formData) {
    return new Promise((resolve, reject) => {
      formData.organisationId = this.authService.organisationId;
      this.http.post(this.apiUrl + 'updateEmployeeDetails', formData).subscribe(resp => {
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  }

  getEmployeeList() {
    return new Promise((resolve, reject) => {
      let organisationId = this.authService.organisationId;
      this.http.post(this.apiUrl + 'getAllEmployee', {
        organisationId
      }).subscribe(resp => {
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  }

  getEmployeeAttendence(formData) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + 'viewEmployeesAttendance', formData).subscribe(resp => {
        console.log("rsp", resp);
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  }

  getOneEmployee(formData) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + 'getoneEmployee', formData).subscribe(resp => {
        console.log("rsp", resp);
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  }

  getMonthlySalary(formData) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + 'getMonthlySalary', formData).subscribe(resp => {
        console.log("rsp", resp);
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  }

  generateSalaries(formData) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + 'generateSalaries', formData).subscribe(resp => {
        console.log("rsp", resp);
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  }

  createTeam(formData) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + 'createTeam', formData).subscribe(resp => {
        console.log("rsp", resp);
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  }

  fetchAllTeams() {
    return new Promise((resolve, reject) => {
      // paramsData.organisationId = this.authService.organisationId;
      this.http.post(this.apiUrl + 'fetchTeams', {
        organisationId: this.authService.organisationId
      }).subscribe(resp => {
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  }

  fetchAllUserGroups() {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + 'fetchAllUserGroups', {
        organisationId: this.authService.organisationId
      }).subscribe(resp => {
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  }

  fetchTeamColumns(teamId) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + 'fetchTeamColumns', {
        teamId
      }).subscribe(resp => {
        console.log("rsp", resp);
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  }

  updateTeam(paramsData) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + 'updateTeam', paramsData).subscribe(resp => {
        console.log("rsp", resp);
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  }

  deleteTeam(team) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + 'deleteTeam', team).subscribe(resp => {
        console.log("rsp", resp);
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  }

  updateUserGroup(paramsData) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + 'updateUserGroup', paramsData).subscribe(resp => {
        console.log("rsp", resp);
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  }

  deleteUserGroup(group) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + 'deleteUserGroup', group).subscribe(resp => {
        console.log("rsp", resp);
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  }

  searchEmployees(searchTerm) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + 'searchEmployees', {
        searchTerm
      }).subscribe(resp => {
        console.log("rsp", resp);
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  }

  getEmployeesByIds(employeeIds) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + 'getEmployeesByIds', {
        employeeIds
      }).subscribe(resp => {
        console.log("rsp", resp);
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  }

  createTeamColumn(paramsData) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + 'createTeamColumn', paramsData).subscribe(resp => {
        console.log("rsp", resp);
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  }

  deleteTeamColumn(columnId) {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + 'deleteTeamColumn', {
        columnId
      }).subscribe(resp => {
        console.log("rsp", resp);
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  }

  getUserTeams() {
    return new Promise((resolve, reject) => {
      this.http.post(this.apiUrl + 'getUserTeams', {}).subscribe(resp => {
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  }

  createUserGroup(paramsData) {
    return new Promise((resolve, reject) => {
      paramsData.organisationId = this.authService.organisationId;
      this.http.post(this.apiUrl + 'createUserGroup', paramsData).subscribe(resp => {
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  }

  getDSR(paramsData) {
    return new Promise((resolve, reject) => {
      // paramsData.organisationId = this.authService.organisationId;
      this.http.post(this.apiUrl + 'filterdataTask', paramsData).subscribe(resp => {
        resolve(resp);
      }, error => {
        reject(error);
      });
    });
  } ///for mass upload


  massUpload(payload, data) {
    return this.http.post(this.apiUrl + 'dailyAttendance', data);
  }

  formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();
    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;
    return [year, month, day].join('-');
  }

};

CommonService.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.LoadingController
}, {
  type: _auth_service__WEBPACK_IMPORTED_MODULE_1__.AuthService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.AlertController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ActionSheetController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router
}];

CommonService = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Injectable)({
  providedIn: 'root'
})], CommonService);


/***/ }),

/***/ 2340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment)
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ 4431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ 6057);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 6747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 2340);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
(0,_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.log(err));


/***/ }),

/***/ 863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-accordion_2.entry.js": [
		79,
		"common",
		"node_modules_ionic_core_dist_esm_ion-accordion_2_entry_js"
	],
	"./ion-action-sheet.entry.js": [
		5593,
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		3225,
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		4812,
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		6655,
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		4856,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		3059,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-breadcrumb_2.entry.js": [
		8648,
		"common",
		"node_modules_ionic_core_dist_esm_ion-breadcrumb_2_entry_js"
	],
	"./ion-button_2.entry.js": [
		8308,
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		4690,
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		4090,
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		6214,
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		9447,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime-button.entry.js": [
		7950,
		"default-node_modules_ionic_core_dist_esm_parse-17d9d367_js-node_modules_ionic_core_dist_esm_t-a480aa",
		"node_modules_ionic_core_dist_esm_ion-datetime-button_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		9689,
		"default-node_modules_ionic_core_dist_esm_parse-17d9d367_js-node_modules_ionic_core_dist_esm_t-a480aa",
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		8840,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		749,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		8911,
		"common",
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		3288,
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		5473,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		3634,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		2855,
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		495,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		8737,
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		9632,
		"common",
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-picker-column-internal.entry.js": [
		4446,
		"common",
		"node_modules_ionic_core_dist_esm_ion-picker-column-internal_entry_js"
	],
	"./ion-picker-internal.entry.js": [
		2275,
		"node_modules_ionic_core_dist_esm_ion-picker-internal_entry_js"
	],
	"./ion-popover.entry.js": [
		8050,
		"common",
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		8994,
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		3592,
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		5454,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		290,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		2666,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		4816,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		5534,
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		4902,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		1938,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		8179,
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-slide_2.entry.js": [
		668,
		"node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"
	],
	"./ion-spinner.entry.js": [
		1624,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		9989,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		8902,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		199,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		8395,
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		6357,
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		8268,
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		5269,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	],
	"./ion-virtual-scroll.entry.js": [
		2875,
		"node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 863;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 9259:
/*!***********************************************!*\
  !*** ./src/app/app.component.scss?ngResource ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = "ion-menu {\n  border: none;\n  --background: #161b22;\n  overflow: hidden;\n}\n\nion-split-pane {\n  background: #1e1f21;\n}\n\nion-menu ion-content {\n  --background: #161b22;\n}\n\nion-menu ion-content {\n  --padding-bottom: 20px;\n}\n\nion-menu ion-list {\n  padding: 20px 0 0 0;\n}\n\nion-menu ion-note {\n  line-height: 24px;\n  margin-bottom: 20px;\n}\n\nion-menu ion-item {\n  --padding-start: 16px;\n  --padding-end: 16px;\n  --min-height: 50px;\n}\n\nion-menu ion-item.selected ion-icon {\n  color: #222;\n}\n\nion-menu ion-item ion-icon {\n  font-size: 24px;\n  color: #ccc;\n}\n\nion-menu ion-list#labels-list ion-list-header {\n  margin-bottom: 8px;\n}\n\nion-menu ion-list-header,\nion-menu ion-note {\n  padding-left: 16px;\n  padding-right: 16px;\n}\n\nion-menu ion-note {\n  margin-bottom: 8px;\n}\n\nion-note {\n  display: inline-block;\n  font-size: 16px;\n  color: #000;\n}\n\nion-item {\n  --color: #ccc;\n  --background: transparent;\n}\n\nion-item.selected {\n  --color: #222;\n  font-weight: bold;\n  --background: #ffc048;\n}\n\n.rightSidebar ion-menu {\n  --side-width: 40px;\n}\n\n.rightSidebar ion-list {\n  --background: #000;\n  background: #000;\n}\n\nion-split-pane {\n  --side-width: 200px;\n}\n\nion-header {\n  --background: #051e34;\n  background: #051e34;\n}\n\nion-content {\n  --ion-background-color: #161b22;\n}\n\nion-list {\n  background: #161b22;\n}\n\nion-toolbar {\n  --background: #161b22;\n  background-color: #161b22;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVNLFlBQUE7RUFDSixxQkFBQTtFQUVBLGdCQUFBO0FBREY7O0FBSUE7RUFFTSxtQkFBQTtBQUZOOztBQUtBO0VBQ0UscUJBQUE7QUFGRjs7QUFLQTtFQUNFLHNCQUFBO0FBRkY7O0FBS0E7RUFDRSxtQkFBQTtBQUZGOztBQUtBO0VBQ0UsaUJBQUE7RUFDQSxtQkFBQTtBQUZGOztBQUtBO0VBQ0UscUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FBRkY7O0FBS0E7RUFDRSxXQUFBO0FBRkY7O0FBS0E7RUFDRSxlQUFBO0VBQ0EsV0FBQTtBQUZGOztBQUtBO0VBQ0Usa0JBQUE7QUFGRjs7QUFLQTs7RUFFRSxrQkFBQTtFQUNBLG1CQUFBO0FBRkY7O0FBS0E7RUFDRSxrQkFBQTtBQUZGOztBQUtBO0VBQ0UscUJBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtBQUZGOztBQU1BO0VBQ0UsYUFBQTtFQUNBLHlCQUFBO0FBSEY7O0FBUUE7RUFDRSxhQUFBO0VBQ0EsaUJBQUE7RUFFQSxxQkFBQTtBQU5GOztBQVNBO0VBQ0Usa0JBQUE7QUFORjs7QUFTQTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7QUFORjs7QUFTQTtFQUNFLG1CQUFBO0FBTkY7O0FBU0E7RUFDRSxxQkFBQTtFQUNBLG1CQUFBO0FBTkY7O0FBY0E7RUFDRSwrQkFBQTtBQVhGOztBQWNBO0VBQ0UsbUJBQUE7QUFYRjs7QUFjQTtFQUNFLHFCQUFBO0VBQ0EseUJBQUE7QUFYRiIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tbWVudSB7XG4gIC8vIG1hcmdpbjogMTBweCAhaW1wb3J0YW50O1xuICAgICAgYm9yZGVyOiBub25lO1xuICAtLWJhY2tncm91bmQ6ICMxNjFiMjI7XG4gIC8vIGJvcmRlci1yYWRpdXM6IDIwcHg7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbmlvbi1zcGxpdC1wYW5lIHtcbiAgICAgIC8vIGJhY2tncm91bmQ6ICNiZGMzYzc7XG4gICAgICBiYWNrZ3JvdW5kOiAjMWUxZjIxO1xufVxuXG5pb24tbWVudSBpb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogIzE2MWIyMjtcbn1cblxuaW9uLW1lbnUgaW9uLWNvbnRlbnQge1xuICAtLXBhZGRpbmctYm90dG9tOiAyMHB4O1xufVxuXG5pb24tbWVudSBpb24tbGlzdCB7XG4gIHBhZGRpbmc6IDIwcHggMCAwIDA7XG59XG5cbmlvbi1tZW51IGlvbi1ub3RlIHtcbiAgbGluZS1oZWlnaHQ6IDI0cHg7XG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XG59XG5cbmlvbi1tZW51IGlvbi1pdGVtIHtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxNnB4O1xuICAtLXBhZGRpbmctZW5kOiAxNnB4O1xuICAtLW1pbi1oZWlnaHQ6IDUwcHg7XG59XG5cbmlvbi1tZW51IGlvbi1pdGVtLnNlbGVjdGVkIGlvbi1pY29uIHtcbiAgY29sb3I6ICMyMjJcbn1cblxuaW9uLW1lbnUgaW9uLWl0ZW0gaW9uLWljb24ge1xuICBmb250LXNpemU6IDI0cHg7XG4gIGNvbG9yOiAjY2NjO1xufVxuXG5pb24tbWVudSBpb24tbGlzdCNsYWJlbHMtbGlzdCBpb24tbGlzdC1oZWFkZXIge1xuICBtYXJnaW4tYm90dG9tOiA4cHg7XG59XG5cbmlvbi1tZW51IGlvbi1saXN0LWhlYWRlcixcbmlvbi1tZW51IGlvbi1ub3RlIHtcbiAgcGFkZGluZy1sZWZ0OiAxNnB4O1xuICBwYWRkaW5nLXJpZ2h0OiAxNnB4O1xufVxuXG5pb24tbWVudSBpb24tbm90ZSB7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbn1cblxuaW9uLW5vdGUge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgY29sb3I6ICMwMDA7XG4gIC8vIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtLXNoYWRlKTtcbn1cblxuaW9uLWl0ZW0ge1xuICAtLWNvbG9yOiAjY2NjO1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAvLyBib3JkZXItbGVmdDogNXB4IHNvbGlkICMxMTJjNDQ7XG59XG5cblxuaW9uLWl0ZW0uc2VsZWN0ZWQge1xuICAtLWNvbG9yOiAjMjIyO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgLy8gYm9yZGVyLWxlZnQ6IDVweCBzb2xpZCAjZjdmMWUzO1xuICAtLWJhY2tncm91bmQ6ICNmZmMwNDg7XG59XG5cbi5yaWdodFNpZGViYXIgaW9uLW1lbnUge1xuICAtLXNpZGUtd2lkdGg6IDQwcHg7XG59IFxuXG4ucmlnaHRTaWRlYmFyIGlvbi1saXN0IHtcbiAgLS1iYWNrZ3JvdW5kOiAjMDAwO1xuICBiYWNrZ3JvdW5kOiAjMDAwO1xufSBcblxuaW9uLXNwbGl0LXBhbmUge1xuICAtLXNpZGUtd2lkdGg6IDIwMHB4O1xufVxuXG5pb24taGVhZGVyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMDUxZTM0O1xuICBiYWNrZ3JvdW5kOiAjMDUxZTM0O1xufVxuXG5pb24tZm9vdGVyIHtcbiAgLy8gLS1pb24tYmFja2dyb3VuZDogIzA2MWUzNCAhaW1wb3J0YW50O1xuICAvLyBiYWNrZ3JvdW5kOiAjMDYxZTM0ICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogIzE2MWIyMjtcbn1cblxuaW9uLWxpc3Qge1xuICBiYWNrZ3JvdW5kOiAjMTYxYjIyO1xufVxuXG5pb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogIzE2MWIyMjtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzE2MWIyMjtcbn1cbiJdfQ== */";

/***/ }),

/***/ 4115:
/*!******************************************************************************!*\
  !*** ./src/app/pages/employee-profile/employee-profile.page.scss?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "ion-menu ion-content {\n  --background: var(--ion-item-background, var(--ion-background-color, #fff));\n}\n\nion-menu.md ion-content {\n  --padding-start: 8px;\n  --padding-end: 8px;\n  --padding-top: 20px;\n  --padding-bottom: 20px;\n}\n\nion-menu.md ion-list {\n  padding: 20px 0;\n}\n\nion-menu.md ion-note {\n  margin-bottom: 30px;\n}\n\nion-menu.md ion-list-header,\nion-menu.md ion-note {\n  padding-left: 10px;\n}\n\nion-menu.md ion-list#inbox-list {\n  border-bottom: 1px solid var(--ion-color-step-150, #d7d8da);\n}\n\nion-menu.md ion-list#inbox-list ion-list-header {\n  font-size: 22px;\n  font-weight: 600;\n  min-height: 20px;\n}\n\nion-menu.md ion-list#labels-list ion-list-header {\n  font-size: 16px;\n  margin-bottom: 18px;\n  color: #757575;\n  min-height: 26px;\n}\n\nion-menu.md ion-item {\n  --padding-start: 10px;\n  --padding-end: 10px;\n  border-radius: 4px;\n}\n\nion-menu.md ion-item.selected {\n  --background: rgba(var(--ion-color-primary-rgb), 0.14);\n}\n\nion-menu.md ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.md ion-item ion-icon {\n  color: #616e7e;\n}\n\nion-menu.md ion-item ion-label {\n  font-weight: 500;\n}\n\nion-menu.ios ion-content {\n  --padding-bottom: 20px;\n}\n\nion-menu.ios ion-list {\n  padding: 20px 0 0 0;\n}\n\nion-menu.ios ion-note {\n  line-height: 24px;\n  margin-bottom: 20px;\n}\n\nion-menu.ios ion-item {\n  --padding-start: 16px;\n  --padding-end: 16px;\n  --min-height: 50px;\n}\n\nion-menu.ios ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.ios ion-item ion-icon {\n  font-size: 24px;\n  color: #73849a;\n}\n\nion-menu.ios ion-list#labels-list ion-list-header {\n  margin-bottom: 8px;\n}\n\nion-menu.ios ion-list-header,\nion-menu.ios ion-note {\n  padding-left: 16px;\n  padding-right: 16px;\n}\n\nion-menu.ios ion-note {\n  margin-bottom: 8px;\n}\n\nion-note {\n  display: inline-block;\n  font-size: 16px;\n  color: var(--ion-color-medium-shade);\n}\n\nion-item.selected {\n  --color: var(--ion-color-primary);\n}\n\nion-list {\n  background: #f7f7f7;\n  padding: 10px;\n}\n\nion-item {\n  --background: transparent;\n}\n\nion-input {\n  border: 0.5px solid rgb(83, 83, 83);\n  background: #2c2d2e;\n  border-radius: 10px;\n  padding: 0px 10px !important;\n  color: #fff;\n}\n\nion-accordion {\n  background: #112c44;\n  color: #fff;\n}\n\nion-accordion.accordion-expanding .ion-accordion-toggle-icon,\nion-accordion.accordion-expanded .ion-accordion-toggle-icon {\n  color: #fff !important;\n}\n\nion-accordion.accordion-animated .ion-accordion-toggle-icon {\n  color: #fff !important;\n}\n\nion-accordion.accordion-animated .ion-accordion-toggle-icon {\n  color: #fff !important;\n}\n\n/* The container must be positioned relative: */\n\nion-item .custom-select {\n  position: relative;\n  font-family: Arial;\n}\n\nion-item .custom-select select {\n  display: none;\n  /*hide original SELECT element: */\n}\n\nselect {\n  width: 100%;\n  background: white;\n  color: #222;\n  padding: 7px;\n  border: 0.5px solid #ddd;\n  border-radius: 10px;\n  outline: none;\n}\n\nselect:active,\nselect:hover {\n  outline: none;\n}\n\nselect:focus {\n  border-color: gray;\n  outline: none;\n}\n\n.profileImage {\n  display: block;\n  width: 100%;\n  height: auto;\n  padding: 10px;\n  border-radius: 50%;\n}\n\ninput#file {\n  display: inline-block;\n  width: 100%;\n  padding: 50px 0 0 0;\n  height: 50px;\n  overflow: hidden;\n  box-sizing: border-box;\n  background: url(https://cdn1.iconfinder.com/data/icons/hawcons/32/698394-icon-130-cloud-upload-512.png) center center no-repeat #0d1116;\n  border-radius: 10px;\n  background-size: 60px 60px;\n  border: 0.5px solid #434343;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImVtcGxveWVlLXByb2ZpbGUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksMkVBQUE7QUFDSjs7QUFFRTtFQUNFLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLHNCQUFBO0FBQ0o7O0FBRUU7RUFDRSxlQUFBO0FBQ0o7O0FBRUU7RUFDRSxtQkFBQTtBQUNKOztBQUVFOztFQUVFLGtCQUFBO0FBQ0o7O0FBRUU7RUFDRSwyREFBQTtBQUNKOztBQUVFO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBRUEsZ0JBQUE7QUFBSjs7QUFHRTtFQUNFLGVBQUE7RUFFQSxtQkFBQTtFQUVBLGNBQUE7RUFFQSxnQkFBQTtBQUhKOztBQU1FO0VBQ0UscUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FBSEo7O0FBTUU7RUFDRSxzREFBQTtBQUhKOztBQU1FO0VBQ0UsK0JBQUE7QUFISjs7QUFNRTtFQUNFLGNBQUE7QUFISjs7QUFNRTtFQUNFLGdCQUFBO0FBSEo7O0FBTUU7RUFDRSxzQkFBQTtBQUhKOztBQU1FO0VBQ0UsbUJBQUE7QUFISjs7QUFNRTtFQUNFLGlCQUFBO0VBQ0EsbUJBQUE7QUFISjs7QUFNRTtFQUNFLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQUhKOztBQU1FO0VBQ0UsK0JBQUE7QUFISjs7QUFNRTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FBSEo7O0FBTUU7RUFDRSxrQkFBQTtBQUhKOztBQU1FOztFQUVFLGtCQUFBO0VBQ0EsbUJBQUE7QUFISjs7QUFNRTtFQUNFLGtCQUFBO0FBSEo7O0FBTUU7RUFDRSxxQkFBQTtFQUNBLGVBQUE7RUFFQSxvQ0FBQTtBQUpKOztBQU9FO0VBQ0UsaUNBQUE7QUFKSjs7QUFPRTtFQUNFLG1CQUFBO0VBQ0EsYUFBQTtBQUpKOztBQVFFO0VBQ0UseUJBQUE7QUFMSjs7QUFRRTtFQUNFLG1DQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLDRCQUFBO0VBQ0EsV0FBQTtBQUxKOztBQVlFO0VBQ0UsbUJBQUE7RUFDQSxXQUFBO0FBVEo7O0FBY0U7O0VBRUUsc0JBQUE7QUFYSjs7QUFlRTtFQUNFLHNCQUFBO0FBWko7O0FBZUU7RUFDRSxzQkFBQTtBQVpKOztBQXdCRSwrQ0FBQTs7QUFDQTtFQUNFLGtCQUFBO0VBQ0Esa0JBQUE7QUFyQko7O0FBd0JFO0VBQ0UsYUFBQTtFQUNBLGlDQUFBO0FBckJKOztBQXdCRTtFQUNFLFdBQUE7RUFDQSxpQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esd0JBQUE7RUFDQSxtQkFBQTtFQUVBLGFBQUE7QUF0Qko7O0FBeUJFOztFQUVFLGFBQUE7QUF0Qko7O0FBMEJFO0VBQ0Usa0JBQUE7RUFDQSxhQUFBO0FBdkJKOztBQTBCRTtFQUNNLGNBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtBQXZCUjs7QUEwQkU7RUFDRSxxQkFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLHNCQUFBO0VBQ0EsdUlBQUE7RUFDQSxtQkFBQTtFQUNBLDBCQUFBO0VBQ0EsMkJBQUE7QUF2QkoiLCJmaWxlIjoiZW1wbG95ZWUtcHJvZmlsZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tbWVudSBpb24tY29udGVudCB7XG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24taXRlbS1iYWNrZ3JvdW5kLCB2YXIoLS1pb24tYmFja2dyb3VuZC1jb2xvciwgI2ZmZikpO1xuICB9XG4gIFxuICBpb24tbWVudS5tZCBpb24tY29udGVudCB7XG4gICAgLS1wYWRkaW5nLXN0YXJ0OiA4cHg7XG4gICAgLS1wYWRkaW5nLWVuZDogOHB4O1xuICAgIC0tcGFkZGluZy10b3A6IDIwcHg7XG4gICAgLS1wYWRkaW5nLWJvdHRvbTogMjBweDtcbiAgfVxuICBcbiAgaW9uLW1lbnUubWQgaW9uLWxpc3Qge1xuICAgIHBhZGRpbmc6IDIwcHggMDtcbiAgfVxuICBcbiAgaW9uLW1lbnUubWQgaW9uLW5vdGUge1xuICAgIG1hcmdpbi1ib3R0b206IDMwcHg7XG4gIH1cbiAgXG4gIGlvbi1tZW51Lm1kIGlvbi1saXN0LWhlYWRlcixcbiAgaW9uLW1lbnUubWQgaW9uLW5vdGUge1xuICAgIHBhZGRpbmctbGVmdDogMTBweDtcbiAgfVxuICBcbiAgaW9uLW1lbnUubWQgaW9uLWxpc3QjaW5ib3gtbGlzdCB7XG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1zdGVwLTE1MCwgI2Q3ZDhkYSk7XG4gIH1cbiAgXG4gIGlvbi1tZW51Lm1kIGlvbi1saXN0I2luYm94LWxpc3QgaW9uLWxpc3QtaGVhZGVyIHtcbiAgICBmb250LXNpemU6IDIycHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBcbiAgICBtaW4taGVpZ2h0OiAyMHB4O1xuICB9XG4gIFxuICBpb24tbWVudS5tZCBpb24tbGlzdCNsYWJlbHMtbGlzdCBpb24tbGlzdC1oZWFkZXIge1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgXG4gICAgbWFyZ2luLWJvdHRvbTogMThweDtcbiAgXG4gICAgY29sb3I6ICM3NTc1NzU7XG4gIFxuICAgIG1pbi1oZWlnaHQ6IDI2cHg7XG4gIH1cbiAgXG4gIGlvbi1tZW51Lm1kIGlvbi1pdGVtIHtcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDEwcHg7XG4gICAgLS1wYWRkaW5nLWVuZDogMTBweDtcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XG4gIH1cbiAgXG4gIGlvbi1tZW51Lm1kIGlvbi1pdGVtLnNlbGVjdGVkIHtcbiAgICAtLWJhY2tncm91bmQ6IHJnYmEodmFyKC0taW9uLWNvbG9yLXByaW1hcnktcmdiKSwgMC4xNCk7XG4gIH1cbiAgXG4gIGlvbi1tZW51Lm1kIGlvbi1pdGVtLnNlbGVjdGVkIGlvbi1pY29uIHtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICB9XG4gIFxuICBpb24tbWVudS5tZCBpb24taXRlbSBpb24taWNvbiB7XG4gICAgY29sb3I6ICM2MTZlN2U7XG4gIH1cbiAgXG4gIGlvbi1tZW51Lm1kIGlvbi1pdGVtIGlvbi1sYWJlbCB7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgfVxuICBcbiAgaW9uLW1lbnUuaW9zIGlvbi1jb250ZW50IHtcbiAgICAtLXBhZGRpbmctYm90dG9tOiAyMHB4O1xuICB9XG4gIFxuICBpb24tbWVudS5pb3MgaW9uLWxpc3Qge1xuICAgIHBhZGRpbmc6IDIwcHggMCAwIDA7XG4gIH1cbiAgXG4gIGlvbi1tZW51LmlvcyBpb24tbm90ZSB7XG4gICAgbGluZS1oZWlnaHQ6IDI0cHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMjBweDtcbiAgfVxuICBcbiAgaW9uLW1lbnUuaW9zIGlvbi1pdGVtIHtcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDE2cHg7XG4gICAgLS1wYWRkaW5nLWVuZDogMTZweDtcbiAgICAtLW1pbi1oZWlnaHQ6IDUwcHg7XG4gIH1cbiAgXG4gIGlvbi1tZW51LmlvcyBpb24taXRlbS5zZWxlY3RlZCBpb24taWNvbiB7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgfVxuICBcbiAgaW9uLW1lbnUuaW9zIGlvbi1pdGVtIGlvbi1pY29uIHtcbiAgICBmb250LXNpemU6IDI0cHg7XG4gICAgY29sb3I6ICM3Mzg0OWE7XG4gIH1cbiAgXG4gIGlvbi1tZW51LmlvcyBpb24tbGlzdCNsYWJlbHMtbGlzdCBpb24tbGlzdC1oZWFkZXIge1xuICAgIG1hcmdpbi1ib3R0b206IDhweDtcbiAgfVxuICBcbiAgaW9uLW1lbnUuaW9zIGlvbi1saXN0LWhlYWRlcixcbiAgaW9uLW1lbnUuaW9zIGlvbi1ub3RlIHtcbiAgICBwYWRkaW5nLWxlZnQ6IDE2cHg7XG4gICAgcGFkZGluZy1yaWdodDogMTZweDtcbiAgfVxuICBcbiAgaW9uLW1lbnUuaW9zIGlvbi1ub3RlIHtcbiAgICBtYXJnaW4tYm90dG9tOiA4cHg7XG4gIH1cbiAgXG4gIGlvbi1ub3RlIHtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICBcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bS1zaGFkZSk7XG4gIH1cbiAgXG4gIGlvbi1pdGVtLnNlbGVjdGVkIHtcbiAgICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gIH1cbiAgXG4gIGlvbi1saXN0IHtcbiAgICBiYWNrZ3JvdW5kOiAjZjdmN2Y3O1xuICAgIHBhZGRpbmc6IDEwcHg7XG4gIH1cbiAgXG4gIFxuICBpb24taXRlbSB7XG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgfVxuICBcbiAgaW9uLWlucHV0IHtcbiAgICBib3JkZXI6IDAuNXB4IHNvbGlkIHJnYig4MywgODMsIDgzKTtcbiAgICBiYWNrZ3JvdW5kOiAjMmMyZDJlO1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgcGFkZGluZzogMHB4IDEwcHggIWltcG9ydGFudDtcbiAgICBjb2xvcjogI2ZmZjtcbiAgfVxuICBcbiAgLy8gaW5wdXQge1xuICAvLyAgIHBhZGRpbmc6IDEwcHggIWltcG9ydGFudDtcbiAgLy8gfVxuICBcbiAgaW9uLWFjY29yZGlvbiB7XG4gICAgYmFja2dyb3VuZDogIzExMmM0NDtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICAvLyBiYWNrZ3JvdW5kOiAjNzQ4Y2IyO1xuICB9XG4gIFxuICBcbiAgaW9uLWFjY29yZGlvbi5hY2NvcmRpb24tZXhwYW5kaW5nIC5pb24tYWNjb3JkaW9uLXRvZ2dsZS1pY29uLFxuICBpb24tYWNjb3JkaW9uLmFjY29yZGlvbi1leHBhbmRlZCAuaW9uLWFjY29yZGlvbi10b2dnbGUtaWNvbiB7XG4gICAgY29sb3I6ICNmZmYgIWltcG9ydGFudDtcbiAgfVxuICBcbiAgXG4gIGlvbi1hY2NvcmRpb24uYWNjb3JkaW9uLWFuaW1hdGVkIC5pb24tYWNjb3JkaW9uLXRvZ2dsZS1pY29uIHtcbiAgICBjb2xvcjogI2ZmZiAhaW1wb3J0YW50O1xuICB9XG4gIFxuICBpb24tYWNjb3JkaW9uLmFjY29yZGlvbi1hbmltYXRlZCAuaW9uLWFjY29yZGlvbi10b2dnbGUtaWNvbiB7XG4gICAgY29sb3I6ICNmZmYgIWltcG9ydGFudDtcbiAgfVxuICBcbiAgLy8gLm15LWN1c3RvbS1tb2RhbC1jc3MgLm1vZGFsLXdyYXBwZXIge1xuICAvLyAgIGhlaWdodDogMjAlO1xuICAvLyAgIHdpZHRoOiAyMCU7XG4gIC8vICAgcG9zaXRpb246IGFic29sdXRlOyBcbiAgLy8gICBkaXNwbGF5OiBibG9jazsgIFxuICAvLyB9XG4gIFxuICBcbiAgXG4gIC8qIFRoZSBjb250YWluZXIgbXVzdCBiZSBwb3NpdGlvbmVkIHJlbGF0aXZlOiAqL1xuICBpb24taXRlbSAuY3VzdG9tLXNlbGVjdCB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIGZvbnQtZmFtaWx5OiBBcmlhbDtcbiAgfVxuICBcbiAgaW9uLWl0ZW0gLmN1c3RvbS1zZWxlY3Qgc2VsZWN0IHtcbiAgICBkaXNwbGF5OiBub25lO1xuICAgIC8qaGlkZSBvcmlnaW5hbCBTRUxFQ1QgZWxlbWVudDogKi9cbiAgfVxuICBcbiAgc2VsZWN0IHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgICBjb2xvcjogIzIyMjtcbiAgICBwYWRkaW5nOiA3cHg7XG4gICAgYm9yZGVyOiAwLjVweCBzb2xpZCAjZGRkO1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgLy8gYm94LXNoYWRvdzogMCAwIDEwcHggMTAwcHggI2ZmZiBpbnNldDtcbiAgICBvdXRsaW5lOiBub25lXG4gIH1cbiAgXG4gIHNlbGVjdDphY3RpdmUsXG4gIHNlbGVjdDpob3ZlciB7XG4gICAgb3V0bGluZTogbm9uZVxuICB9XG4gIFxuICBcbiAgc2VsZWN0OmZvY3VzIHtcbiAgICBib3JkZXItY29sb3I6IGdyYXk7XG4gICAgb3V0bGluZTogbm9uZTtcbiAgfVxuXG4gIC5wcm9maWxlSW1hZ2Uge1xuICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIGhlaWdodDogYXV0bztcbiAgICAgICAgcGFkZGluZzogMTBweDtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICB9XG5cbiAgaW5wdXQjZmlsZSB7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIHBhZGRpbmc6IDUwcHggMCAwIDA7XG4gICAgaGVpZ2h0OiA1MHB4O1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgICBiYWNrZ3JvdW5kOiB1cmwoaHR0cHM6Ly9jZG4xLmljb25maW5kZXIuY29tL2RhdGEvaWNvbnMvaGF3Y29ucy8zMi82OTgzOTQtaWNvbi0xMzAtY2xvdWQtdXBsb2FkLTUxMi5wbmcpIGNlbnRlciBjZW50ZXIgbm8tcmVwZWF0ICMwZDExMTY7XG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICBiYWNrZ3JvdW5kLXNpemU6IDYwcHggNjBweDtcbiAgICBib3JkZXI6IDAuNXB4IHNvbGlkICM0MzQzNDM7XG59Il19 */";

/***/ }),

/***/ 3383:
/*!***********************************************!*\
  !*** ./src/app/app.component.html?ngResource ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-app>\n  <ion-split-pane contentId=\"main-content\">\n    <!-- <div side=\"start\" style=\"margin-right: -200px;background-color: #000;border-right: 5px solid #000;\" class=\"rightSidebar\">\n\n        <ion-list id=\"inbox-list\">\n          <ion-list-header style=\"color: #000;\"></ion-list-header>\n          <ion-note style=\"padding-bottom: 10px;color: #000;border-bottom: 1px solid #000;width: 100%;\"></ion-note>\n            <ion-item routerDirection=\"root\" lines=\"none\" detail=\"false\" routerLinkActive=\"selected\">\n              <ion-icon name=\"chatbubbles-outline\"></ion-icon>\n            </ion-item>\n        </ion-list>\n    </div> -->\n    <ion-menu side=\"start\" contentId=\"main-content\" type=\"overlay\">\n      <ion-content>\n        <div style=\"text-align: left;padding-top: 20px;padding-left: 20px;\">\n          <img src=\"assets/icon/mckinsol-logo.png\" style=\"width:80px;\">\n        </div>\n        <ion-list id=\"inbox-list\">\n\n          <ion-list-header style=\"color: #fff;margin-bottom: 20px;\">Mckinsol Portal</ion-list-header>\n          <!-- <ion-note style=\"padding-bottom: 10px;color: #fff;border-bottom: 1px solid #42515c;width: 100%;\"></ion-note> -->\n\n          <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of modules; let i = index\">\n            <ion-item routerDirection=\"root\" [routerLink]=\"[p.url]\" lines=\"none\" detail=\"false\" routerLinkActive=\"selected\">\n              <ion-icon slot=\"start\" [ios]=\"p.icon + '-outline'\" [md]=\"p.icon + '-sharp'\"></ion-icon>\n              <ion-label>{{ p.title }}</ion-label>\n            </ion-item>\n          </ion-menu-toggle>\n        </ion-list>\n      </ion-content>\n      <ion-footer>\n        <ion-toolbar>\n\n          <ion-item lines=\"none\" (click)=\"openProfile()\" style=\"cursor: pointer;border-bottom: 0px solid #394351;border-top: 0.5px solid #394351;margin-bottom: 0px\">\n            <ion-avatar slot=\"start\">\n              <ion-img [src]=\"user.image\"></ion-img>\n            </ion-avatar>\n            <ion-label>\n              <div>{{user.organisationName || user.firstName}}</div>\n              <p>{{user.organisationEmail || user.officialEmail}}</p>\n            </ion-label>\n            <!-- <ion-icon slot=\"end\" name=\"create-outline\"></ion-icon> -->\n          </ion-item>\n          <!-- <ion-item lines=\"none\" (click)=\"logout()\" style=\"cursor: pointer;\">\n            <ion-label>Logout</ion-label>\n            <ion-icon name=\"log-out-outline\"></ion-icon>\n          </ion-item> -->\n        </ion-toolbar>\n      </ion-footer>\n    </ion-menu>\n    <ion-router-outlet id=\"main-content\"></ion-router-outlet>\n  </ion-split-pane>\n</ion-app>\n";

/***/ }),

/***/ 398:
/*!******************************************************************************!*\
  !*** ./src/app/pages/employee-profile/employee-profile.page.html?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header>\n  <ion-toolbar color=\"gray\">\n    <ion-title>Profile</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button color=\"success\" (click)=\"updateEmployee()\">Update</ion-button>\n      <ion-button (click)=\"modalController.dismiss()\">\n        <ion-icon name=\"arrow-down\"></ion-icon>\n      </ion-button>\n      <!-- <ion-button>\n        <ion-icon name=\"settings-outline\"></ion-icon>\n      </ion-button> -->\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content>\n\n  <!-- <div style=\"margin: 20px;\n  background-color: #3c40c6;\n  color: #fff;\n  font-size: 16px;\n  padding: 10px;\n  font-weight: bold;\n  border-radius: 10px;\">\n    The Add Employee wizard guides you through the process of adding a new employee. You have the flexibility to enter\n    comprehensive information about a new employee as soon as the person joins or first add salient details and update\n    remaining details later.\n  </div> -->\n\n  <div>\n    \n  </div>\n\n\n  <div>\n    <ion-row>\n      <ion-col sizeLg=\"2\" offsetLg=\"0.5\">\n<!-- <ion-avatar> -->\n<img class=\"profileImage\" [src]=\"croppedImage || employeeDetails.image\" />\n<!-- <ion-img class=\"profileImage\" [src]=croppedImage || employeeDetails.image\"></ion-img> -->\n<form>\n  <input id=\"file\" type=\"file\" (change)=\"fileChangeEvent($event)\" />\n</form>\n  <image-cropper *ngIf=\"imageChangedEvent\"\n  [imageChangedEvent]=\"imageChangedEvent\"\n  [maintainAspectRatio]=\"true\"\n  [resizeToWidth]=\"200\"\n  [resizeToHeight]=\"200\"\n  [aspectRatio]=\"4 / 4\"\n  format=\"png\"\n  (imageCropped)=\"imageCropped($event)\"\n  (imageLoaded)=\"imageLoaded($event)\"\n  (cropperReady)=\"cropperReady()\"\n  (loadImageFailed)=\"loadImageFailed()\"\n></image-cropper>\n\n\n<!-- </ion-avatar> -->\n      </ion-col>\n      <ion-col sizeLg=\"9.5\" *ngIf=\"segment=='user'\">\n        <!-- <ion-card> -->\n        <!-- <ion-card-header>\n        User Info\n      </ion-card-header>\n      <ion-card-content> -->\n        <form [formGroup]=\"basic\">\n          <!-- <ion-card> -->\n          <ion-list id=\"inbox-list\" lines=\"none\" style=\"background: transparent;padding:10px 20px;\">\n            <ion-row style=\"padding-bottom: 10px;\">\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">First Name*</ion-label>\n                  <ion-input [disabled]=\"true\" formControlName=\"firstName\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Middle name</ion-label>\n                  <ion-input formControlName=\"middleName\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Last name*</ion-label>\n                  <ion-input [disabled]=\"true\" formControlName=\"lastName\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"8\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Designation</ion-label>\n                  <ion-input [disabled]=\"true\" formControlName=\"designation\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Gender*</ion-label>\n                  <select [disabled] formControlName=\"gender\" style=\"width: 100%;\n                      background: #2c2d2e; color: #fff; padding: 7px;border: 0.5px solid rgb(83, 83, 83)\">\n                    <option value=\"Male\">Male</option>\n                    <option value=\"Female\">Female</option>\n                    <option value=\"Others\">Others</option>\n                  </select>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Phone Number*</ion-label>\n                  <ion-input formControlName=\"phoneNo\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Personal Email*</ion-label>\n                  <ion-input [disabled]=\"true\" formControlName=\"personalEmail\"></ion-input>\n                </ion-item>\n              </ion-col>\n            </ion-row>\n            <ion-row style=\"padding-bottom: 10px;\">\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Spouse Name</ion-label>\n                  <ion-input formControlName=\"spouseName\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Father Name*</ion-label>\n                  <ion-input type=\"text\" formControlName=\"fatherName\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <!-- <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Date of Birth*</ion-label>\n                  <ion-input type=\"date\" formControlName=\"DOB\"></ion-input>\n                </ion-item>\n              </ion-col> -->\n              <!-- <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Emergency Contact Name*</ion-label>\n                  <ion-input formControlName=\"emergencyContactName\"></ion-input>\n                </ion-item>\n              </ion-col> -->\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Emergency Contact Number*</ion-label>\n                  <ion-input formControlName=\"emergencyContactNumber\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <!-- <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Pan Number*</ion-label>\n                  <ion-input formControlName=\"panNumber\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"4\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Aadhar Number*</ion-label>\n                  <ion-input formControlName=\"adharNumber\"></ion-input>\n                </ion-item>\n              </ion-col> -->\n            </ion-row>\n            <ion-row style=\"padding-bottom: 10px;\">\n              <ion-col size=\"12\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Present Address*</ion-label>\n                  <ion-input formControlName=\"presentAddress\"></ion-input>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"12\">\n                <ion-item>\n                  <ion-label position=\"stacked\" style=\"color: #fff;\">Permanent Address*</ion-label>\n                  <ion-input formControlName=\"permanentAddress\"></ion-input>\n                </ion-item>\n              </ion-col>\n            </ion-row>\n            <ion-row style=\"padding-bottom: 10px;\">\n            </ion-row>\n          </ion-list>\n          <!-- </ion-card-content> -->\n        </form>\n        <!-- </ion-card> -->\n      </ion-col>\n    </ion-row>\n\n  </div>\n</ion-content>\n<ion-footer class=\"ion-no-border\" color=\"gray\">\n  <ion-toolbar color=\"gray\">\n    <ion-buttons slot=\"end\">\n      <ion-button *ngIf=\"segment=='card' && updateFlag\" expand=\"block\" fill=\"solid\" color=\"success\"\n        style=\"font-weight: 300;width: 150px;\" (click)=\"updateEmployee()\">Update</ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-footer>\n";

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(4431)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map