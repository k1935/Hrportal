"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_salary_salary_module_ts"],{

/***/ 9711:
/*!*******************************************************!*\
  !*** ./src/app/pages/salary/salary-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SalaryPageRoutingModule": () => (/* binding */ SalaryPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _salary_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./salary.page */ 8382);




const routes = [
    {
        path: '',
        component: _salary_page__WEBPACK_IMPORTED_MODULE_0__.SalaryPage
    }
];
let SalaryPageRoutingModule = class SalaryPageRoutingModule {
};
SalaryPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SalaryPageRoutingModule);



/***/ }),

/***/ 5859:
/*!***********************************************!*\
  !*** ./src/app/pages/salary/salary.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SalaryPageModule": () => (/* binding */ SalaryPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _salary_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./salary-routing.module */ 9711);
/* harmony import */ var _salary_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./salary.page */ 8382);







let SalaryPageModule = class SalaryPageModule {
};
SalaryPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _salary_routing_module__WEBPACK_IMPORTED_MODULE_0__.SalaryPageRoutingModule
        ],
        declarations: [_salary_page__WEBPACK_IMPORTED_MODULE_1__.SalaryPage]
    })
], SalaryPageModule);



/***/ }),

/***/ 8382:
/*!*********************************************!*\
  !*** ./src/app/pages/salary/salary.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SalaryPage": () => (/* binding */ SalaryPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _salary_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./salary.page.html?ngResource */ 7090);
/* harmony import */ var _salary_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./salary.page.scss?ngResource */ 8021);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/common.service */ 5620);






let SalaryPage = class SalaryPage {
    constructor(commonService, router) {
        this.commonService = commonService;
        this.router = router;
        this.allRequests = [];
        this.allYears = [];
        this.allMonths = ["January", "February", "March", "April", "May", "June", "July",
            "August", "September", "October", "November", "December"];
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        let date = new Date();
        this.allYears = [];
        this.year = date.getFullYear();
        this.month = date.getMonth() + 1;
        // console.log("year ",this.year)
        // console.log("month ",this.month)
        for (let i = 0; i <= 10; i++)
            this.allYears.push(parseInt(this.year) - i);
        // this.fetchEmployee(null);
    }
    ////Fetch Employees who are on boarding
    fetchEmployee(ev) {
        let formData = {
            organisationCode: localStorage.getItem('organisationId'),
            month: this.month,
            year: this.year,
        };
        this.commonService.getMonthlySalary(formData).then((resp) => {
            this.allRequests = resp;
            console.log("response from getEmployee", this.allRequests);
        });
    }
    ////Method to navigate on onboarding page for updating details
    generateSalaries() {
        let formData = {
            organisationId: localStorage.getItem('organisationId'),
            month: this.month,
            year: this.year,
        };
        this.commonService.generateSalaries(formData).then((resp) => {
            this.fetchEmployee(null);
            console.log("response from getEmployee", this.allRequests);
        });
    }
    toFixed(amt) {
        return amt.toFixed(2);
    }
};
SalaryPage.ctorParameters = () => [
    { type: _services_common_service__WEBPACK_IMPORTED_MODULE_2__.CommonService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router }
];
SalaryPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-salary',
        template: _salary_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_salary_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], SalaryPage);



/***/ }),

/***/ 8021:
/*!**********************************************************!*\
  !*** ./src/app/pages/salary/salary.page.scss?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = "ion-menu-button {\n  color: var(--ion-color-primary);\n}\n\n#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n\n.demo-chart {\n  width: 100%;\n  height: 300px;\n}\n\nion-grid {\n  --ion-grid-column-padding: 10px;\n  border-collapse: collapse;\n  border-style: hidden;\n  margin-top: 0px;\n  padding-top: 0px;\n}\n\nion-grid ion-row {\n  margin: 5px 0px;\n}\n\nion-grid ion-row:first-child {\n  background-color: #2980b9;\n  border-radius: 5px;\n  color: #fff;\n  font-weight: bold;\n}\n\nion-grid ion-col {\n  border-bottom: 0;\n  border-right: 0;\n}\n\n:host ::ng-deep .ngx-datatable .datatable-body .datatable-scroll {\n  display: inherit;\n}\n\n.odd {\n  background-color: #252628;\n  color: #fff;\n  border-radius: 5px;\n}\n\n.even {\n  background-color: #252628;\n  color: #fff;\n  border-radius: 5px;\n}\n\nion-item {\n  --background: transparent;\n}\n\nion-select {\n  width: 100%;\n}\n\nion-grid ion-col {\n  border-bottom: 0;\n  border-right: 0;\n  font-size: 14px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNhbGFyeS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUE7RUFDSSwrQkFBQTtBQURKOztBQUlFO0VBQ0Usa0JBQUE7RUFDQSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsUUFBQTtFQUNBLDJCQUFBO0FBREo7O0FBSUU7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7QUFESjs7QUFJRTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxTQUFBO0FBREo7O0FBSUU7RUFDRSxxQkFBQTtBQURKOztBQUlFO0VBQ0UsV0FBQTtFQUNBLGFBQUE7QUFESjs7QUFJRTtFQUNFLCtCQUFBO0VBQ0EseUJBQUE7RUFDQSxvQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQURKOztBQUtJO0VBQ0UsZUFBQTtBQUhOOztBQU1JO0VBQ0UseUJBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtBQUpOOztBQU9JO0VBRUUsZ0JBQUE7RUFDQSxlQUFBO0FBTk47O0FBa0JFO0VBQ0UsZ0JBQUE7QUFmSjs7QUFrQkU7RUFDRSx5QkFBQTtFQUdBLFdBQUE7RUFDQSxrQkFBQTtBQWpCSjs7QUFvQkU7RUFDRSx5QkFBQTtFQUNBLFdBQUE7RUFHQSxrQkFBQTtBQW5CSjs7QUFzQkU7RUFDRSx5QkFBQTtBQW5CSjs7QUF1QkU7RUFDRSxXQUFBO0FBcEJKOztBQXVCRTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7QUFwQkoiLCJmaWxlIjoic2FsYXJ5LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxuXG5pb24tbWVudS1idXR0b24ge1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gIH1cbiAgXG4gICNjb250YWluZXIge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgbGVmdDogMDtcbiAgICByaWdodDogMDtcbiAgICB0b3A6IDUwJTtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSk7XG4gIH1cbiAgXG4gICNjb250YWluZXIgc3Ryb25nIHtcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgbGluZS1oZWlnaHQ6IDI2cHg7XG4gIH1cbiAgXG4gICNjb250YWluZXIgcCB7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIGxpbmUtaGVpZ2h0OiAyMnB4O1xuICAgIGNvbG9yOiAjOGM4YzhjO1xuICAgIG1hcmdpbjogMDtcbiAgfVxuICBcbiAgI2NvbnRhaW5lciBhIHtcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG4gIH1cbiAgXG4gIC5kZW1vLWNoYXJ0IHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDMwMHB4O1xuICB9XG4gIFxuICBpb24tZ3JpZCB7XG4gICAgLS1pb24tZ3JpZC1jb2x1bW4tcGFkZGluZzogMTBweDtcbiAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xuICAgIGJvcmRlci1zdHlsZTogaGlkZGVuO1xuICAgIG1hcmdpbi10b3A6IDBweDtcbiAgICBwYWRkaW5nLXRvcDogMHB4O1xuICAgIC8vIHBhZGRpbmc6IDEwcHg7XG4gICAgLy8gYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgXG4gICAgaW9uLXJvdyB7XG4gICAgICBtYXJnaW46IDVweCAwcHg7XG4gICAgfVxuICBcbiAgICBpb24tcm93OmZpcnN0LWNoaWxkIHtcbiAgICAgIGJhY2tncm91bmQtY29sb3I6ICMyOTgwYjk7XG4gICAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgICBjb2xvcjogI2ZmZjtcbiAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIH1cbiAgXG4gICAgaW9uLWNvbCB7XG4gICAgICAvLyBib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xuICAgICAgYm9yZGVyLWJvdHRvbTogMDtcbiAgICAgIGJvcmRlci1yaWdodDogMDtcbiAgICB9XG4gIFxuICAgIC8vIGlvbi1jb2w6bGFzdC1jaGlsZCB7XG4gICAgICAvLyBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCBibGFjaztcbiAgICAvLyB9XG4gIFxuICAgIC8vIGlvbi1yb3c6bGFzdC1jaGlsZCB7XG4gICAgICAvLyBib3JkZXItYm90dG9tOiAxcHggc29saWQgYmxhY2s7XG4gICAgLy8gfVxuICB9XG4gIFxuICA6aG9zdCA6Om5nLWRlZXAgLm5neC1kYXRhdGFibGUgLmRhdGF0YWJsZS1ib2R5IC5kYXRhdGFibGUtc2Nyb2xsIHtcbiAgICBkaXNwbGF5OiBpbmhlcml0O1xuICB9XG4gIFxuICAub2RkIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMjUyNjI4O1xuICAgIC8vIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjY2NjO1xuICAgIC8vIGJveC1zaGFkb3c6IDAgMXB4IDJweCAwIHJnYig2MCA2NCA2NyAvIDMwJSksIDAgMXB4IDNweCAxcHggcmdiKDYwIDY0IDY3IC8gMTUlKTtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIH1cbiAgXG4gIC5ldmVuIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMjUyNjI4O1xuICAgIGNvbG9yOiAjZmZmO1xuICAgIC8vIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjY2NjO1xuICAgIC8vIGJveC1zaGFkb3c6IDAgMXB4IDJweCAwIHJnYig2MCA2NCA2NyAvIDMwJSksIDAgMXB4IDNweCAxcHggcmdiKDYwIDY0IDY3IC8gMTUlKTtcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIH1cbiAgXG4gIGlvbi1pdGVtIHtcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICB9XG5cbiAgXG4gIGlvbi1zZWxlY3Qge1xuICAgIHdpZHRoOiAxMDAlO1xuICB9XG4gIFxuICBpb24tZ3JpZCBpb24tY29sIHtcbiAgICBib3JkZXItYm90dG9tOiAwO1xuICAgIGJvcmRlci1yaWdodDogMDtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gIH0iXX0= */";

/***/ }),

/***/ 7090:
/*!**********************************************************!*\
  !*** ./src/app/pages/salary/salary.page.html?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = "<ion-header class=\"ion-no-border\">\n  <ion-toolbar color=\"dark\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Employees Salary List</ion-title>\n    <!-- <ion-buttons slot=\"end\" class=\"hidden-sm-down\">\n      <ion-button [routerLink]=\"['/employee-onboarding/null']\" color=\"primary\" style=\"font-weight: 300;width: 100px;\">\n        <ion-icon name=\"person-add-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons> -->\n    \n  </ion-toolbar>\n  <ion-toolbar color=\"dark\">\n    <ion-searchbar placeholder=\"Filter Requests\"></ion-searchbar>\n  </ion-toolbar>\n  <ion-toolbar color=\"dark\">\n    <ion-row>\n      <ion-col size=\"2\" style=\"border: 1px solid rgb(37 38 40);background-color: rgb(30 31 33);padding: 0px;\">\n        </ion-col>\n      <ion-col size=\"3\" style=\"border: 1px solid rgb(37 38 40);background-color: rgb(30 31 33);padding: 0px;\">\n        <ion-item lines=\"none\">\n          <ion-select [(ngModel)]=\"year\" placeholder=\"Select Year\" (ionChange)=\"fetchEmployee($event)\" style=\"color: #ccc;font-weight: bold;\">\n            <ion-select-option *ngFor=\"let year of allYears;\" [value]=\"year\">{{year}}</ion-select-option>\n          </ion-select>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"3\" style=\"border: 1px solid rgb(37 38 40);background-color: rgb(30 31 33);padding: 0px;\">\n        <ion-item lines=\"none\">\n          <ion-select [(ngModel)]=\"month\" placeholder=\"Select Month\" (ionChange)=\"fetchEmployee($event)\" style=\"color: #ccc;font-weight: bold;\">\n            <ion-select-option *ngFor=\"let month of allMonths; let i = index;\" [value]=\"i + 1\">{{month}}</ion-select-option>\n          </ion-select>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"2\" style=\"border: 1px solid rgb(37 38 40);background-color: rgb(30 31 33);padding: 0px;\">\n        <ion-button\n        (click)=\"generateSalaries()\"\n        \n        color=\"dark\"\n        size=\"small\"\n        expand=\"block\"\n        style=\"font-size: 17px;\"\n      >\n      Generate Salaries\n      </ion-button>\n      </ion-col>\n      <ion-col size=\"2\" style=\"border: 1px solid rgb(37 38 40);background-color: rgb(30 31 33);padding: 0px;\">\n        <ion-button\n        (click)=\"showModal()\"\n       \n        color=\"dark\"\n        size=\"small\"\n        expand=\"block\"\n        style=\"font-size: 17px;\"\n      >\n      Download Excel\n      </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <!-- Desktop View -->\n  <ion-grid class=\"ion-margin hidden-sm-down\">    \n    <ion-row style=\"position: sticky;top: 0px;z-index: 999999999;background-color: #000;color: #fff;margin: 0px;\">\n      <ion-col size=\"1.5\">Employee Name</ion-col>\n      <ion-col size=\"1\">Emp. Id</ion-col>\n      <ion-col size=\"1\">Payable Days</ion-col>\n      <ion-col size=\"1.5\">Basic Sal.</ion-col>\n      <ion-col size=\"1.5\">Tot. Sal.</ion-col>\n      <ion-col size=\"1\">PF Ded.</ion-col>\n      <ion-col size=\"1\">ESIC Ded.</ion-col>\n      <ion-col size=\"1\">OT Hrs.</ion-col>\n      <ion-col size=\"1\">OT Sal.</ion-col>\n      <ion-col size=\"1.5\">Sal. After Ded.</ion-col>\n      <!-- <ion-col size=\"1\"></ion-col> -->\n    </ion-row>\n    <ion-row *ngIf=\"allRequests.length == 0\">\n      <div id=\"container\">\n        <img width=\"200px\" src=\"https://i.gifer.com/origin/f5/f5baef4b6b6677020ab8d091ef78a3bc_w200.webp\" alt=\"\">\n      </div>\n    </ion-row>\n    <ion-row *ngFor=\"let request of allRequests; index as i\" [ngClass]=\"(i % 2 == 0) ? 'odd' : 'even'\">\n      <ion-col size=\"1.5\">{{request.firstName}} {{request.middleName}} {{request.lastName}}</ion-col>\n      <ion-col size=\"1\">{{request.employeeID}}</ion-col>\n      <ion-col size=\"1\">{{request.totalWorkingDays}} days</ion-col>\n      <ion-col size=\"1.5\">{{request.basicSalary}}</ion-col>\n      <ion-col size=\"1.5\">{{request.totalSalary}}</ion-col>\n      <ion-col size=\"1\">{{request.pfDeduction}}</ion-col>\n      <ion-col size=\"1\">{{request.esicDeduction}}</ion-col>\n      <ion-col size=\"1\">{{request.overtimeHours}}</ion-col>\n      <ion-col size=\"1\">{{request.overtimeSalary}}</ion-col>\n      <ion-col size=\"1.5\">{{toFixed(request.overAllDeductedSalary + request.overtimeSalary)}}</ion-col>\n      <!-- <ion-col style=\"padding: 0px;text-align: center;\" size=\"1\">\n        <ion-button  (click)=\"updateEmployee(request)\" style=\"text-align: center;\" size=\"small\" fill=\"clear\"\n          color=\"primary\">\n          <ion-icon slot=\"icon-only\" name=\"create-outline\"></ion-icon>\n        </ion-button>\n      </ion-col> -->\n    </ion-row>\n  </ion-grid>\n  <ion-infinite-scroll>\n    <ion-infinite-scroll-content loadingSpinner=\"bubbles\" loadingText=\"Loading more data...\">\n    </ion-infinite-scroll-content>\n  </ion-infinite-scroll>\n</ion-content>\n<!-- <ion-footer>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"showModal()\" fill=\"outline\" color=\"dark\" expand=\"block\" style=\"font-weight: 300;width: 80px;\">\n        Import\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-footer> -->\n\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_salary_salary_module_ts.js.map