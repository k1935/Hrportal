"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_teams_teams_module_ts"],{

/***/ 9784:
/*!*****************************************************!*\
  !*** ./src/app/pages/teams/teams-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TeamsPageRoutingModule": () => (/* binding */ TeamsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _teams_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./teams.page */ 7327);




const routes = [
    {
        path: '',
        component: _teams_page__WEBPACK_IMPORTED_MODULE_0__.TeamsPage
    }
];
let TeamsPageRoutingModule = class TeamsPageRoutingModule {
};
TeamsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], TeamsPageRoutingModule);



/***/ }),

/***/ 8573:
/*!*********************************************!*\
  !*** ./src/app/pages/teams/teams.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TeamsPageModule": () => (/* binding */ TeamsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/cdk/scrolling */ 6328);
/* harmony import */ var _teams_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./teams-routing.module */ 9784);
/* harmony import */ var _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/cdk/overlay */ 5895);
/* harmony import */ var _teams_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./teams.page */ 7327);









let TeamsPageModule = class TeamsPageModule {
};
TeamsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_5__.OverlayModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_7__.ScrollingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _teams_routing_module__WEBPACK_IMPORTED_MODULE_0__.TeamsPageRoutingModule
        ],
        declarations: [_teams_page__WEBPACK_IMPORTED_MODULE_1__.TeamsPage]
    })
], TeamsPageModule);



/***/ }),

/***/ 7327:
/*!*******************************************!*\
  !*** ./src/app/pages/teams/teams.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TeamsPage": () => (/* binding */ TeamsPage)
/* harmony export */ });
/* harmony import */ var _Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _teams_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./teams.page.html?ngResource */ 4547);
/* harmony import */ var _teams_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./teams.page.scss?ngResource */ 7195);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);
/* harmony import */ var _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/cdk/overlay */ 5895);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/common.service */ 5620);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 124);











let TeamsPage = class TeamsPage {
  constructor(fb, alertController, commonService, overlay, menuController, // private loadingService: LoadingService,
  platform, authService, // private userService: UserService,
  // private helperService: HelperService,
  // private authService: AuthService,
  router) {
    this.fb = fb;
    this.alertController = alertController;
    this.commonService = commonService;
    this.overlay = overlay;
    this.menuController = menuController;
    this.platform = platform;
    this.authService = authService;
    this.router = router;
    this.segment = 'teams';
    this.working = {
      monday: false,
      tuesday: false,
      wednesday: false,
      thursday: false,
      friday: false,
      saturday: false,
      sunday: false
    };
    this.allTeams = [];
    this.allUsers = [];
    this.managers = [];
    this.boardColumns = [];
    this.selectedTeam = 0;
    this.isOpen = false;
    this.changeText = false;
    this.managersToggle = {};
    this.keepOn = {};
  }

  ngOnInit() {
    this.form = this.fb.group({
      organisationName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      // organisationCode: ['', Validators.required],
      organisationGST: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      organisationPAN: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      organisationEmail: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      organisationBranch: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      organisationPhone: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      organisationAddress: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      NumberofEmployee: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required] // email: ['', Validators.required],
      // pwd: ['', Validators.required],

    });
    this.fetchAllTeams();
  }

  fetchAllTeams() {
    this.commonService.fetchAllTeams().then(resp => {
      this.allTeams = resp;
      this.getEmployeesByIds(this.allTeams[this.selectedTeam]['users']);
      this.allTeams.forEach((team, m) => {
        this.managersToggle[m] = {};
        this.keepOn[m] = {};
        this.fetchTeamColumns(team);
        this.commonService.getEmployeesByIds(team.managers).then(managersData => {
          team.managersData = managersData;
        });
      });
      console.log("this.managersToggle ", this.managersToggle);
    });
  }

  delayMouseOverToggle(managersToggle, i, m) {
    // setTimeout(() => {
    this.keepOn[i][m] = false;
    let iKeys = Object.keys(managersToggle);
    iKeys.forEach(ikey => {
      let mKeys = Object.keys(managersToggle[ikey]);
      mKeys.forEach(mkey => {
        mkey = false;
      });
    }); // console.log("managersToggle ",managersToggle)
    // console.log("this.keepOn ",this.keepOn)
    // if(!this.keepOn[i][m])

    managersToggle[i][m] = true; // }, 500);
  }

  delayMouseOutToggle(managersToggle, i, m) {
    // console.log("delayMouseOutToggle ")
    setTimeout(() => {
      // console.log("managersToggle ",managersToggle)
      // console.log("this.keepOn ",this.keepOn)
      if (!this.keepOn[i][m]) managersToggle[i][m] = false;
    }, 200);
  }

  closePopover(managersToggle, i, m) {
    // console.log("closePopover ")
    // console.log("this.keepOn[i][m]  ", this.keepOn[i][m])
    this.keepOn[i][m] = false;
    managersToggle[i][m] = false;
  }

  fetchTeamColumns(team) {
    this.commonService.fetchTeamColumns(team.teamId).then(resp => {
      team.teamBoardColumns = resp;
    });
  }

  getEmployeesByIds(employeeIds) {
    console.log("employeeIds  ", employeeIds);
    this.commonService.getEmployeesByIds(employeeIds).then(resp => {
      this.allUsers = resp;
    });
  }

  getTeamManagers(team) {
    this.commonService.getEmployeesByIds(team.managers).then(resp => {
      team.managersData = resp;
    });
  }

  selectTeam(index) {
    this.selectedTeam = index;
    let team = this.allTeams[this.selectedTeam];
    this.allUsers = [];
    this.getEmployeesByIds(team.users);
  }

  searchEmployee(ev) {
    if (ev.target.value.length > 0) {
      this.commonService.searchEmployees(ev.target.value).then(resp => {
        console.log("searchEmployee  ", resp);
        this.allUsers = resp;
      });
    } else {
      this.getEmployeesByIds(this.allTeams[this.selectedTeam]['users']);
    }
  }

  searchManagers(ev) {
    if (ev.target.value.length > 0) {
      this.commonService.searchEmployees(ev.target.value).then(resp => {
        this.managers = resp;
      });
    }
  }

  addEmployeeTeam(user) {
    console.log("user  ", user);
    let team = this.allTeams[this.selectedTeam];
    console.log("team  ", team);
    team.users.push(user.employeeId);
    this.commonService.updateTeam(team);
  }

  removeEmployeeTeam(user) {
    let team = this.allTeams[this.selectedTeam];
    let index = team.users.indexOf(user.employeeId);
    team.users.splice(index, 1);
    this.commonService.updateTeam(team);
  }

  checkInTeam(user) {
    let team = this.allTeams[this.selectedTeam];
    if (team && team.users && team.users.indexOf(user.employeeId) > -1) return false;else return true;
  }

  checkInTeamManagers(user) {
    let team = this.allTeams[this.selectedTeam];
    if (team && team.managers && team.managers.indexOf(user.employeeId) > -1) return false;else return true;
  }

  addTeam() {
    var _this = this;

    return (0,_Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this.alertController.create({
        header: 'Please enter team name',
        inputs: [{
          name: 'teamName',
          type: 'text',
          placeholder: 'Team name'
        }],
        buttons: [{
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Add',
          handler: alertData => {
            _this.allTeams.push({
              teamName: alertData.teamName
            });

            _this.commonService.createTeam({
              teamName: alertData.teamName
            }).then(resp => {
              _this.fetchAllTeams();

              console.log("create team ", resp);
            });
          }
        }]
      });
      yield alert.present();
    })();
  }

  addManager(team, user) {
    team.managers.push(user.employeeId);
    this.getTeamManagers(team);
    this.commonService.updateTeam(team);
  }

  removeTeamManager(team, manager) {
    console.log("removeTeamManager");
    let index = team.managers.indexOf(manager.employeeId);
    team.managersData.splice(index, 1);
    team.managers.splice(index, 1);
    this.commonService.updateTeam(team);
  } // removeTeam(team, index){
  //   console.log("team ",team)
  //   this.allTeams.splice(index,1);
  //   // this.commonService.deleteTeam(team).then(resp => {
  //   // })
  // }


  removeTeam(team, index) {
    var _this2 = this;

    return (0,_Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this2.alertController.create({
        header: 'Delete Team ' + team.teamName + '!',
        buttons: [{
          text: 'Cancel',
          role: 'cancel',
          handler: () => {}
        }, {
          text: 'OK',
          role: 'confirm',
          handler: () => {
            _this2.allTeams.splice(index, 1);

            _this2.commonService.deleteTeam(team).then(resp => {
              _this2.commonService.showToast("success", "Removed team " + team.teamName + "!");
            });
          }
        }]
      });
      yield alert.present();
      const {
        role
      } = yield alert.onDidDismiss();
    })();
  }

  addNewBoard() {
    var _this3 = this;

    return (0,_Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this3.alertController.create({
        header: 'Please enter board column name',
        inputs: [{
          name: 'input',
          type: 'text',
          placeholder: 'Column name'
        }],
        buttons: [{
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Add',
          handler: alertData => {
            let columnName = alertData.input; // console.log(columnName);
            // console.log("selected team ", this.allTeams[this.selectedTeam]);

            let newColumn = {
              teamId: _this3.allTeams[_this3.selectedTeam].teamId,
              columnName: columnName
            };
            console.log("newColumn ", newColumn);

            _this3.commonService.createTeamColumn(newColumn).then(resp => {
              _this3.fetchTeamColumns(_this3.allTeams[_this3.selectedTeam]);

              console.log("createTeamColumn ", resp);
            });
          }
        }]
      });
      yield alert.present();
    })();
  }

  deleteTeamColumn(column) {
    this.commonService.deleteTeamColumn(column.columnId).then(resp => {
      this.fetchTeamColumns(this.allTeams[this.selectedTeam]);
      console.log("createTeamColumn ", resp);
    });
  }

  submitBoard() {
    console.log("wwww", this.boardName);
  }

};

TeamsPage.ctorParameters = () => [{
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController
}, {
  type: _services_common_service__WEBPACK_IMPORTED_MODULE_4__.CommonService
}, {
  type: _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_7__.Overlay
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.MenuController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.Platform
}, {
  type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.Router
}];

TeamsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
  selector: 'app-teams',
  template: _teams_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_teams_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], TeamsPage);


function test() {
  console.log("wwww test");
}

/***/ }),

/***/ 7195:
/*!********************************************************!*\
  !*** ./src/app/pages/teams/teams.page.scss?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = "#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n\n.demo-chart {\n  width: 100%;\n  height: 300px;\n}\n\nion-grid {\n  --ion-grid-column-padding: 10px;\n  border-collapse: collapse;\n  border-style: hidden;\n  margin-top: 0px;\n  padding-top: 0px;\n  height: 100%;\n}\n\nion-grid ion-row {\n  margin: 5px 0px;\n}\n\nion-grid ion-col {\n  border-bottom: 0;\n  border-right: 0;\n}\n\n:host ::ng-deep .ngx-datatable .datatable-body .datatable-scroll {\n  display: inherit;\n}\n\n.selected {\n  background-color: #505ef9;\n  cursor: pointer;\n  color: #fff;\n  border-radius: 5px;\n}\n\n.notSelected {\n  cursor: pointer;\n  background-color: transparent;\n  color: #fff;\n  border-radius: 5px;\n}\n\n.notSelected ion-item {\n  color: #fff;\n}\n\nion-item {\n  --background: transparent;\n}\n\nion-select {\n  width: 100%;\n}\n\nion-segment-button {\n  --padding-end: 30px;\n  --padding-start: 30px;\n}\n\nion-grid ion-col {\n  border-bottom: 0;\n  border-right: 0;\n  font-size: 14px;\n  height: 100%;\n}\n\n.cross {\n  z-index: 9999999999;\n  background-color: red;\n  width: 100px;\n  height: 100px;\n  opacity: 0;\n}\n\n.tooltip {\n  position: relative;\n  display: inline-block;\n  border-bottom: 1px dotted black;\n  /* If you want dots under the hoverable text */\n}\n\n/* Tooltip text */\n\n.tooltip .tooltiptext {\n  visibility: hidden;\n  width: 120px;\n  background-color: black;\n  color: #fff;\n  text-align: center;\n  padding: 5px 0;\n  border-radius: 6px;\n  /* Position the tooltip text - see examples below! */\n  position: absolute;\n  z-index: 1;\n}\n\n/* Show the tooltip text when you mouse over the tooltip container */\n\n.tooltip:hover .tooltiptext {\n  visibility: visible;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRlYW1zLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxPQUFBO0VBQ0EsUUFBQTtFQUNBLFFBQUE7RUFDQSwyQkFBQTtBQUNGOztBQUVBO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsU0FBQTtBQUNGOztBQUVBO0VBQ0UscUJBQUE7QUFDRjs7QUFFQTtFQUNFLFdBQUE7RUFDQSxhQUFBO0FBQ0Y7O0FBRUE7RUFDRSwrQkFBQTtFQUNBLHlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0FBQ0Y7O0FBR0U7RUFDRSxlQUFBO0FBREo7O0FBSUU7RUFFRSxnQkFBQTtFQUNBLGVBQUE7QUFISjs7QUFlQTtFQUNFLGdCQUFBO0FBWkY7O0FBZUE7RUFDRSx5QkFBQTtFQUNBLGVBQUE7RUFHQSxXQUFBO0VBQ0Esa0JBQUE7QUFkRjs7QUFpQkE7RUFDRSxlQUFBO0VBQ0EsNkJBQUE7RUFDQSxXQUFBO0VBR0Esa0JBQUE7QUFoQkY7O0FBa0JFO0VBQ0UsV0FBQTtBQWhCSjs7QUFvQkE7RUFDRSx5QkFBQTtBQWpCRjs7QUFxQkE7RUFDRSxXQUFBO0FBbEJGOztBQXFCQTtFQUNFLG1CQUFBO0VBQ0EscUJBQUE7QUFsQkY7O0FBcUJBO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7QUFsQkY7O0FBcUJBO0VBQ0UsbUJBQUE7RUFDQSxxQkFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsVUFBQTtBQWxCRjs7QUEwQkE7RUFDRSxrQkFBQTtFQUNBLHFCQUFBO0VBQ0EsK0JBQUE7RUFDQSw4Q0FBQTtBQXZCRjs7QUEwQkEsaUJBQUE7O0FBQ0E7RUFDRSxrQkFBQTtFQUNBLFlBQUE7RUFDQSx1QkFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUVBLG9EQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0FBeEJGOztBQTJCQSxvRUFBQTs7QUFDQTtFQUNFLG1CQUFBO0FBeEJGIiwiZmlsZSI6InRlYW1zLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIiNjb250YWluZXIge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogMDtcbiAgcmlnaHQ6IDA7XG4gIHRvcDogNTAlO1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSk7XG59XG5cbiNjb250YWluZXIgc3Ryb25nIHtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBsaW5lLWhlaWdodDogMjZweDtcbn1cblxuI2NvbnRhaW5lciBwIHtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBsaW5lLWhlaWdodDogMjJweDtcbiAgY29sb3I6ICM4YzhjOGM7XG4gIG1hcmdpbjogMDtcbn1cblxuI2NvbnRhaW5lciBhIHtcbiAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xufVxuXG4uZGVtby1jaGFydCB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDMwMHB4O1xufVxuXG5pb24tZ3JpZCB7XG4gIC0taW9uLWdyaWQtY29sdW1uLXBhZGRpbmc6IDEwcHg7XG4gIGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7XG4gIGJvcmRlci1zdHlsZTogaGlkZGVuO1xuICBtYXJnaW4tdG9wOiAwcHg7XG4gIHBhZGRpbmctdG9wOiAwcHg7XG4gIGhlaWdodDogMTAwJTtcbiAgLy8gcGFkZGluZzogMTBweDtcbiAgLy8gYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcblxuICBpb24tcm93IHtcbiAgICBtYXJnaW46IDVweCAwcHg7XG4gIH1cblxuICBpb24tY29sIHtcbiAgICAvLyBib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xuICAgIGJvcmRlci1ib3R0b206IDA7XG4gICAgYm9yZGVyLXJpZ2h0OiAwO1xuICB9XG5cbiAgLy8gaW9uLWNvbDpsYXN0LWNoaWxkIHtcbiAgLy8gYm9yZGVyLXJpZ2h0OiAxcHggc29saWQgYmxhY2s7XG4gIC8vIH1cblxuICAvLyBpb24tcm93Omxhc3QtY2hpbGQge1xuICAvLyBib3JkZXItYm90dG9tOiAxcHggc29saWQgYmxhY2s7XG4gIC8vIH1cbn1cblxuOmhvc3QgOjpuZy1kZWVwIC5uZ3gtZGF0YXRhYmxlIC5kYXRhdGFibGUtYm9keSAuZGF0YXRhYmxlLXNjcm9sbCB7XG4gIGRpc3BsYXk6IGluaGVyaXQ7XG59XG5cbi5zZWxlY3RlZCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICM1MDVlZjk7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgLy8gYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNjY2M7XG4gIC8vIGJveC1zaGFkb3c6IDAgMXB4IDJweCAwIHJnYig2MCA2NCA2NyAvIDMwJSksIDAgMXB4IDNweCAxcHggcmdiKDYwIDY0IDY3IC8gMTUlKTtcbiAgY29sb3I6ICNmZmY7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbn1cblxuLm5vdFNlbGVjdGVkIHtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgY29sb3I6ICNmZmY7XG4gIC8vIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjY2NjO1xuICAvLyBib3gtc2hhZG93OiAwIDFweCAycHggMCByZ2IoNjAgNjQgNjcgLyAzMCUpLCAwIDFweCAzcHggMXB4IHJnYig2MCA2NCA2NyAvIDE1JSk7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcblxuICBpb24taXRlbSB7XG4gICAgY29sb3I6ICNmZmY7XG4gIH1cbn1cblxuaW9uLWl0ZW0ge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xufVxuXG5cbmlvbi1zZWxlY3Qge1xuICB3aWR0aDogMTAwJTtcbn1cblxuaW9uLXNlZ21lbnQtYnV0dG9uIHtcbiAgLS1wYWRkaW5nLWVuZDogMzBweDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAzMHB4O1xufVxuXG5pb24tZ3JpZCBpb24tY29sIHtcbiAgYm9yZGVyLWJvdHRvbTogMDtcbiAgYm9yZGVyLXJpZ2h0OiAwO1xuICBmb250LXNpemU6IDE0cHg7XG4gIGhlaWdodDogMTAwJTtcbn1cblxuLmNyb3NzIHtcbiAgei1pbmRleDogOTk5OTk5OTk5OTtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmVkO1xuICB3aWR0aDogMTAwcHg7XG4gIGhlaWdodDogMTAwcHg7XG4gIG9wYWNpdHk6IDA7XG59XG5cbi8vIC5jcm9zczpob3ZlciB7XG4vLyAgIHotaW5kZXg6IDk5OTk5OTk5OTk7XG4vLyAgIG9wYWNpdHk6IDAuNjtcbi8vIH1cblxuLnRvb2x0aXAge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgYm9yZGVyLWJvdHRvbTogMXB4IGRvdHRlZCBibGFjaztcbiAgLyogSWYgeW91IHdhbnQgZG90cyB1bmRlciB0aGUgaG92ZXJhYmxlIHRleHQgKi9cbn1cblxuLyogVG9vbHRpcCB0ZXh0ICovXG4udG9vbHRpcCAudG9vbHRpcHRleHQge1xuICB2aXNpYmlsaXR5OiBoaWRkZW47XG4gIHdpZHRoOiAxMjBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogYmxhY2s7XG4gIGNvbG9yOiAjZmZmO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBhZGRpbmc6IDVweCAwO1xuICBib3JkZXItcmFkaXVzOiA2cHg7XG5cbiAgLyogUG9zaXRpb24gdGhlIHRvb2x0aXAgdGV4dCAtIHNlZSBleGFtcGxlcyBiZWxvdyEgKi9cbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB6LWluZGV4OiAxO1xufVxuXG4vKiBTaG93IHRoZSB0b29sdGlwIHRleHQgd2hlbiB5b3UgbW91c2Ugb3ZlciB0aGUgdG9vbHRpcCBjb250YWluZXIgKi9cbi50b29sdGlwOmhvdmVyIC50b29sdGlwdGV4dCB7XG4gIHZpc2liaWxpdHk6IHZpc2libGU7XG59Il19 */";

/***/ }),

/***/ 4547:
/*!********************************************************!*\
  !*** ./src/app/pages/teams/teams.page.html?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar color=\"gray\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Teams & Boards</ion-title>\n  </ion-toolbar>\n\n</ion-header>\n\n<ion-content>\n  <ion-row style=\"height: 100%;\">\n    <ion-col>\n      <ion-row style=\"height: 100%;\">\n        <ion-col size=\"5\" style=\"border-right: 0.5px solid rgb(52 52 52)\">\n          <ion-row>\n            <ion-col size=\"12\">\n              <ion-item>\n                <ion-label style=\"color: #ccc;\">\n                  Teams\n                </ion-label>\n                <ion-button slot=\"end\" fill=\"clear\" (click)=\"addTeam()\">\n                  <ion-icon name=\"add\"></ion-icon>\n                </ion-button>\n              </ion-item>\n            </ion-col>\n          </ion-row>\n          <ion-row *ngFor=\"let team of allTeams; index as i\" style=\"margin: 0px 10px;\">\n            <ion-col size=\"12\" style=\"padding: 0px;\">\n              <ion-item [ngClass]=\"(i == selectedTeam) ? 'selected' : 'notSelected'\" lines=\"none\"\n                (click)=\"selectTeam(i)\">\n                <ion-label>\n                  {{team.teamName}}\n                </ion-label>\n                <ion-avatar cdkOverlayOrigin #trigger=\"cdkOverlayOrigin\"\n                  (mouseover)=\"delayMouseOverToggle(managersToggle,i,m)\"\n                  (mouseleave)=\"delayMouseOutToggle(managersToggle,i,m)\" id=\"hover-trigger\"\n                  *ngFor=\"let manager of team.managersData; index as m\" slot=\"end\" style=\"position: relative;\">\n\n                  <img style=\"position: absolute;z-index: -1;\"\n                    [src]=\"manager.image\">\n\n                  <!-- <img (click)=\"removeTeamManager(team, manager)\" class=\"cross\" managersToggle\n                    src=\"https://www.citypng.com/public/uploads/preview/png-red-round-close-x-icon-31631915146jpppmdzihs.png\"> -->\n                  <!-- <ion-popover [id]=\"i+'-'+m\" trigger=\"hover-trigger\" triggerAction=\"hover\">\n                    <ng-template>\n                      <ion-content class=\"ion-padding\">Hello World!</ion-content>\n                    </ng-template>\n                  </ion-popover> -->\n                  <ng-template cdkConnectedOverlay [cdkConnectedOverlayOrigin]=\"trigger\"\n                    [cdkConnectedOverlayOpen]=\"managersToggle[i][m]\"\n                    (overlayOutsideClick)=\"managersToggle[i][m] = false\">\n\n                    <div class=\"example-overlay\" (mouseover)=\"keepOn[i][m] = true\"\n                      (mouseleave)=\"closePopover(managersToggle,i,m)\">\n                      <ion-item lines=\"none\">\n                        <ion-label style=\"color: #ccc;\">\n                          <div>\n                            {{manager.firstName}} {{manager.lastName}}\n                          </div>\n                          <p>\n                            {{manager.officialEmail}}\n                          </p>\n                        </ion-label>\n                      </ion-item>\n                      <div\n                        style=\"background-color: #161b22;border-top: 1px solid #252628;padding: 10px 10px;\">\n                        <div style=\"cursor: pointer;border: 1px solid #e74c3c;border-radius: 5px;color: #e74c3c;font-size: 14px;padding: 5px;\" (click)=\"removeTeamManager(team, manager)\">\n                          Remove\n                        </div>\n                      </div>\n                    </div>\n                  </ng-template>\n\n                </ion-avatar>\n                <ion-avatar slot=\"end\" (click)=\"isOpen = !isOpen\" cdkOverlayOrigin #trigger=\"cdkOverlayOrigin\">\n                  <!-- <img src=\"http://simpleicon.com/wp-content/uploads/add-user.png\"> -->\n                  <img\n                    src=\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTjly4qKE7rp1WGq1KUbV2Q-zWCm2rmlsEUd5KSAEN5Q2odS0secr2eSOmKmeAZjnkMlnY&usqp=CAU\">\n                </ion-avatar>\n                  <ion-icon (click)=\"removeTeam(team, i)\" name=\"close-circle-outline\" color=\"danger\" slot=\"end\"></ion-icon>\n              </ion-item>\n\n              <ng-template *ngIf=\"i == selectedTeam\" cdkConnectedOverlay [cdkConnectedOverlayOrigin]=\"trigger\"\n                [cdkConnectedOverlayOpen]=\"isOpen\" (overlayOutsideClick)=\"isOpen = false\">\n                <div class=\"example-overlay\">\n                  <ion-item lines=\"none\">\n                    <ion-label style=\"color: #ccc;\">\n                      Managers\n                    </ion-label>\n                  </ion-item>\n                  <ion-toolbar color=\"gray\">\n                    <ion-searchbar placeholder=\"Search Managers\" debounce=\"500\" (ionChange)=\"searchManagers($event)\">\n                    </ion-searchbar>\n                  </ion-toolbar>\n                  <ion-row *ngFor=\"let user of managers; index as i\" [ngClass]=\"(i % 2 == 0) ? 'odd' : 'even'\" style=\"background: #252628;\n                      border-radius: 10px;margin: 10px;\">\n                    <ion-item lines=\"none\" style=\"width: 100%;cursor: pointer;\" (click)=\"isOpen = !isOpen\"\n                      (click)=\"addManager(team, user)\">\n                      <ion-avatar slot=\"start\">\n                        <img [src]=\"user.image\">\n                      </ion-avatar>\n                      <ion-label style=\"color: #fff;\">\n                        {{user.firstName}} {{user.lastName}}\n                      </ion-label>\n                      <!-- <ion-button *ngIf=\"checkInTeamManagers(user)\" slot=\"end\" fill=\"clear\" (click)=\"addEmployeeTeam(user)\">\n                              <ion-icon name=\"add\"></ion-icon>\n                            </ion-button> -->\n                    </ion-item>\n                  </ion-row>\n                </div>\n              </ng-template>\n\n            </ion-col>\n          </ion-row>\n        </ion-col>\n\n        <ion-col size=\"7\" style=\"position: absolute;right:0;padding: 0px 20px;\">\n\n          <ion-toolbar color=\"gray\">\n            <ion-segment [(ngModel)]=\"segment\">\n              <ion-segment-button value=\"teams\">\n                <ion-text>\n                  Teams\n                </ion-text>\n              </ion-segment-button>\n              <ion-segment-button value=\"boards\">\n                <ion-text>\n                  Boards\n                </ion-text>\n              </ion-segment-button>\n            </ion-segment>\n          </ion-toolbar>\n          <div *ngIf=\"segment=='teams'\">\n            <ion-row style=\"z-index: 999999999;background-color: transparent;color: #fff;margin: 0px;\">\n              <ion-col size=\"12\" style=\"background: #0d1116;\">\n                <ion-item lines=\"none\">\n                  <ion-label style=\"color: #ccc;\">\n                    Members\n                  </ion-label>\n                </ion-item>\n                <ion-toolbar color=\"gray\">\n                  <ion-searchbar placeholder=\"Search Employee\" debounce=\"1000\" (ionChange)=\"searchEmployee($event)\">\n                  </ion-searchbar>\n                </ion-toolbar>\n              </ion-col>\n            </ion-row>\n            <ion-row *ngFor=\"let user of allUsers; index as i\" [ngClass]=\"(i % 2 == 0) ? 'odd' : 'even'\" style=\"background: #252628;\n  border-radius: 10px;margin: 10px;\">\n              <ion-item lines=\"none\" style=\"width: 100%;\">\n                <ion-avatar slot=\"start\">\n                  <img\n                    [src]=\"user.image\">\n                </ion-avatar>\n                <ion-label style=\"color: #fff;\">\n                  {{user.firstName}} {{user.lastName}}\n                </ion-label>\n                <ion-button *ngIf=\"checkInTeam(user)\" slot=\"end\" fill=\"clear\" (click)=\"addEmployeeTeam(user)\">\n                  <ion-icon color=\"success\" name=\"add\"></ion-icon>\n                </ion-button>\n                <ion-button *ngIf=\"!checkInTeam(user)\" slot=\"end\" fill=\"clear\" (click)=\"removeEmployeeTeam(user)\">\n                  <ion-icon color=\"danger\" name=\"close\"></ion-icon>\n                </ion-button>\n              </ion-item>\n            </ion-row>\n          </div>\n          <div *ngIf=\"segment=='boards'\">\n            <ion-row style=\"z-index: 999999999;background-color: transparent;color: #fff;margin: 0px;\">\n              <ion-col size=\"12\">\n                <ion-item lines=\"none\">\n                  <ion-label style=\"color: #ccc;\">\n                    Team Board Columns\n                  </ion-label>\n                  <!-- <ion-button slot=\"end\" fill=\"clear\" (click)=\"addTeam()\">\n                        <ion-icon name=\"add\"></ion-icon>\n                      </ion-button> -->\n                </ion-item>\n              </ion-col>\n            </ion-row>\n\n            <ion-col size=\"12\" style=\"position: absolute;right:0;padding: 0px 20px;\">\n              <ion-row *ngFor=\"let column of allTeams[selectedTeam].teamBoardColumns; index as i\"\n                [ngClass]=\"(i % 2 == 0) ? 'odd' : 'even'\" style=\"background: #252628;\n                  border-radius: 10px;margin: 10px;\">\n                <ion-item lines=\"none\" style=\"width: 100%;\">\n                  <ion-label style=\"color: #fff;\">\n                    {{column.columnName}}\n                  </ion-label>\n                  <ion-button slot=\"end\" fill=\"clear\" (click)=\"deleteTeamColumn(column)\">\n                    <ion-icon color=\"danger\" name=\"trash\"></ion-icon>\n                  </ion-button>\n                </ion-item>\n              </ion-row>\n              <ion-row style=\"border-radius: 10px;margin: 10px;border: 1px solid #161b22;cursor: pointer;\"\n                (click)=\"addNewBoard()\">\n                <ion-item lines=\"none\" style=\"width: 100%;\">\n                  <ion-icon slot=\"start\" color=\"light\" name=\"add\"></ion-icon>\n                  <ion-label style=\"color: #fff;\">\n                    Add new column\n                  </ion-label>\n                </ion-item>\n              </ion-row>\n            </ion-col>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-col>\n  </ion-row>\n  <!-- <ion-row>\n    <ion-col *ngIf=\"segment=='boards'\">\n      <ion-toolbar color=\"gray\">\n        <ion-buttons slot=\"end\" style=\"color: #fff;cursor: pointer;\">\n          <ion-icon name=\"add\"></ion-icon><span style=\"font-size: 14px;\" (click)=\"addBoard()\">Add Boards</span>\n        </ion-buttons>\n        </ion-toolbar>\n        <ion-row\n          style=\"position: sticky;top: 0px;z-index: 999999999;background-color: #000;color: #fff;margin: 0px;\">\n          <ion-col style=\"line-height: 28px;\" size=\"12\">Board Name</ion-col>\n        </ion-row>\n        <ion-row style=\"background-color: #252628;color: #fff;border-radius: 5px;\">\n          <ion-col>Development Board</ion-col>\n        </ion-row>\n    </ion-col>\n  </ion-row> -->\n\n\n\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_teams_teams_module_ts.js.map