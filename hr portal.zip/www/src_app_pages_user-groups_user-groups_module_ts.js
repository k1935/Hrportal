"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_user-groups_user-groups_module_ts"],{

/***/ 4959:
/*!*****************************************************************!*\
  !*** ./src/app/pages/user-groups/user-groups-routing.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserGroupsPageRoutingModule": () => (/* binding */ UserGroupsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _user_groups_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user-groups.page */ 1147);




const routes = [
    {
        path: '',
        component: _user_groups_page__WEBPACK_IMPORTED_MODULE_0__.UserGroupsPage
    }
];
let UserGroupsPageRoutingModule = class UserGroupsPageRoutingModule {
};
UserGroupsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], UserGroupsPageRoutingModule);



/***/ }),

/***/ 8183:
/*!*********************************************************!*\
  !*** ./src/app/pages/user-groups/user-groups.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserGroupsPageModule": () => (/* binding */ UserGroupsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/cdk/scrolling */ 6328);
/* harmony import */ var _user_groups_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user-groups-routing.module */ 4959);
/* harmony import */ var _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/cdk/overlay */ 5895);
/* harmony import */ var _user_groups_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./user-groups.page */ 1147);









let UserGroupsPageModule = class UserGroupsPageModule {
};
UserGroupsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_5__.OverlayModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_7__.ScrollingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _user_groups_routing_module__WEBPACK_IMPORTED_MODULE_0__.UserGroupsPageRoutingModule
        ],
        declarations: [_user_groups_page__WEBPACK_IMPORTED_MODULE_1__.UserGroupsPage]
    })
], UserGroupsPageModule);



/***/ }),

/***/ 1147:
/*!*******************************************************!*\
  !*** ./src/app/pages/user-groups/user-groups.page.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserGroupsPage": () => (/* binding */ UserGroupsPage)
/* harmony export */ });
/* harmony import */ var _Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _user_groups_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./user-groups.page.html?ngResource */ 3441);
/* harmony import */ var _user_groups_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./user-groups.page.scss?ngResource */ 6392);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);
/* harmony import */ var _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/cdk/overlay */ 5895);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/common.service */ 5620);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 124);











let UserGroupsPage = class UserGroupsPage {
  constructor(fb, alertController, commonService, overlay, menuController, // private loadingService: LoadingService,
  platform, authService, // private userService: UserService,
  // private helperService: HelperService,
  // private authService: AuthService,
  router) {
    this.fb = fb;
    this.alertController = alertController;
    this.commonService = commonService;
    this.overlay = overlay;
    this.menuController = menuController;
    this.platform = platform;
    this.authService = authService;
    this.router = router;
    this.working = {
      monday: false,
      tuesday: false,
      wednesday: false,
      thursday: false,
      friday: false,
      saturday: false,
      sunday: false
    };
    this.permissions = {
      // ViewAllDSR: false,
      CreateProject: false
    };
    this.permissionsKeys = [];
    this.allUsers = [];
    this.allTeams = [];
    this.allUserGroups = [];
    this.managers = [];
    this.boardColumns = [];
    this.selectedGroup = 0;
    this.moduleKeys = [];
    this.segment = "modules";
    this.modules = {
      Dashboard: false,
      EmployeeList: false,
      Attendance: false,
      Tasks: false,
      ViewAllDSR: false,
      // MinutesOfMeeting: false,
      Projects: false,
      Teams: false,
      UserGroups: false,
      Leaves: false,
      Expenses: false
    };
  }

  ngOnInit() {
    this.authService.userLogin.subscribe(resp => {
      this.permissionsKeys = Object.keys(this.permissions);
      this.moduleKeys = Object.keys(this.modules);
      this.fetchAllUserGroups();
    });
  }

  fetchAllUserGroups() {
    this.commonService.fetchAllUserGroups().then(resp => {
      this.allUserGroups = resp; // this.getEmployeesByIds(this.allTeams[this.selectedGroup]['users']);

      this.allUserGroups.forEach(group => {
        if (group && group.modules && Object.keys(group.modules).length == 0) group.modules = Object.assign(this.modules);
        if (group && group.permissions && Object.keys(group.permissions).length == 0) group.permissions = Object.assign(this.permissions);
      });
    });
  }

  addUserGroup() {
    var _this = this;

    return (0,_Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this.alertController.create({
        header: 'Please enter user group name',
        inputs: [{
          name: 'groupName',
          type: 'text',
          placeholder: 'Team name'
        }],
        buttons: [{
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Add',
          handler: alertData => {
            let paramsData = {
              groupName: alertData.groupName
            };

            _this.commonService.createUserGroup(paramsData).then(resp => {
              _this.fetchAllUserGroups();

              console.log("create team ", resp);
            });
          }
        }]
      });
      yield alert.present();
    })();
  }

  selectGroup(i) {
    console.log("selectGroup  ", i);
    this.selectedGroup = i;
  }

  getModuleModel() {}

  updateModules() {
    // console.log("updateUserGroup ", this.allUserGroups[this.selectedGroup])
    this.commonService.updateUserGroup(this.allUserGroups[this.selectedGroup]).then(resp => {
      this.fetchAllUserGroups();
      console.log("create team ", resp);
      this.commonService.showToast('success', 'User Group Updated!');
    });
  }

  removeUserGroup(group, index) {
    var _this2 = this;

    return (0,_Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this2.alertController.create({
        header: 'Delete User Group ' + group.groupName + '!',
        buttons: [{
          text: 'Cancel',
          role: 'cancel',
          handler: () => {}
        }, {
          text: 'OK',
          role: 'confirm',
          handler: () => {
            _this2.allUserGroups.splice(index, 1);

            _this2.commonService.deleteUserGroup(group).then(resp => {
              _this2.commonService.showToast("success", "Removed group " + group.groupName + "!");
            });
          }
        }]
      });
      yield alert.present();
      const {
        role
      } = yield alert.onDidDismiss();
    })();
  }

  updatePermissions() {
    // console.log("updateUserGroup ", this.allUserGroups[this.selectedGroup])
    this.commonService.updateUserGroup(this.allUserGroups[this.selectedGroup]).then(resp => {
      this.fetchAllUserGroups();
      console.log("create team ", resp);
    });
  }

};

UserGroupsPage.ctorParameters = () => [{
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController
}, {
  type: _services_common_service__WEBPACK_IMPORTED_MODULE_4__.CommonService
}, {
  type: _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_7__.Overlay
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.MenuController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.Platform
}, {
  type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.Router
}];

UserGroupsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
  selector: 'app-user-groups',
  template: _user_groups_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_user_groups_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], UserGroupsPage);


/***/ }),

/***/ 6392:
/*!********************************************************************!*\
  !*** ./src/app/pages/user-groups/user-groups.page.scss?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = "#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n\n.demo-chart {\n  width: 100%;\n  height: 300px;\n}\n\nion-grid {\n  --ion-grid-column-padding: 10px;\n  border-collapse: collapse;\n  border-style: hidden;\n  margin-top: 0px;\n  padding-top: 0px;\n  height: 100%;\n}\n\nion-grid ion-row {\n  margin: 5px 0px;\n}\n\nion-grid ion-col {\n  border-bottom: 0;\n  border-right: 0;\n}\n\n:host ::ng-deep .ngx-datatable .datatable-body .datatable-scroll {\n  display: inherit;\n}\n\n.selected {\n  background-color: #505ef9;\n  cursor: pointer;\n  color: #fff;\n  border-radius: 5px;\n}\n\n.notSelected {\n  cursor: pointer;\n  background-color: transparent;\n  color: #fff;\n  border-radius: 5px;\n}\n\n.notSelected ion-item {\n  color: #fff;\n}\n\nion-item {\n  --background: transparent;\n}\n\nion-select {\n  width: 100%;\n}\n\nion-segment-button {\n  --padding-end: 30px;\n  --padding-start: 30px;\n}\n\nion-grid ion-col {\n  border-bottom: 0;\n  border-right: 0;\n  font-size: 14px;\n  height: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZXItZ3JvdXBzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNJLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxPQUFBO0VBQ0EsUUFBQTtFQUNBLFFBQUE7RUFDQSwyQkFBQTtBQUFKOztBQUdFO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0FBQUo7O0FBR0U7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsU0FBQTtBQUFKOztBQUdFO0VBQ0UscUJBQUE7QUFBSjs7QUFHRTtFQUNFLFdBQUE7RUFDQSxhQUFBO0FBQUo7O0FBR0U7RUFDRSwrQkFBQTtFQUNBLHlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0FBQUo7O0FBSUk7RUFDRSxlQUFBO0FBRk47O0FBS0k7RUFFRSxnQkFBQTtFQUNBLGVBQUE7QUFKTjs7QUFnQkU7RUFDRSxnQkFBQTtBQWJKOztBQWdCRTtFQUNFLHlCQUFBO0VBQ0EsZUFBQTtFQUdBLFdBQUE7RUFDQSxrQkFBQTtBQWZKOztBQWtCRTtFQUNFLGVBQUE7RUFDQSw2QkFBQTtFQUNBLFdBQUE7RUFHQSxrQkFBQTtBQWpCSjs7QUFtQkk7RUFDRSxXQUFBO0FBakJOOztBQXFCRTtFQUNFLHlCQUFBO0FBbEJKOztBQXNCRTtFQUNFLFdBQUE7QUFuQko7O0FBc0JFO0VBQ0UsbUJBQUE7RUFDQSxxQkFBQTtBQW5CSjs7QUFzQkU7RUFDRSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtBQW5CSiIsImZpbGUiOiJ1c2VyLWdyb3Vwcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcbiNjb250YWluZXIge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgbGVmdDogMDtcbiAgICByaWdodDogMDtcbiAgICB0b3A6IDUwJTtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSk7XG4gIH1cbiAgXG4gICNjb250YWluZXIgc3Ryb25nIHtcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgbGluZS1oZWlnaHQ6IDI2cHg7XG4gIH1cbiAgXG4gICNjb250YWluZXIgcCB7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIGxpbmUtaGVpZ2h0OiAyMnB4O1xuICAgIGNvbG9yOiAjOGM4YzhjO1xuICAgIG1hcmdpbjogMDtcbiAgfVxuICBcbiAgI2NvbnRhaW5lciBhIHtcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG4gIH1cbiAgXG4gIC5kZW1vLWNoYXJ0IHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDMwMHB4O1xuICB9XG4gIFxuICBpb24tZ3JpZCB7XG4gICAgLS1pb24tZ3JpZC1jb2x1bW4tcGFkZGluZzogMTBweDtcbiAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xuICAgIGJvcmRlci1zdHlsZTogaGlkZGVuO1xuICAgIG1hcmdpbi10b3A6IDBweDtcbiAgICBwYWRkaW5nLXRvcDogMHB4O1xuICAgIGhlaWdodDogMTAwJTtcbiAgICAvLyBwYWRkaW5nOiAxMHB4O1xuICAgIC8vIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gIFxuICAgIGlvbi1yb3cge1xuICAgICAgbWFyZ2luOiA1cHggMHB4O1xuICAgIH1cbiAgXG4gICAgaW9uLWNvbCB7XG4gICAgICAvLyBib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xuICAgICAgYm9yZGVyLWJvdHRvbTogMDtcbiAgICAgIGJvcmRlci1yaWdodDogMDtcbiAgICB9XG4gIFxuICAgIC8vIGlvbi1jb2w6bGFzdC1jaGlsZCB7XG4gICAgICAvLyBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCBibGFjaztcbiAgICAvLyB9XG4gIFxuICAgIC8vIGlvbi1yb3c6bGFzdC1jaGlsZCB7XG4gICAgICAvLyBib3JkZXItYm90dG9tOiAxcHggc29saWQgYmxhY2s7XG4gICAgLy8gfVxuICB9XG4gIFxuICA6aG9zdCA6Om5nLWRlZXAgLm5neC1kYXRhdGFibGUgLmRhdGF0YWJsZS1ib2R5IC5kYXRhdGFibGUtc2Nyb2xsIHtcbiAgICBkaXNwbGF5OiBpbmhlcml0O1xuICB9XG4gIFxuICAuc2VsZWN0ZWQge1xuICAgIGJhY2tncm91bmQtY29sb3I6ICM1MDVlZjk7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIC8vIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjY2NjO1xuICAgIC8vIGJveC1zaGFkb3c6IDAgMXB4IDJweCAwIHJnYig2MCA2NCA2NyAvIDMwJSksIDAgMXB4IDNweCAxcHggcmdiKDYwIDY0IDY3IC8gMTUlKTtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIH1cbiAgXG4gIC5ub3RTZWxlY3RlZCB7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xuICAgIGNvbG9yOiAjZmZmO1xuICAgIC8vIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjY2NjO1xuICAgIC8vIGJveC1zaGFkb3c6IDAgMXB4IDJweCAwIHJnYig2MCA2NCA2NyAvIDMwJSksIDAgMXB4IDNweCAxcHggcmdiKDYwIDY0IDY3IC8gMTUlKTtcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIFxuICAgIGlvbi1pdGVtIHtcbiAgICAgIGNvbG9yOiAjZmZmO1xuICAgIH1cbiAgfVxuICBcbiAgaW9uLWl0ZW0ge1xuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIH1cbiAgXG4gIFxuICBpb24tc2VsZWN0IHtcbiAgICB3aWR0aDogMTAwJTtcbiAgfVxuICBcbiAgaW9uLXNlZ21lbnQtYnV0dG9uIHtcbiAgICAtLXBhZGRpbmctZW5kOiAzMHB4O1xuICAgIC0tcGFkZGluZy1zdGFydDogMzBweDtcbiAgfVxuICBcbiAgaW9uLWdyaWQgaW9uLWNvbCB7XG4gICAgYm9yZGVyLWJvdHRvbTogMDtcbiAgICBib3JkZXItcmlnaHQ6IDA7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICAgIGhlaWdodDogMTAwJTtcbiAgfSJdfQ== */";

/***/ }),

/***/ 3441:
/*!********************************************************************!*\
  !*** ./src/app/pages/user-groups/user-groups.page.html?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar color=\"gray\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>User Groups</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-row style=\"height: 100%;\">\n    <ion-col>\n        <ion-row style=\"height: 100%;\">\n          <ion-col size=\"5\" style=\"border-right: 0.5px solid rgb(52 52 52);\" >\n              <ion-row>\n                <ion-col size=\"12\">\n                  <ion-item>\n                    <ion-label style=\"color: #ccc;\">\n                      User Group Name\n                    </ion-label>\n                    <ion-button slot=\"end\" fill=\"clear\" (click)=\"addUserGroup()\">\n                      <ion-icon name=\"add\"></ion-icon>\n                    </ion-button>\n                  </ion-item>\n                </ion-col>\n              </ion-row>\n              <ion-row *ngFor=\"let group of allUserGroups; index as i\"  style=\"margin: 0px 10px;\">\n                <ion-col size=\"12\">\n                  <ion-item [ngClass]=\"(i == selectedGroup) ? 'selected' : 'notSelected'\"\n                   lines=\"none\" (click)=\"selectGroup(i)\">\n                    <ion-label>\n                      {{group.groupName}}\n                    </ion-label>\n                    <ion-icon (click)=\"removeUserGroup(group, i)\" name=\"close-circle-outline\" color=\"danger\" slot=\"end\"></ion-icon>\n                  </ion-item>\n                  \n<!-- \n                  <div style=\"margin:200px\">\n                    <button\n                      (click)=\"isOpen = !isOpen\"\n                      cdkOverlayOrigin\n                      #trigger=\"cdkOverlayOrigin\"\n                    >\n                      Open/close overlay\n                    </button>\n                  </div>\n                  \n                  <div>This content will be under the overlay</div> -->\n                </ion-col>\n              </ion-row>\n          </ion-col>\n\n          <ion-col size=\"7\" style=\"position: absolute;right:0;padding: 0px 20px;\">\n            <ion-toolbar color=\"gray\">\n              <ion-segment [(ngModel)]=\"segment\">\n                <ion-segment-button value=\"modules\">\n                  <ion-text>\n                    Modules\n                  </ion-text>\n                </ion-segment-button>\n                <ion-segment-button disabled value=\"permissions\">\n                  <ion-text>\n                    Permissions\n                  </ion-text>\n                </ion-segment-button>\n              </ion-segment>\n            </ion-toolbar>\n            <div *ngIf=\"segment=='modules'\">\n              <ion-row>\n                <ion-col size=\"12\">\n                  <ion-item lines=\"none\">\n                    <ion-label style=\"color: #ccc;\">\n                      Modules\n                    </ion-label>\n                    <ion-button slot=\"end\" fill=\"clear\" color=\"success\" (click)=\"updateModules()\">\n                      Update\n                    </ion-button>\n                  </ion-item>\n                </ion-col>\n              </ion-row>\n              <ion-row>\n                <!-- allUserGroups[selectedGroup].permissions -->\n                <ion-list *ngIf=\"allUserGroups.length > 0\" style=\"width: 100%;\">\n                  <ion-item *ngFor=\"let module of moduleKeys\" style=\"background-color:#161b22;margin: 5px;width: 100%;\" lines=\"none\">\n                    <ion-checkbox slot=\"start\" color=\"light\" [(ngModel)]=\"allUserGroups[selectedGroup].modules[module]\"></ion-checkbox>\n                    <ion-label style=\"color: #fff;\">{{module}}</ion-label>\n                  </ion-item>\n                </ion-list>\n              </ion-row>\n            </div>\n            <div *ngIf=\"segment=='permissions'\">\n              <ion-row>\n                <ion-col size=\"12\">\n                  <ion-item lines=\"none\">\n                    <ion-label style=\"color: #ccc;\">\n                      Permissions\n                    </ion-label>\n                    <ion-button slot=\"end\" fill=\"clear\" color=\"success\" (click)=\"updatePermissions()\">\n                      Update\n                    </ion-button>\n                  </ion-item>\n                </ion-col>\n              </ion-row>\n              <ion-row>\n                <!-- allUserGroups[selectedGroup].permissions -->\n                <ion-list *ngIf=\"allUserGroups.length > 0\" style=\"width: 100%;\">\n                  <ion-item *ngFor=\"let permission of permissionsKeys\" style=\"background-color:#161b22;margin: 5px;width: 100%;\" lines=\"none\">\n                    <ion-checkbox slot=\"start\" color=\"light\" [(ngModel)]=\"allUserGroups[selectedGroup].permissions[permission]\"></ion-checkbox>\n                    <ion-label style=\"color: #fff;\">{{permission}}</ion-label>\n                  </ion-item>\n                </ion-list>\n              </ion-row>\n            </div>\n          </ion-col>\n\n        </ion-row>\n    </ion-col>\n  </ion-row>\n\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_user-groups_user-groups_module_ts.js.map