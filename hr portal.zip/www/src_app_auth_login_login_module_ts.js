"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_auth_login_login_module_ts"],{

/***/ 4272:
/*!****************************************************!*\
  !*** ./src/app/auth/login/login-routing.module.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageRoutingModule": () => (/* binding */ LoginPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login.page */ 1506);




const routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_0__.LoginPage
    }
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], LoginPageRoutingModule);



/***/ }),

/***/ 8990:
/*!********************************************!*\
  !*** ./src/app/auth/login/login.module.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageModule": () => (/* binding */ LoginPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login-routing.module */ 4272);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page */ 1506);







let LoginPageModule = class LoginPageModule {
};
LoginPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _login_routing_module__WEBPACK_IMPORTED_MODULE_0__.LoginPageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule
        ],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_1__.LoginPage]
    })
], LoginPageModule);



/***/ }),

/***/ 1506:
/*!******************************************!*\
  !*** ./src/app/auth/login/login.page.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPage": () => (/* binding */ LoginPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _login_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login.page.html?ngResource */ 5286);
/* harmony import */ var _login_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page.scss?ngResource */ 9633);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/common.service */ 5620);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 124);



// import { AuthService } from 'src/app/services/auth.service';





// import { HelperService } from '../../services/helper.service';

let LoginPage = class LoginPage {
    constructor(fb, commonService, navController, menuController, 
    // private loadingService: LoadingService,
    platform, authService, 
    // private userService: UserService,
    // private helperService: HelperService,
    // private authService: AuthService,
    router) {
        this.fb = fb;
        this.commonService = commonService;
        this.navController = navController;
        this.menuController = menuController;
        this.platform = platform;
        this.authService = authService;
        this.router = router;
    }
    ngOnInit() {
        this.form = this.fb.group({
            email: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            password: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required]
        });
    }
    ionViewWillEnter() {
        this.menuController.enable(false);
    }
    ionViewWillLeave() {
        this.menuController.enable(true);
    }
    login() {
        let that = this;
        this.commonService.presentLoading();
        this.commonService.login(this.form.value).then((resp) => {
            console.log(resp);
            if (resp && resp.userId) {
                localStorage.setItem('userId', JSON.stringify(resp.userId));
                this.authService.userLogin.next(resp);
                this.commonService.showToast("success", "Login Successful!");
                setTimeout(() => {
                    that.commonService.loadingDismiss();
                }, 500);
            }
            else {
                this.commonService.showToast("error", "Invalid Username or Password!");
            }
        }, error => {
            this.commonService.loadingDismiss();
            this.commonService.showToast("error", "Invalid Username or Password!");
            console.log(error);
        });
    }
};
LoginPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder },
    { type: _services_common_service__WEBPACK_IMPORTED_MODULE_3__.CommonService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.MenuController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.Platform },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router }
];
LoginPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-login',
        template: _login_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_login_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], LoginPage);



/***/ }),

/***/ 9633:
/*!*******************************************************!*\
  !*** ./src/app/auth/login/login.page.scss?ngResource ***!
  \*******************************************************/
/***/ ((module) => {

module.exports = "ion-content {\n  --ion-background-color: #222;\n}\n\n.box {\n  height: 400px;\n  width: 98%;\n  border-radius: 10px;\n  background-color: rgba(0, 0, 0, 0.3294117647);\n  color: #fff;\n}\n\nion-footer {\n  --ion-background-color: #f6f6f6;\n}\n\nion-toolbar {\n  --background: #f6f6f6;\n  --color: #222;\n}\n\nion-button {\n  --color: #f6f6f6;\n}\n\nion-item {\n  --background: transparent;\n  box-shadow: 1px 1px 4px 0px rgba(0, 0, 0, 0.5);\n}\n\nion-row {\n  padding: 0px !important;\n}\n\n.base {\n  background: white;\n  margin: 0px auto;\n  display: flex;\n  flex-direction: row;\n  justify-content: center;\n  overflow: hidden;\n}\n\n.terms {\n  text-align: left;\n  font-size: 11px;\n  padding: 10px;\n}\n\n.register-button {\n  background: #2261a1;\n  color: white;\n  padding: 5px;\n  width: 100%;\n  text-align: center;\n  margin: 5px;\n  cursor: pointer;\n}\n\n.login-button {\n  color: #222;\n  padding: 5px;\n  width: 100%;\n  text-align: center;\n  margin: 5px;\n  cursor: pointer;\n}\n\n.signinButton {\n  background: #2ecc71;\n  border-radius: 10px;\n  text-align: center;\n  line-height: 2.5rem;\n  width: 100%;\n  margin: 0 auto;\n  margin-top: 20px;\n  font-weight: bold;\n  color: #fff;\n  cursor: pointer;\n}\n\n.signupButton {\n  border-radius: 10px;\n  text-align: center;\n  line-height: 2.5rem;\n  width: 100%;\n  margin: 0 auto;\n  margin-top: 20px;\n  font-weight: bold;\n  color: #fff;\n  cursor: pointer;\n}\n\n.forgotButton {\n  background: transparent;\n  text-align: center;\n  margin: 0 auto;\n  margin-top: 10px;\n  margin-bottom: 10px;\n  font-weight: bold;\n  color: #2980b9;\n  cursor: pointer;\n}\n\nion-item {\n  box-shadow: none !important;\n}\n\n@media screen and (max-width: 480px) {\n  .box {\n    border-radius: 20px;\n  }\n  .container {\n    margin: 15px !important;\n    height: calc(100% - 30px) !important;\n  }\n}\n\nion-input {\n  color: #fff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvZ2luLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLDRCQUFBO0FBQ0o7O0FBRUE7RUFDSSxhQUFBO0VBQ0EsVUFBQTtFQUVBLG1CQUFBO0VBQ0EsNkNBQUE7RUFDQSxXQUFBO0FBQUo7O0FBR0E7RUFDSSwrQkFBQTtBQUFKOztBQUdBO0VBQ0kscUJBQUE7RUFDQSxhQUFBO0FBQUo7O0FBR0E7RUFDSSxnQkFBQTtBQUFKOztBQUdBO0VBQ0kseUJBQUE7RUFDQSw4Q0FBQTtBQUFKOztBQVlBO0VBQ0ksdUJBQUE7QUFUSjs7QUFZQTtFQUNJLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLGdCQUFBO0FBVEo7O0FBWUE7RUFDSSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxhQUFBO0FBVEo7O0FBWUE7RUFDSSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7QUFUSjs7QUFZQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7QUFUSjs7QUFZQTtFQUNJLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7QUFUSjs7QUFZQTtFQUVJLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0FBVko7O0FBYUE7RUFDSSx1QkFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0FBVko7O0FBYUE7RUFDSSwyQkFBQTtBQVZKOztBQWFBO0VBQ0k7SUFDSSxtQkFBQTtFQVZOO0VBYUU7SUFDSSx1QkFBQTtJQUNBLG9DQUFBO0VBWE47QUFDRjs7QUFjQTtFQUNJLFdBQUE7QUFaSiIsImZpbGUiOiJsb2dpbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCB7XG4gICAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogIzIyMjtcbn1cblxuLmJveCB7XG4gICAgaGVpZ2h0OiA0MDBweDtcbiAgICB3aWR0aDogOTglO1xuICAgIC8vIGJvcmRlcjogMXB4IHNvbGlkIHJnYigxMjIsIDEyMCwgMTIwKTtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICMwMDAwMDA1NDtcbiAgICBjb2xvcjogI2ZmZjtcbn1cblxuaW9uLWZvb3RlciB7XG4gICAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogI2Y2ZjZmNjtcbn1cblxuaW9uLXRvb2xiYXIge1xuICAgIC0tYmFja2dyb3VuZDogI2Y2ZjZmNjtcbiAgICAtLWNvbG9yOiAjMjIyO1xufVxuXG5pb24tYnV0dG9uIHtcbiAgICAtLWNvbG9yOiAjZjZmNmY2O1xufVxuXG5pb24taXRlbSB7XG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICBib3gtc2hhZG93OiAxcHggMXB4IDRweCAwcHggcmdiYSgwLCAwLCAwLCAwLjUpO1xufVxuXG5cblxuXG4vLyBpb24tY2FyZCB7XG4vLyAgIC0tYmFja2dyb3VuZDogI2ZmZjtcbi8vICAgbWFyZ2luOiAxNXB4IDIwcHg7XG5cbi8vIH1cblxuaW9uLXJvdyB7XG4gICAgcGFkZGluZzogMHB4ICFpbXBvcnRhbnQ7XG59XG5cbi5iYXNlIHtcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgICBtYXJnaW46IDBweCBhdXRvO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4udGVybXMge1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgZm9udC1zaXplOiAxMXB4O1xuICAgIHBhZGRpbmc6IDEwcHg7XG59XG5cbi5yZWdpc3Rlci1idXR0b24ge1xuICAgIGJhY2tncm91bmQ6ICMyMjYxYTE7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIHBhZGRpbmc6IDVweDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgbWFyZ2luOiA1cHg7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xufVxuXG4ubG9naW4tYnV0dG9uIHtcbiAgICBjb2xvcjogIzIyMjtcbiAgICBwYWRkaW5nOiA1cHg7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIG1hcmdpbjogNXB4O1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbn1cblxuLnNpZ25pbkJ1dHRvbiB7XG4gICAgYmFja2dyb3VuZDogIzJlY2M3MTtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBsaW5lLWhlaWdodDogMi41cmVtO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIG1hcmdpbjogMCBhdXRvO1xuICAgIG1hcmdpbi10b3A6IDIwcHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xufVxuXG4uc2lnbnVwQnV0dG9uIHtcbiAgICAvLyBiYWNrZ3JvdW5kOiAjMjk4MGI5O1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGxpbmUtaGVpZ2h0OiAyLjVyZW07XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgbWFyZ2luOiAwIGF1dG87XG4gICAgbWFyZ2luLXRvcDogMjBweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG59XG5cbi5mb3Jnb3RCdXR0b24ge1xuICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBtYXJnaW46IDAgYXV0bztcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgY29sb3I6ICMyOTgwYjk7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xufVxuXG5pb24taXRlbSB7XG4gICAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xufVxuXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA0ODBweCkge1xuICAgIC5ib3gge1xuICAgICAgICBib3JkZXItcmFkaXVzOiAyMHB4O1xuICAgIH1cblxuICAgIC5jb250YWluZXIge1xuICAgICAgICBtYXJnaW46IDE1cHggIWltcG9ydGFudDtcbiAgICAgICAgaGVpZ2h0OiBjYWxjKDEwMCUgLSAzMHB4KSAhaW1wb3J0YW50O1xuICAgIH1cbn1cblxuaW9uLWlucHV0IHtcbiAgICBjb2xvcjogI2ZmZjtcbn0iXX0= */";

/***/ }),

/***/ 5286:
/*!*******************************************************!*\
  !*** ./src/app/auth/login/login.page.html?ngResource ***!
  \*******************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n\n  <ion-row style=\"height: 100%;\">\n    <!-- <ion-row style=\"height: 100%;background: rgb(26, 26, 26);\"> -->\n      <ion-col sizeLg=\"4.5\" style=\"height: 100%;background-image: url(https://images.pexels.com/photos/3183197/pexels-photo-3183197.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2);background-size: cover;background-position: center;\">\n        \n      </ion-col>\n      <ion-col style=\"height: 100%;background: rgb(17, 17, 17);;border-radius: 0px;border: 1px solid #222;margin: 0px;\" sizeLg=\"3\" sizeMd=\"3\" sizeSm=\"12\" sizeXs=\"12\" class=\"box\">\n        <div style=\"text-align: center;padding-top: 30%;padding-bottom: 15%\">\n          <img src=\"assets\\icon\\mckinsol-logo.png\" style=\"width:100px;\">\n        </div>\n        <div>\n          <form [formGroup]=\"form\">\n            <ion-list style=\"background: transparent;padding:10px 20px;\">\n              <ion-label style=\"color: #fff;\">Email address</ion-label>\n              <ion-item lines=\"none\" style=\"border: 1px solid rgb(122, 120, 120);margin-bottom: 10px;margin-top: 5px;border-radius: 10px;\">\n                <ion-input type=\"text\" required formControlName=\"email\"></ion-input>\n              </ion-item>\n              <ion-label style=\"color: #fff;\">Password</ion-label>\n              <ion-item lines=\"none\" style=\"border: 1px solid rgb(122, 120, 120);margin-top: 5px;border-radius: 10px;\">\n                <ion-input type=\"password\" required formControlName=\"password\"></ion-input>\n              </ion-item>\n              <div class=\"forgotButton\" (click)=\"login()\">Forgot password?</div>\n              <div class=\"signinButton\" (click)=\"login()\">Login</div>\n              <!-- <div class=\"signupButton\" [routerLink]=\"['/register']\">Register now</div> -->\n            </ion-list>\n          </form>\n        </div>\n        <div>\n          <div style=\"text-align: center;width: 100%;color: #fff;margin-left: 20px;\">\n            {{errorMessage}}\n          </div>\n        </div>\n        <!-- <div style=\"position: absolute;bottom:0;\">\n          <img src=\"assets/sap.png\" style=\"border-radius: 20px;\">\n        </div> -->\n      </ion-col>\n      <ion-col sizeLg=\"4.5\" style=\"height: 100%;background-image: url(https://images.pexels.com/photos/1170412/pexels-photo-1170412.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2);background-size: cover;background-position: center;\">\n        \n      </ion-col>\n      \n    </ion-row>\n</ion-content>\n<ion-footer style=\"padding: 0px; background-color: #000\">\n  <ion-row style=\"padding: 0px\">\n    <ion-col style=\"padding: 0px\">\n      <div\n        style=\"\n          background: #000;\n          padding: 10px 20px;\n          padding-bottom: 15px;\n          text-align: right;\n          color: #ccc;\n          font-size: 16px;\n        \"\n      >\n        <span>\n          Copyrights 2020 © McKinsol Consulting Inc. All rights reserved</span\n        >\n      </div>\n    </ion-col>\n  </ion-row>\n</ion-footer>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_auth_login_login_module_ts.js.map