"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_attendance_attendance_module_ts"],{

/***/ 8669:
/*!***************************************************************!*\
  !*** ./src/app/pages/attendance/attendance-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AttendancePageRoutingModule": () => (/* binding */ AttendancePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _attendance_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./attendance.page */ 7760);




const routes = [
    {
        path: '',
        component: _attendance_page__WEBPACK_IMPORTED_MODULE_0__.AttendancePage
    }
];
let AttendancePageRoutingModule = class AttendancePageRoutingModule {
};
AttendancePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AttendancePageRoutingModule);



/***/ }),

/***/ 8818:
/*!*******************************************************!*\
  !*** ./src/app/pages/attendance/attendance.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AttendancePageModule": () => (/* binding */ AttendancePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _attendance_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./attendance-routing.module */ 8669);
/* harmony import */ var _attendance_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./attendance.page */ 7760);







let AttendancePageModule = class AttendancePageModule {
};
AttendancePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _attendance_routing_module__WEBPACK_IMPORTED_MODULE_0__.AttendancePageRoutingModule
        ],
        declarations: [_attendance_page__WEBPACK_IMPORTED_MODULE_1__.AttendancePage]
    })
], AttendancePageModule);



/***/ }),

/***/ 7760:
/*!*****************************************************!*\
  !*** ./src/app/pages/attendance/attendance.page.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AttendancePage": () => (/* binding */ AttendancePage)
/* harmony export */ });
/* harmony import */ var _Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _attendance_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./attendance.page.html?ngResource */ 5151);
/* harmony import */ var _attendance_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./attendance.page.scss?ngResource */ 6897);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/common.service */ 5620);





 // import { MassUploadPage } from 'src/app/Modal/mass-upload/mass-upload.page';


let AttendancePage = class AttendancePage {
  constructor(modalCtrl, commonService) {
    this.modalCtrl = modalCtrl;
    this.commonService = commonService;
    this.allRequests = [];
    this.checkAttendance = {};
    this.attendanceToggle = false;
    this.showDeleteButton = false;
  }

  ngOnInit() {
    this.fetchEmployee(this.commonService.formatDate(new Date()));
    this.attendenceDate = this.commonService.formatDate(new Date());
  }

  showModal() {// const modal = await this.modalCtrl.create({  
    //   component: MassUploadPage,
    //   componentProps : {payload : '/massUploadMaterial',name : 'Upload Attendence'},
    //   cssClass: 'my-custom-modal-css'
    // });  
    // return await modal.present();  

    return (0,_Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {})();
  }

  getDate(ev) {
    console.log(ev);
    console.log(ev.target.value);
    this.fetchEmployee(ev.target.value);
  }

  toggleAllAttendance() {
    this.attendanceToggle = !this.attendanceToggle;
    console.log("toggle ", this.attendanceToggle);
    let keys = Object.keys(this.checkAttendance);

    if (this.attendanceToggle) {
      this.showDeleteButton = true;
      keys.forEach(key => {
        this.checkAttendance[key] = true;
      });
    } else {
      this.showDeleteButton = false;
      keys.forEach(key => {
        this.checkAttendance[key] = false;
      });
    }
  }

  toggleOneAttendance(i) {
    let keys = Object.keys(this.checkAttendance);
    this.showDeleteButton;
    this.showDeleteButton = false;
    keys.forEach(key => {
      if (this.checkAttendance[key]) this.showDeleteButton = true;
    });
  } ////Fetch Employees who are on boarding


  fetchEmployee(date) {
    let formData = {
      organisationId: localStorage.getItem('organisationId'),
      date
    };
    this.commonService.getEmployeeAttendence(formData).then(resp => {
      console.log("resp", resp);
      this.allRequests = resp;
      this.allRequests.forEach((r, i) => {
        this.checkAttendance[i] = false;
      }); // this.toggleAllAttendance();
      // console.log("response from getEmployee",this.allRequests)
    });
  }

};

AttendancePage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController
}, {
  type: _services_common_service__WEBPACK_IMPORTED_MODULE_3__.CommonService
}];

AttendancePage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
  selector: 'app-attendance',
  template: _attendance_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_attendance_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], AttendancePage);


/***/ }),

/***/ 6897:
/*!******************************************************************!*\
  !*** ./src/app/pages/attendance/attendance.page.scss?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

module.exports = ".box {\n  height: 400px;\n  width: 98%;\n  border: 1px solid rgb(122, 120, 120);\n  border-radius: 10px;\n  background-color: #161b22;\n  color: #fff;\n}\n\nion-card {\n  border: 1px solid rgb(122, 120, 120);\n  border-radius: 10px;\n  background-color: transparent;\n  color: #fff;\n}\n\n.option {\n  text-align: center;\n  display: none;\n  height: 32px;\n  width: 40px;\n  border: 1px solid rgb(122, 120, 120);\n  border-radius: 10px;\n  margin-top: 5px;\n}\n\n.showOption:hover .option {\n  display: block;\n}\n\n.option1 {\n  display: none;\n}\n\n.item:hover .option1 {\n  display: block;\n}\n\n:host {\n  --padding-start: 0 !important;\n  --inner-padding-end: 0 !important;\n}\n\n#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF0dGVuZGFuY2UucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksYUFBQTtFQUNBLFVBQUE7RUFDQSxvQ0FBQTtFQUNBLG1CQUFBO0VBQ0EseUJBQUE7RUFDQSxXQUFBO0FBQ0o7O0FBRUE7RUFDSSxvQ0FBQTtFQUNBLG1CQUFBO0VBQ0EsNkJBQUE7RUFDQSxXQUFBO0FBQ0o7O0FBRUE7RUFDSSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLG9DQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0FBQ0o7O0FBR0k7RUFDSSxjQUFBO0FBQVI7O0FBSUE7RUFDSSxhQUFBO0FBREo7O0FBS0k7RUFDSSxjQUFBO0FBRlI7O0FBVUE7RUFDSSw2QkFBQTtFQUNBLGlDQUFBO0FBUEo7O0FBV0E7RUFDSSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSxRQUFBO0VBQ0EsMkJBQUE7QUFSSjs7QUFXRTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtBQVJKOztBQVdFO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLFNBQUE7QUFSSjs7QUFXRTtFQUNFLHFCQUFBO0FBUkoiLCJmaWxlIjoiYXR0ZW5kYW5jZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYm94IHtcbiAgICBoZWlnaHQ6IDQwMHB4O1xuICAgIHdpZHRoOiA5OCU7XG4gICAgYm9yZGVyOiAxcHggc29saWQgcmdiKDEyMiwgMTIwLCAxMjApO1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzE2MWIyMjtcbiAgICBjb2xvcjogI2ZmZjtcbn1cblxuaW9uLWNhcmQge1xuICAgIGJvcmRlcjogMXB4IHNvbGlkIHJnYigxMjIsIDEyMCwgMTIwKTtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xuICAgIGNvbG9yOiAjZmZmO1xufVxuXG4ub3B0aW9uIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZGlzcGxheTogbm9uZTtcbiAgICBoZWlnaHQ6IDMycHg7XG4gICAgd2lkdGg6IDQwcHg7XG4gICAgYm9yZGVyOiAxcHggc29saWQgcmdiKDEyMiwgMTIwLCAxMjApO1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgbWFyZ2luLXRvcDogNXB4O1xufVxuXG4uc2hvd09wdGlvbjpob3ZlciB7XG4gICAgLm9wdGlvbiB7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIH1cbn1cblxuLm9wdGlvbjEge1xuICAgIGRpc3BsYXk6IG5vbmU7XG59XG5cbi5pdGVtOmhvdmVyIHtcbiAgICAub3B0aW9uMSB7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIH1cbn1cblxuLy8gLml0ZW0ge1xuLy8gICAgIHdpZHRoOiAyODBweDtcbi8vIH1cblxuOmhvc3Qge1xuICAgIC0tcGFkZGluZy1zdGFydDogMCAhaW1wb3J0YW50O1xuICAgIC0taW5uZXItcGFkZGluZy1lbmQ6IDAgIWltcG9ydGFudDtcbn1cblxuXG4jY29udGFpbmVyIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGxlZnQ6IDA7XG4gICAgcmlnaHQ6IDA7XG4gICAgdG9wOiA1MCU7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC01MCUpO1xuICB9XG4gIFxuICAjY29udGFpbmVyIHN0cm9uZyB7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIGxpbmUtaGVpZ2h0OiAyNnB4O1xuICB9XG4gIFxuICAjY29udGFpbmVyIHAge1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICBsaW5lLWhlaWdodDogMjJweDtcbiAgICBjb2xvcjogIzhjOGM4YztcbiAgICBtYXJnaW46IDA7XG4gIH1cbiAgXG4gICNjb250YWluZXIgYSB7XG4gICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xuICB9Il19 */";

/***/ }),

/***/ 5151:
/*!******************************************************************!*\
  !*** ./src/app/pages/attendance/attendance.page.html?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

module.exports = "<ion-header class=\"ion-no-border\">\n  <ion-toolbar color=\"gray\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Attendance</ion-title>\n  </ion-toolbar>\n  <!-- <ion-toolbar color=\"dark\">\n    <ion-searchbar placeholder=\"Filter Requests\"></ion-searchbar>\n  </ion-toolbar> -->\n  <ion-toolbar color=\"gray\">\n    <ion-row>\n      <ion-col size=\"6\" style=\"border: 1px solid rgb(37 38 40);background-color: rgb(30 31 33);padding: 0px;\">\n        <ion-item lines=\"none\">\n          <!-- <ion-label position=\"fixed\" style=\"color: #000;\">Date</ion-label> -->\n          <ion-input [(ngModel)]=\"attendenceDate\" (change)=\"getDate($event)\" type=\"date\" style=\"color: #ccc;font-weight: bold;\"></ion-input>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"2\" style=\"border: 1px solid rgb(37 38 40);background-color: rgb(30 31 33);padding: 0px;\">\n        <ion-button\n        (click)=\"showModal()\"\n       \n        color=\"dark\"\n        size=\"small\"\n        expand=\"block\"\n        style=\"font-size: 17px;\"\n      >\n        Upload CSV\n      </ion-button>\n      </ion-col>\n      <ion-col size=\"2\" style=\"border: 1px solid rgb(37 38 40);background-color: rgb(30 31 33);padding: 0px;\">\n        <ion-button\n        (click)=\"showModal()\"\n       \n        color=\"dark\"\n        size=\"small\"\n        expand=\"block\"\n        style=\"font-size: 17px;\"\n      > \n      <!-- fill=\"outline\" -->\n        Download CSV\n      </ion-button>\n      </ion-col>\n      <ion-col size=\"2\" style=\"border: 1px solid rgb(37 38 40);background-color: rgb(30 31 33);padding: 0px;\">\n        <ion-button *ngIf=\"showDeleteButton\"\n        (click)=\"showModal()\"\n        fill=\"outline\"\n        color=\"danger\"\n        size=\"small\"\n        expand=\"block\"\n        style=\"font-size: 17px;color: #fff !important;\"\n      >\n        Delete Selected\n      </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-toolbar>\n</ion-header>\n<!-- <ion-header [translucent]=\"true\" class=\"ion-no-border\">\n  <ion-toolbar color=\"dark\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Attendence</ion-title>\n  </ion-toolbar>\n</ion-header> -->\n<ion-content>\n  <!-- Desktop View -->\n  <ion-grid class=\"ion-margin hidden-sm-down\">\n    <ion-row\n      style=\"position: sticky;top: 0px;z-index: 999999999;background-color: #000;color: #fff;margin: 0px;\">\n      <!-- <ion-col size=\"12\" style=\"padding: 0px; margin-top: 30px; margin-left: -20px\">\n        <ion-header>\n          <ion-toolbar color=\"dark\">\n            <ion-title size=\"large\">Attendence</ion-title>\n          </ion-toolbar>\n          <ion-toolbar color=\"dark\">\n            <ion-searchbar placeholder=\"Filter Requests\"></ion-searchbar>\n          </ion-toolbar>\n        </ion-header>\n      </ion-col> -->\n      <ion-col size=\"0.5\">\n        <ion-checkbox (ionChange)=\"toggleAllAttendance()\" color=\"dark\"></ion-checkbox>\n      </ion-col>\n      <ion-col style=\"line-height: 28px;\" size=\"2\">Employee Name</ion-col>\n      <ion-col style=\"line-height: 28px;\" size=\"1.5\">Employee Id</ion-col>\n      <ion-col style=\"line-height: 28px;\" size=\"2\">Date</ion-col>\n      <ion-col style=\"line-height: 28px;\" size=\"2\">Punch In</ion-col>\n      <ion-col style=\"line-height: 28px;\" size=\"2\">Punch Out</ion-col>\n      <ion-col style=\"line-height: 28px;\" size=\"1\">Over Time</ion-col>\n      <ion-col style=\"line-height: 28px;\" size=\"1\">Total Hours</ion-col>\n      <!-- <ion-col size=\"2\">Status</ion-col> -->\n    </ion-row>\n    <ion-row *ngIf=\"allRequests.length == 0\">\n      <div id=\"container\">\n        <img width=\"100px\" src=\"assets/loader.gif\" alt=\"\">\n      </div>\n    </ion-row>\n    <ion-row\n      *ngFor=\"let request of allRequests; index as i\"\n      [ngClass]=\"(i % 2 == 0) ? 'odd' : 'even'\"\n      style=\"margin: 5px 10px\"\n    >\n    <ion-col size=\"0.5\">\n      <ion-checkbox [(ngModel)]=\"checkAttendance[i]\" (ionChange)=\"toggleOneAttendance(i)\" color=\"dark\"></ion-checkbox>\n    </ion-col>\n    <ion-col style=\"line-height: 28px;\" size=\"2\">{{request.firstName}} {{request.lastName}}</ion-col>\n    <ion-col style=\"line-height: 28px;\" size=\"1.5\">{{request.employeeId}}</ion-col>\n      <ion-col style=\"line-height: 28px;\" size=\"2\">{{request.date}}</ion-col>\n      <ion-col style=\"line-height: 28px;\" size=\"2\">{{request.punchIn}}</ion-col>\n      <ion-col style=\"line-height: 28px;\" size=\"2\">{{request.punchOut}}</ion-col>\n      <ion-col style=\"line-height: 28px;\" size=\"1\">{{request.overtime}}</ion-col>\n      <ion-col style=\"line-height: 28px;\" size=\"1\">{{request.totalWorkingHours}}</ion-col>\n    </ion-row>\n  </ion-grid>\n  <ion-infinite-scroll>\n    <ion-infinite-scroll-content\n      loadingSpinner=\"bubbles\"\n      loadingText=\"Loading more data...\"\n    >\n    </ion-infinite-scroll-content>\n  </ion-infinite-scroll>\n</ion-content>\n<!-- <ion-footer class=\"ion-no-border\">\n  <ion-toolbar color=\"dark\">\n    <ion-buttons slot=\"start\">\n      <ion-button\n        (click)=\"showModal()\"\n        fill=\"outline\"\n        color=\"danger\"\n        expand=\"block\"\n        style=\"margin: 0px 20px;\"\n      >\n        Delete Selected\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-footer> -->\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_attendance_attendance_module_ts.js.map