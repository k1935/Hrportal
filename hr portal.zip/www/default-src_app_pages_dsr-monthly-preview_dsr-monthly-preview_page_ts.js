"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_pages_dsr-monthly-preview_dsr-monthly-preview_page_ts"],{

/***/ 310:
/*!***********************************************************************!*\
  !*** ./src/app/pages/dsr-monthly-preview/dsr-monthly-preview.page.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DsrMonthlyPreviewPage": () => (/* binding */ DsrMonthlyPreviewPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _dsr_monthly_preview_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dsr-monthly-preview.page.html?ngResource */ 994);
/* harmony import */ var _dsr_monthly_preview_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dsr-monthly-preview.page.scss?ngResource */ 660);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_tasks_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/tasks.service */ 2632);
/* harmony import */ var _services_project_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/project.service */ 354);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/auth.service */ 7556);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/common.service */ 5620);









let DsrMonthlyPreviewPage = class DsrMonthlyPreviewPage {
    constructor(commonService, authService, tasksService, projectService, modalCtrl) {
        this.commonService = commonService;
        this.authService = authService;
        this.tasksService = tasksService;
        this.projectService = projectService;
        this.modalCtrl = modalCtrl;
        this.teams = [];
        this.years = [];
        this.month = 1;
        this.teamEmployees = [];
        this.months = [
            { value: 1, name: 'January' },
            { value: 2, name: 'February' },
            { value: 3, name: 'March' },
            { value: 4, name: 'April' },
            { value: 5, name: 'May' },
            { value: 6, name: 'June' },
            { value: 7, name: 'July' },
            { value: 8, name: 'August' },
            { value: 9, name: 'September' },
            { value: 10, name: 'October' },
            { value: 11, name: 'November' },
            { value: 12, name: 'December' }
        ];
        this.dsrData = [];
        this.allMonthDates = [];
        this.employeeIds = [];
        this.permissionViewAllDSR = false;
    }
    ngOnInit() {
        let date = new Date();
        this.month = date.getMonth() + 1;
        let year = date.getFullYear();
        for (let i = 0; i < 10; i++)
            this.years.push(year - i);
        this.year = year;
        this.authService.userLogin.subscribe((userData) => {
            this.projectService.getTeamsReporting().then((reportingTeamData) => {
                console.log("getTeamsReporting ", reportingTeamData);
                this.teams = reportingTeamData;
                console.log("getTeamsReporting this.teams ", this.teams);
                if (reportingTeamData.length > 0) {
                    this.selectedTeam = reportingTeamData[0].teamId;
                    console.log("getTeamsReporting this.selectedTeam ", this.selectedTeam);
                    this.teamEmployees = reportingTeamData[0].users;
                    console.log("getTeamsReporting this.teamEmployees ", this.teamEmployees);
                    this.employeeIds = this.teamEmployees;
                    console.log("getTeamsReporting this.employeeIds ", this.employeeIds);
                }
                this.permissionViewAllDSR = userData.permissions.ViewAllDSR;
                this.commonService.fetchAllTeams().then(teamData => {
                    if (this.permissionViewAllDSR) {
                        this.teams = teamData;
                        this.selectedTeam = teamData[0].teamId;
                        this.teamEmployees = teamData[0].users;
                        this.employeeIds = this.teamEmployees;
                        this.filterDsr();
                    }
                });
            }, error => {
                console.log("getTeamsReporting error ", error);
            });
        });
    }
    filterDsr() {
        let monthDates = new Date(this.year, this.month, 0).getDate();
        this.allMonthDates = [];
        for (let i = 1; i <= monthDates; i++)
            this.allMonthDates.push(i);
        this.tasksService.filterDsr({ employeeIds: this.employeeIds, month: this.month, year: this.year }).then((resp) => {
            // console.log("resp filterDsr ",resp);
            this.dsrData = resp;
            resp.forEach(emp => {
                let d = emp.result;
                for (let i = 1; i <= monthDates; i++) {
                    let fDate = this.year + '-' + this.addLeadingZeros(this.month, 2) + '-' + this.addLeadingZeros(i, 2);
                    // console.log(" fDate ",fDate);
                    let filtered = d.filter(r => r.date == fDate);
                    // console.log(" filtered ",filtered);
                    if (filtered.length == 0) {
                    }
                }
            });
            console.log("resp this.allMonthDates ", this.allMonthDates);
        });
    }
    addLeadingZeros(num, totalLength) {
        return String(num).padStart(totalLength, '0');
    }
    teamChanged(event) {
        let filteredTeams = this.teams.filter(team => event.indexOf(team.teamId) > -1);
        let employeesIds = [];
        filteredTeams.forEach(team => {
            employeesIds = employeesIds.concat(team.users);
        });
        this.employeeIds = employeesIds;
        this.filterDsr();
    }
    checkStatus(dsr, date) {
        let fDate = this.year + '-' + this.addLeadingZeros(this.month, 2) + '-' + this.addLeadingZeros(date, 2);
        let filtered = dsr.result.filter(r => r.date == fDate);
        if (filtered && filtered[0] && filtered[0].dsrStatus == 'Completed')
            return 1;
        else if (filtered && filtered[0] && filtered[0].dsrStatus == 'In-Complete')
            return 2;
        else
            return 0;
    }
};
DsrMonthlyPreviewPage.ctorParameters = () => [
    { type: _services_common_service__WEBPACK_IMPORTED_MODULE_5__.CommonService },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_4__.AuthService },
    { type: _services_tasks_service__WEBPACK_IMPORTED_MODULE_2__.TasksService },
    { type: _services_project_service__WEBPACK_IMPORTED_MODULE_3__.ProjectService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController }
];
DsrMonthlyPreviewPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-dsr-monthly-preview',
        template: _dsr_monthly_preview_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_dsr_monthly_preview_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], DsrMonthlyPreviewPage);



/***/ }),

/***/ 354:
/*!*********************************************!*\
  !*** ./src/app/services/project.service.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProjectService": () => (/* binding */ ProjectService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth.service */ 7556);




let ProjectService = class ProjectService {
    constructor(authService, http) {
        this.authService = authService;
        this.http = http;
    }
    createProject(projectObject) {
        projectObject.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'createProject', projectObject).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateProject(projectObject) {
        projectObject.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'updateProject', projectObject).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getOneProject(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getOneProject', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getProjectMembers(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getProjectMembers', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    addProjectMember(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'addProjectMember', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    removeProjectMember(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'removeProjectMember', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateProjectMember(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'updateProjectMember', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    fetchAllProjects(paramsData) {
        paramsData.organisationId = this.authService.organisationId;
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'fetchAllProjects', paramsData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getMemberProjects() {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getMemberProjects', { employeeId: this.authService.userId }).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getTeamsReporting() {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getTeamsReporting', { userId: this.authService.userId }).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    createEpic(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'createEpic', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateProjectEpic(epicData) {
        let newEpic = Object.assign(epicData);
        newEpic['id'] = newEpic.id.replace('epic', '');
        console.log("updateProjectEpic epicData ", epicData);
        console.log("updateProjectEpic newEpic ", newEpic);
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'epicUpdate', newEpic).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getProjectEpics(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getProjectEpics', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    createStory(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'createStory', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateEpicStory(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'storyUpdate', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getEpicStories(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getStories', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    createStoryTask(taskData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'createStoryTask', taskData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getStoryTasks(epicData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getStoryTasks', epicData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getProjectColumns(projectData) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getProjectColumns', projectData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateProjectTask(task) {
        return new Promise((resolve, reject) => {
            task.organisationId = this.authService.organisationId;
            this.http.post(this.authService.apiUrl + 'updateProjectTask', task).subscribe((resp) => {
                console.log("rsp", resp);
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
};
ProjectService.ctorParameters = () => [
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
ProjectService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], ProjectService);



/***/ }),

/***/ 2632:
/*!*******************************************!*\
  !*** ./src/app/services/tasks.service.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TasksService": () => (/* binding */ TasksService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth.service */ 7556);




let TasksService = class TasksService {
    constructor(authService, http) {
        this.authService = authService;
        this.http = http;
    }
    getUserTeams() {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getUserTeams', { userId: this.authService.userId }).subscribe((resp) => {
                console.log("rsp", resp);
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    fetchTeamColumns(teamId) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'fetchTeamColumns', { teamId }).subscribe((resp) => {
                console.log("rsp", resp);
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    updateTask(task) {
        return new Promise((resolve, reject) => {
            task.organisationId = this.authService.organisationId;
            this.http.post(this.authService.apiUrl + 'updateTask', task).subscribe((resp) => {
                console.log("rsp", resp);
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    createTask(task) {
        return new Promise((resolve, reject) => {
            task.organisationId = this.authService.organisationId;
            task.employeeId = this.authService.userId;
            this.http.post(this.authService.apiUrl + 'createTask', task).subscribe((resp) => {
                console.log("rsp", resp);
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getUserTasks(column) {
        return new Promise((resolve, reject) => {
            column.organisationId = this.authService.organisationId;
            column.employeeId = this.authService.userId;
            this.http.post(this.authService.apiUrl + 'getUserTasks', column).subscribe((resp) => {
                // console.log("rsp",resp)
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    deleteUserTasks(column) {
        return new Promise((resolve, reject) => {
            column.organisationId = this.authService.organisationId;
            column.employeeId = this.authService.userId;
            this.http.post(this.authService.apiUrl + 'deleteTask', column).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    filterDsr(params) {
        return new Promise((resolve, reject) => {
            params.organisationId = this.authService.organisationId;
            // if(!params.employeeIds)
            // params.employeeIds = [this.authService.userId];
            // params.employeeIds = [4,9,31];
            this.http.post(this.authService.apiUrl + 'filterDsr', params).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
};
TasksService.ctorParameters = () => [
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
TasksService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], TasksService);



/***/ }),

/***/ 660:
/*!************************************************************************************!*\
  !*** ./src/app/pages/dsr-monthly-preview/dsr-monthly-preview.page.scss?ngResource ***!
  \************************************************************************************/
/***/ ((module) => {

module.exports = "table {\n  font-family: arial, sans-serif;\n  border-collapse: collapse;\n  width: 100%;\n}\n\ntd, th {\n  border: 1px solid rgb(95, 95, 95);\n  text-align: left;\n  padding: 8px;\n}\n\ntr:nth-child(even) {\n  background-color: #222;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRzci1tb250aGx5LXByZXZpZXcucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksOEJBQUE7RUFDQSx5QkFBQTtFQUNBLFdBQUE7QUFDSjs7QUFFRTtFQUNFLGlDQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0FBQ0o7O0FBRUU7RUFDRSxzQkFBQTtBQUNKIiwiZmlsZSI6ImRzci1tb250aGx5LXByZXZpZXcucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsidGFibGUge1xuICAgIGZvbnQtZmFtaWx5OiBhcmlhbCwgc2Fucy1zZXJpZjtcbiAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xuICAgIHdpZHRoOiAxMDAlO1xuICB9XG4gIFxuICB0ZCwgdGgge1xuICAgIGJvcmRlcjogMXB4IHNvbGlkIHJnYig5NSwgOTUsIDk1KTtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIHBhZGRpbmc6IDhweDtcbiAgfVxuICBcbiAgdHI6bnRoLWNoaWxkKGV2ZW4pIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMjIyO1xuICB9Il19 */";

/***/ }),

/***/ 994:
/*!************************************************************************************!*\
  !*** ./src/app/pages/dsr-monthly-preview/dsr-monthly-preview.page.html?ngResource ***!
  \************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar color=\"gray\">\n    <ion-title>DSR Monthly Preview</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"modalCtrl.dismiss()\">\n        <ion-icon name=\"arrow-down\"></ion-icon>\n      </ion-button>\n      <!-- <ion-button>\n        <ion-icon name=\"settings-outline\"></ion-icon>\n      </ion-button> -->\n    </ion-buttons>\n  </ion-toolbar>\n  <ion-toolbar color=\"gray\" style=\"border-top: 1px solid #3f4040;\">\n    <ion-row>\n      <ion-col size=\"4\" style=\"border-right: 1px solid rgb(37 38 40);\n      background-color: transparent;\n      padding: 0px;\">\n        <ion-item lines=\"none\">\n          <ion-select placeholder=\"Select team\" [(ngModel)]=\"selectedTeam\" (ngModelChange)=\"teamChanged($event)\"\n            style=\"color: #fff;width: 100%;\" multiple>\n            <ion-select-option *ngFor=\"let team of teams\" style=\"color: #fff;font-weight: bold;\" [value]=\"team.teamId\">\n              {{team.teamName}}</ion-select-option>\n          </ion-select>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"4\" style=\"border-right: 1px solid rgb(37 38 40);\n      background-color: transparent;\n      padding: 0px;\">\n        <ion-item lines=\"none\">\n          <ion-select placeholder=\"Select year\" [(ngModel)]=\"year\" style=\"color: #fff;width: 100%;\" >\n            <ion-select-option *ngFor=\"let year of years\" style=\"color: #fff;font-weight: bold;\" [value]=\"year\">{{year}}\n            </ion-select-option>\n          </ion-select>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"4\" style=\"border-right: 0px solid rgb(37 38 40);\n      background-color: transparent;\n      padding: 0px;\">\n        <ion-item lines=\"none\">\n          <ion-select placeholder=\"Select month\" [(ngModel)]=\"month\" style=\"color: #fff;width: 100%;\" >\n            <ion-select-option *ngFor=\"let month of months\" style=\"color: #fff;font-weight: bold;\"\n              [value]=\"month.value\">{{month.name}}</ion-select-option>\n          </ion-select>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <table>\n    <tr>\n      <th></th>\n      <th *ngFor=\"let date of allMonthDates\">{{date}}</th>\n    </tr>\n    <tr *ngFor=\"let dsr of dsrData\">\n      <td>{{dsr.name}}</td>\n      <td *ngFor=\"let date of allMonthDates\">\n        <div *ngIf=\"checkStatus(dsr, date) == 1\" style=\"color: #2ecc71;width:20px;height:20px;border-radius: 50%;text-align: center;\">\n          <ion-icon name=\"checkmark-circle-outline\"></ion-icon>\n        </div>\n        <div *ngIf=\"checkStatus(dsr, date) == 2\" style=\"color: #f1c40f;width:20px;height:20px;border-radius: 50%;text-align: center;\">\n          <ion-icon name=\"information-circle-outline\"></ion-icon>\n        </div>\n        <div *ngIf=\"checkStatus(dsr, date) == 0\" style=\"color: #e74c3c;width:20px;height:20px;border-radius: 50%;text-align: center;\">\n          <ion-icon name=\"close-circle-outline\"></ion-icon>\n        </div>\n      </td>\n    </tr>\n  </table>\n  <!-- <ion-row>\n    <ion-col size=\"2\">\n    </ion-col>\n    <ion-col size=\"10\">\n      <ion-row>\n        <ion-col *ngFor=\"let date of allMonthDates\">\n          <div style=\"background-color: red;margin:1px;text-align: center;\">\n            {{date}}\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-col>\n  </ion-row> -->\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=default-src_app_pages_dsr-monthly-preview_dsr-monthly-preview_page_ts.js.map