"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_auth_register_register_module_ts"],{

/***/ 2638:
/*!**********************************************************!*\
  !*** ./src/app/auth/register/register-routing.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPageRoutingModule": () => (/* binding */ RegisterPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register.page */ 1351);




const routes = [
    {
        path: '',
        component: _register_page__WEBPACK_IMPORTED_MODULE_0__.RegisterPage
    }
];
let RegisterPageRoutingModule = class RegisterPageRoutingModule {
};
RegisterPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], RegisterPageRoutingModule);



/***/ }),

/***/ 6108:
/*!**************************************************!*\
  !*** ./src/app/auth/register/register.module.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPageModule": () => (/* binding */ RegisterPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _register_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register-routing.module */ 2638);
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./register.page */ 1351);







let RegisterPageModule = class RegisterPageModule {
};
RegisterPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _register_routing_module__WEBPACK_IMPORTED_MODULE_0__.RegisterPageRoutingModule
        ],
        declarations: [_register_page__WEBPACK_IMPORTED_MODULE_1__.RegisterPage]
    })
], RegisterPageModule);



/***/ }),

/***/ 1351:
/*!************************************************!*\
  !*** ./src/app/auth/register/register.page.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPage": () => (/* binding */ RegisterPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _register_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register.page.html?ngResource */ 4089);
/* harmony import */ var _register_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./register.page.scss?ngResource */ 9105);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/common.service */ 5620);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 124);








// import { HelperService } from '../../services/helper.service';

let RegisterPage = class RegisterPage {
    constructor(fb, commonService, navController, menuController, 
    // private loadingService: LoadingService,
    platform, authService, 
    // private userService: UserService,
    // private helperService: HelperService,
    // private authService: AuthService,
    router) {
        this.fb = fb;
        this.commonService = commonService;
        this.navController = navController;
        this.menuController = menuController;
        this.platform = platform;
        this.authService = authService;
        this.router = router;
    }
    ngOnInit() {
        this.form = this.fb.group({
            organisationName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            organisationGST: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            organisationPAN: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            organisationEmail: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            organisationBranch: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            organisationPhone: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            organisationAddress: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            NumberofEmployee: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            password: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
            confirmPassword: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
        });
    }
    ionViewWillEnter() {
        this.menuController.enable(false);
    }
    ionViewWillLeave() {
        this.menuController.enable(true);
    }
    login() {
        console.log(this.form.value);
        // this.authService.login(this.form.value).then((m: any) => {
        //   // console.log(m._id)
        //   if (m && m._id) {
        //     this.userId = m._id
        //     localStorage.setItem('userId', JSON.stringify(this.userId))
        //     this.router.navigate(['/home'])
        //     this.commonService.showToast("success", "Login Successful!")
        //   } else {
        //     this.commonService.showToast("error", "Invalid Username or Password!")
        //   }
        // }, error => {
        //   console.log(error);
        // })
    }
    ////create organisation api
    register() {
        if (this.form.valid) {
            let formData = this.form.value;
            console.log("formData", formData);
            if (formData.password == formData.confirmPassword) {
                this.commonService.createOrg(formData).then((resp) => {
                    this.commonService.showToast("success", "Welcome aboard! Login to Continue.");
                    this.router.navigate(['/login']);
                    console.log("resp", resp);
                });
            }
            else {
                this.commonService.showToast('error', "Password and Confirm Password don't match!");
            }
        }
    }
};
RegisterPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder },
    { type: _services_common_service__WEBPACK_IMPORTED_MODULE_3__.CommonService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.MenuController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.Platform },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router }
];
RegisterPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-register',
        template: _register_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_register_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], RegisterPage);



/***/ }),

/***/ 9105:
/*!*************************************************************!*\
  !*** ./src/app/auth/register/register.page.scss?ngResource ***!
  \*************************************************************/
/***/ ((module) => {

module.exports = "ion-footer {\n  --ion-background-color: #f6f6f6;\n}\n\nion-toolbar {\n  --background: #f6f6f6;\n  --color: #222;\n}\n\nion-button {\n  --color: #f6f6f6;\n}\n\nion-item {\n  --background: transparent;\n  box-shadow: 1px 1px 4px 0px rgba(0, 0, 0, 0.5);\n}\n\nion-input {\n  color: #fff;\n}\n\nion-row {\n  padding: 0px !important;\n}\n\n.base {\n  background: white;\n  margin: 0px auto;\n  display: flex;\n  flex-direction: row;\n  justify-content: center;\n  overflow: hidden;\n}\n\n.terms {\n  text-align: left;\n  font-size: 11px;\n  padding: 10px;\n}\n\n.register-button {\n  background: #2261a1;\n  color: white;\n  padding: 5px;\n  width: 100%;\n  text-align: center;\n  margin: 5px;\n  cursor: pointer;\n}\n\n.login-button {\n  color: #222;\n  padding: 5px;\n  width: 100%;\n  text-align: center;\n  margin: 5px;\n  cursor: pointer;\n}\n\n.signinButton {\n  background: #2980b9;\n  border-radius: 10px;\n  text-align: center;\n  line-height: 2.5rem;\n  width: 100%;\n  margin: 0 auto;\n  margin-top: 20px;\n  font-weight: bold;\n  color: #fff;\n  cursor: pointer;\n  border: 1px solid #fff;\n}\n\n.signupButton {\n  border-radius: 10px;\n  text-align: center;\n  line-height: 2.5rem;\n  width: 100%;\n  margin: 0 auto;\n  margin-top: 20px;\n  font-weight: bold;\n  color: #222;\n  cursor: pointer;\n  border: 1px solid #fff;\n}\n\n.forgotButton {\n  background: #fff;\n  text-align: right;\n  margin: 0 auto;\n  margin-top: 20px;\n  margin-bottom: 10px;\n  font-weight: bold;\n  color: #2980b9;\n  cursor: pointer;\n}\n\nion-item {\n  box-shadow: none !important;\n}\n\n@media screen and (max-width: 480px) {\n  .box {\n    border-radius: 20px;\n  }\n  .container {\n    margin: 15px !important;\n    height: calc(100% - 30px) !important;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlZ2lzdGVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFVQTtFQUdJLCtCQUFBO0FBWEo7O0FBY0E7RUFDSSxxQkFBQTtFQUNBLGFBQUE7QUFYSjs7QUFjQTtFQUNJLGdCQUFBO0FBWEo7O0FBY0E7RUFFSSx5QkFBQTtFQUNGLDhDQUFBO0FBWkY7O0FBY0E7RUFDSSxXQUFBO0FBWEo7O0FBdUJBO0VBQ0ksdUJBQUE7QUFwQko7O0FBdUJBO0VBQ0ksaUJBQUE7RUFJQSxnQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsZ0JBQUE7QUF2Qko7O0FBMkJBO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsYUFBQTtBQXhCSjs7QUEyQkE7RUFDSSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7QUF4Qko7O0FBMkJBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtBQXhCSjs7QUEyQkE7RUFDSSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0Esc0JBQUE7QUF4Qko7O0FBMkJBO0VBRUksbUJBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxzQkFBQTtBQXpCSjs7QUE0QkE7RUFDSSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0FBekJKOztBQTRCQTtFQUNJLDJCQUFBO0FBekJKOztBQTRCQTtFQUNJO0lBQ0ksbUJBQUE7RUF6Qk47RUEyQkU7SUFDSSx1QkFBQTtJQUNBLG9DQUFBO0VBekJOO0FBQ0YiLCJmaWxlIjoicmVnaXN0ZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXG5cbi8vIGlvbi1jb250ZW50IHtcbiAgICAvLyAtLWlvbi1iYWNrZ3JvdW5kOiB1cmwoXCJhc3NldHMvaW1ncy9iZy5qcGdcIik7XG4gICAgLy8gLS1pb24tYmFja2dyb3VuZC1jb2xvcjogI2ZiZmJmYjtcbiAgICAvLyAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICAgIC8vIC0taW9uLWJhY2tncm91bmQtY29sb3I6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSg0Nyw4OCwxMjAsMSkgMCUsIHJnYmEoMTQxLDE3NSwyMDIsMSkgMTAwJSk7XG5cbi8vIH1cblxuaW9uLWZvb3RlciB7XG4gICAgLy8gLS1pb24tYmFja2dyb3VuZC1jb2xvcjogI2ZiZmJmYjtcbiAgICAvLyAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAjZmJmYmZiO1xuICAgIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICNmNmY2ZjY7XG59XG5cbmlvbi10b29sYmFyIHtcbiAgICAtLWJhY2tncm91bmQ6ICNmNmY2ZjY7XG4gICAgLS1jb2xvcjogIzIyMjtcbn1cblxuaW9uLWJ1dHRvbiB7XG4gICAgLS1jb2xvcjogI2Y2ZjZmNjtcbn1cblxuaW9uLWl0ZW0ge1xuICAgIC8vIGJhY2tncm91bmQ6ICNmYmZiZmI7XG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgYm94LXNoYWRvdzogMXB4IDFweCA0cHggMHB4IHJnYmEoMCwgMCwgMCwgMC41KTtcbn1cbmlvbi1pbnB1dHtcbiAgICBjb2xvcjogI2ZmZjtcbiAgfVxuXG5cblxuXG4vLyBpb24tY2FyZCB7XG4vLyAgIC0tYmFja2dyb3VuZDogI2ZmZjtcbi8vICAgbWFyZ2luOiAxNXB4IDIwcHg7XG5cbi8vIH1cblxuaW9uLXJvdyB7XG4gICAgcGFkZGluZzogMHB4ICFpbXBvcnRhbnQ7XG59XG5cbi5iYXNlIHtcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgICAvLyBib3gtc2hhZG93OiAwIDAgMjBweCAwIHJnYmEoMCwgMCwgMCwgMC4xNSk7XG4gICAgLy8gd2lkdGg6IDg3OHB4O1xuICAgIC8vIGhlaWdodDogNTYxcHg7XG4gICAgbWFyZ2luOiAwcHggYXV0bztcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICAvLyBib3JkZXItcmFkaXVzOiA1cHg7XG59XG5cbi50ZXJtcyB7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBmb250LXNpemU6IDExcHg7XG4gICAgcGFkZGluZzogMTBweDtcbn1cblxuLnJlZ2lzdGVyLWJ1dHRvbiB7XG4gICAgYmFja2dyb3VuZDogIzIyNjFhMTtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgcGFkZGluZzogNXB4O1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBtYXJnaW46IDVweDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG59XG5cbi5sb2dpbi1idXR0b24ge1xuICAgIGNvbG9yOiAjMjIyO1xuICAgIHBhZGRpbmc6IDVweDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgbWFyZ2luOiA1cHg7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xufVxuXG4uc2lnbmluQnV0dG9uIHtcbiAgICBiYWNrZ3JvdW5kOiAjMjk4MGI5O1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGxpbmUtaGVpZ2h0OiAyLjVyZW07XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgbWFyZ2luOiAwIGF1dG87XG4gICAgbWFyZ2luLXRvcDogMjBweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgYm9yZGVyOjFweCBzb2xpZCAjZmZmO1xufVxuXG4uc2lnbnVwQnV0dG9uIHtcbiAgICAvLyBiYWNrZ3JvdW5kOiAjMjk4MGI5O1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGxpbmUtaGVpZ2h0OiAyLjVyZW07XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgbWFyZ2luOiAwIGF1dG87XG4gICAgbWFyZ2luLXRvcDogMjBweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBjb2xvcjogIzIyMjtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgYm9yZGVyOjFweCBzb2xpZCAjZmZmO1xufVxuXG4uZm9yZ290QnV0dG9uIHtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xuICAgIHRleHQtYWxpZ246IHJpZ2h0O1xuICAgIG1hcmdpbjogMCBhdXRvO1xuICAgIG1hcmdpbi10b3A6IDIwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBjb2xvcjogIzI5ODBiOTtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG59XG5cbmlvbi1pdGVtIHtcbiAgICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XG59XG5cbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDQ4MHB4KSB7XG4gICAgLmJveCB7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDIwcHg7XG4gICAgfVxuICAgIC5jb250YWluZXIge1xuICAgICAgICBtYXJnaW46IDE1cHggIWltcG9ydGFudDtcbiAgICAgICAgaGVpZ2h0OiBjYWxjKDEwMCUgLSAzMHB4KSAhaW1wb3J0YW50O1xuICAgIH1cbiAgfSJdfQ== */";

/***/ }),

/***/ 4089:
/*!*************************************************************!*\
  !*** ./src/app/auth/register/register.page.html?ngResource ***!
  \*************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <!-- https://www.applaudhr.com/hubfs/images/blog-images/Office.png -->\n  <!-- https://www.egnyte.com/sites/default/files/2022-01/FinancialServices%402x.png -->\n  <!-- https://images.unsplash.com/photo-1642355008521-236f1d29d0a8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1032&q=80 -->\n  <!-- https://images.unsplash.com/photo-1510936111840-65e151ad71bb?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=890&q=80 -->\n  <div\n    style=\"background:linear-gradient(55deg, #000, rgba(129, 128, 128, 0.3)), url(https://www.applaudhr.com/hubfs/images/blog-images/Office.png);background-size: cover;background-position: fixed;height: 100%;\" class=\"container\">\n    <ion-row style=\"height: 100%;\">\n      <ion-col style=\"height: calc(100% - 100px);z-index:9999999;opacity: 1;border-radius: 20px;margin: 50px;\" sizeLg=\"6\" offsetLg=\"3\" sizeMd=\"8\" offsetMd=\"2\" sizeSm=\"12\" sizeXs=\"12\" class=\"box\">\n        <div style=\"text-align: center;\">\n          <img src=\"assets\\icon\\hr-logo.png\" style=\"width:200px;\">\n          <!-- <div style=\"color:#fff;font-weight: 900;font-size: 22px;padding-bottom: 20px;\"></div> -->\n        </div>\n        <div>\n          <form [formGroup]=\"form\">\n            <ion-list style=\"background: transparent;\">\n              <ion-row>\n                <ion-col size=\"4\">\n                  <ion-label style=\"color: #fff;\">Company Name</ion-label>\n                  <ion-item lines=\"none\" style=\"border: 1px solid rgb(122, 120, 120);margin-bottom: 5px;margin-top: 5px;border-radius: 10px;\">\n                    <ion-input type=\"text\" required formControlName=\"organisationName\"></ion-input>\n                  </ion-item>\n                </ion-col>\n                <ion-col size=\"4\">\n                  <ion-label style=\"color: #fff;\">GST No.</ion-label>\n                  <ion-item lines=\"none\" style=\"border: 1px solid rgb(122, 120, 120);margin-bottom: 5px;margin-top: 5px;border-radius: 10px;\">\n                    <ion-input type=\"text\" required formControlName=\"organisationGST\"></ion-input>\n                  </ion-item>\n                </ion-col>\n                <ion-col size=\"4\">\n                  <ion-label style=\"color: #fff;\">PAN No.</ion-label>\n                  <ion-item lines=\"none\" style=\"border: 1px solid rgb(122, 120, 120);margin-bottom: 5px;margin-top: 5px;border-radius: 10px;\">\n                    <ion-input type=\"text\" required formControlName=\"organisationPAN\"></ion-input>\n                  </ion-item>\n                </ion-col>\n              </ion-row>\n              <ion-row>\n                <ion-col size=\"4\">\n                  <ion-label style=\"color: #fff;\">Phone*</ion-label>\n                  <ion-item lines=\"none\" style=\"border: 1px solid rgb(122, 120, 120);margin-bottom: 5px;margin-top: 5px;border-radius: 10px;\">\n                    <ion-input type=\"text\" required formControlName=\"organisationPhone\"></ion-input>\n                  </ion-item>\n                </ion-col>\n                <ion-col size=\"4\">\n                  <ion-label style=\"color: #fff;\">Email*</ion-label>\n                  <ion-item lines=\"none\" style=\"border: 1px solid rgb(122, 120, 120);margin-bottom: 5px;margin-top: 5px;border-radius: 10px;\">\n                    <ion-input type=\"text\" required formControlName=\"organisationEmail\"></ion-input>\n                  </ion-item>\n                </ion-col>\n                <ion-col size=\"4\">\n                  <ion-label style=\"color: #fff;\">Branch*</ion-label>\n                  <ion-item lines=\"none\" style=\"border: 1px solid rgb(122, 120, 120);margin-bottom: 5px;margin-top: 5px;border-radius: 10px;\">\n                    <ion-input type=\"text\" required formControlName=\"organisationBranch\"></ion-input>\n                  </ion-item>\n                </ion-col>\n              </ion-row>\n              <ion-row> \n                <ion-col size=\"8\">\n                    <ion-label style=\"color: #fff;\">Address*</ion-label>\n                    <ion-item lines=\"none\" style=\"border: 1px solid rgb(122, 120, 120);margin-bottom: 5px;margin-top: 5px;border-radius: 10px;\">\n                      <ion-input type=\"text\" required formControlName=\"organisationAddress\"></ion-input>\n                    </ion-item>\n                </ion-col>\n                <ion-col size=\"4\">\n                  <ion-label style=\"color: #fff;\">No. of Employee*</ion-label>\n                  <ion-item lines=\"none\" style=\"border: 1px solid rgb(122, 120, 120);margin-bottom: 5px;margin-top: 5px;border-radius: 10px;\">\n                    <ion-input type=\"number\" required formControlName=\"NumberofEmployee\"></ion-input>\n                  </ion-item>\n                </ion-col>\n                <ion-col size=\"4\">\n                  <ion-label style=\"color: #fff;\">Password</ion-label>\n                  <ion-item lines=\"none\" style=\"border: 1px solid rgb(122, 120, 120);margin-bottom: 5px;margin-top: 5px;border-radius: 10px;\">\n                    <ion-input type=\"password\" required formControlName=\"password\"></ion-input>\n                  </ion-item>\n                </ion-col>\n                <ion-col size=\"4\">\n                  <ion-label style=\"color: #fff;\">Confirm Password</ion-label>\n                  <ion-item lines=\"none\" style=\"border: 1px solid rgb(122, 120, 120);margin-bottom: 5px;margin-top: 5px;border-radius: 10px;\">\n                    <ion-input type=\"password\" required formControlName=\"confirmPassword\"></ion-input>\n                  </ion-item>\n                </ion-col>\n              </ion-row>\n              <!-- <ion-label style=\"color: #222;\">Organization name</ion-label>\n              <ion-item lines=\"none\" style=\"border: 1px solid #ccc;margin-bottom: 10px;margin-top: 5px;background: #fff;border-radius: 10px;\">\n                <ion-input style=\"\" type=\"text\" required formControlName=\"email\"></ion-input>\n              </ion-item>\n              <ion-label style=\"color: #222;\">Email address</ion-label>\n              <ion-item lines=\"none\" style=\"border: 1px solid #ccc;margin-bottom: 10px;margin-top: 5px;background: #fff;border-radius: 10px;\">\n                <ion-input style=\"\" type=\"text\" required formControlName=\"email\"></ion-input>\n              </ion-item>\n              <ion-label style=\"color: #222;\">Password</ion-label>\n              <ion-item lines=\"none\" style=\"border: 1px solid #ccc;margin-top: 5px;background: #fff;border-radius: 10px;\">\n                <ion-input style=\"\" type=\"password\" required formControlName=\"pwd\"></ion-input>\n              </ion-item> -->\n              <ion-row>\n                <ion-col size=\"6\">\n                  <ion-button expand=\"block\" fill=\"solid\" color=\"success\" (click)=\"register()\">Register</ion-button>\n                </ion-col>\n                <ion-col size=\"6\">\n                  <ion-button style=\"border:1px solid rgb(122, 120, 120);border-radius: 10px;\" expand=\"block\" fill=\"clear\" color=\"light\" [routerLink]=\"['/login']\">Go to login</ion-button>\n                </ion-col>\n              </ion-row>\n            </ion-list>\n          </form>\n        </div>\n        <div>\n          <div style=\"text-align: center;width: 100%;color: #fff;margin-left: 20px;\">\n            {{errorMessage}}\n          </div>\n        </div>\n        <!-- <div style=\"position: absolute;bottom:0;\">\n          <img src=\"assets/sap.png\" style=\"border-radius: 20px;\">\n        </div> -->\n      </ion-col>\n    </ion-row>\n  </div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_auth_register_register_module_ts.js.map