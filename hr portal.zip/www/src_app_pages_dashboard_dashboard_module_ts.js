"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_dashboard_dashboard_module_ts"],{

/***/ 4792:
/*!*************************************************!*\
  !*** ./src/app/components/dsr/dsr.component.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DsrComponent": () => (/* binding */ DsrComponent)
/* harmony export */ });
/* harmony import */ var _Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _dsr_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dsr.component.html?ngResource */ 2496);
/* harmony import */ var _dsr_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./dsr.component.scss?ngResource */ 3514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/common.service */ 5620);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_tasks_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/tasks.service */ 2632);
/* harmony import */ var _services_project_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/project.service */ 354);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/auth.service */ 7556);
/* harmony import */ var _pages_dsr_monthly_preview_dsr_monthly_preview_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../pages/dsr-monthly-preview/dsr-monthly-preview.page */ 310);











let DsrComponent = class DsrComponent {
  constructor(authService, tasksService, projectService, commonService, modalCtrl) {
    this.authService = authService;
    this.tasksService = tasksService;
    this.projectService = projectService;
    this.commonService = commonService;
    this.modalCtrl = modalCtrl;
    this.status = '0';
    this.dsrEmployees = [];
    this.employees = [];
    this.teams = [];
    this.teamEmployees = [];
    this.selectedStatuses = [0];
  }

  ngOnInit() {
    this.toDate = this.commonService.formatDate(new Date());
    this.fromDate = this.commonService.formatDate(new Date());
    this.authService.userLogin.subscribe(resp => {
      if (resp && Object.keys(resp).length > 0) {
        this.projectService.getTeamsReporting().then(resp => {
          console.log("getTeamsReporting resp ", resp);

          if (resp.length > 0) {
            this.teams = resp;
            this.selectedTeam = [resp[0].teamId];
            this.teamEmployees = resp[0].users;
            this.getDSR(resp[0].users);
          }
        });
      }
    });
  }

  teamChanged(event) {
    let selectedTeams = this.teams.filter(t => this.selectedTeam.indexOf(t.teamId) != -1);
    let employees = [];
    selectedTeams.forEach(team => {
      employees = employees.concat(team.users);
    });
    employees = employees.filter((item, index) => {
      return employees.indexOf(item) == index;
    });
    this.teamEmployees = employees;
    this.getDSR(employees);
  }

  statusChanged(event) {
    this.selectedStatuses = event;
    this.getDSR(this.teamEmployees);
  }

  getDSR(employees) {
    this.commonService.getDSR({
      statuses: this.selectedStatuses,
      employeeId: employees,
      from: this.fromDate,
      to: this.toDate
    }).then(dsrs => {
      let dsrArray = [];
      dsrs.forEach(dsr => {
        dsrArray.push(dsr.details);
      });
      this.dsrEmployees = dsrArray;
    });
  } // async openCalendar() {
  //   const options: CalendarModalOptions = {
  //     pickMode: 'range',
  //     title: 'RANGE',
  //     color:'dark'
  //   };
  //   const myCalendar = await this.modalCtrl.create({
  //     component: CalendarModal,
  //     componentProps: { options }
  //   });
  //   myCalendar.present();
  //   const event: any = await myCalendar.onDidDismiss();
  //   const date = event.data;
  //   const from: CalendarResult = date.from;
  //   const to: CalendarResult = date.to;
  //   console.log(date, from, to);
  //   this.date = from.string +" - "+to.string
  // }


  parseFloat(number) {
    return parseFloat(number).toFixed(2);
  }

  acceptTask(task) {
    task.status = 1;
    this.tasksService.updateTask(task).then(resp => {});
  }

  approveAllUserDSR(employee) {
    employee.task.forEach(task => {
      task.status = 1;
      this.tasksService.updateTask(task).then(resp => {});
    });
  }

  dateChange(ev) {
    let that = this;
    setTimeout(() => {
      that.getDSR(this.teamEmployees);
    }, 500);
  }

  rejectTask(task) {
    task.status = 2;
    this.tasksService.updateTask(task).then(resp => {});
  }

  previewFilterDSR() {
    var _this = this;

    return (0,_Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const popover = yield _this.modalCtrl.create({
        component: _pages_dsr_monthly_preview_dsr_monthly_preview_page__WEBPACK_IMPORTED_MODULE_7__.DsrMonthlyPreviewPage,
        cssClass: 'dsr-preview-modal',
        //    enterAnimation(baseEl) {
        //     const wrapperAnimation = createAnimation()
        //     .beforeStyles({
        //       transform: 'translateY(0) scale(1)'
        //     })
        //     .addElement(baseEl.shadowRoot.querySelector('.modal-wrapper'));
        //   return createAnimation()
        //     .addElement(baseEl)
        //     .duration(250)
        //     .fromTo('opacity', '0', '1')
        //     .addAnimation([wrapperAnimation]);
        // },
        showBackdrop: true
      });
      yield popover.present();
    })();
  }

};

DsrComponent.ctorParameters = () => [{
  type: _services_auth_service__WEBPACK_IMPORTED_MODULE_6__.AuthService
}, {
  type: _services_tasks_service__WEBPACK_IMPORTED_MODULE_4__.TasksService
}, {
  type: _services_project_service__WEBPACK_IMPORTED_MODULE_5__.ProjectService
}, {
  type: _services_common_service__WEBPACK_IMPORTED_MODULE_3__.CommonService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ModalController
}];

DsrComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
  selector: 'app-dsr',
  template: _dsr_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_dsr_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], DsrComponent);


/***/ }),

/***/ 3582:
/*!***********************************************************!*\
  !*** ./src/app/components/view-dsr/view-dsr.component.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ViewDsrComponent": () => (/* binding */ ViewDsrComponent)
/* harmony export */ });
/* harmony import */ var _Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _view_dsr_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./view-dsr.component.html?ngResource */ 3270);
/* harmony import */ var _view_dsr_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./view-dsr.component.scss?ngResource */ 4851);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/common.service */ 5620);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_tasks_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/tasks.service */ 2632);
/* harmony import */ var _services_project_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/project.service */ 354);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/auth.service */ 7556);
/* harmony import */ var _pages_dsr_monthly_preview_dsr_monthly_preview_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../pages/dsr-monthly-preview/dsr-monthly-preview.page */ 310);











let ViewDsrComponent = class ViewDsrComponent {
  constructor(authService, tasksService, projectService, commonService, modalCtrl) {
    this.authService = authService;
    this.tasksService = tasksService;
    this.projectService = projectService;
    this.commonService = commonService;
    this.modalCtrl = modalCtrl;
    this.status = "1";
    this.dsrEmployees = [];
    this.employees = [];
    this.teams = [];
    this.teamEmployees = [];
    this.permissionViewAllDSR = false;
  }

  ngOnInit() {
    this.toDate = this.commonService.formatDate(new Date());
    this.fromDate = this.commonService.formatDate(new Date());
    this.authService.userLogin.subscribe(resp => {
      this.projectService.getTeamsReporting().then(resp => {
        this.teams = resp;
        this.selectedTeam = resp[0].teamId;
        this.teamEmployees = resp[0].users;
        this.getDSR(resp[0].users);
        this.permissionViewAllDSR = resp.permissions.ViewAllDSR;
        this.commonService.fetchAllTeams().then(resp => {
          if (this.permissionViewAllDSR) {
            this.teams = resp;
            this.selectedTeam = resp[0].teamId;
            this.teamEmployees = resp[0].users;
            this.getDSR(resp[0].users);
          }
        });
      });
    });
  }

  teamChanged(event) {
    let selectedTeams = this.teams.filter(t => this.selectedTeam.indexOf(t.teamId) != -1);
    let employees = [];
    selectedTeams.forEach(team => {
      employees = employees.concat(team.users);
    });
    employees = employees.filter((item, index) => {
      return employees.indexOf(item) == index;
    });
    this.teamEmployees = employees;
    this.getDSR(employees);
  }

  getDSR(employees) {
    this.commonService.getDSR({
      employeeId: employees,
      from: this.fromDate,
      to: this.toDate
    }).then(dsrs => {
      let dsrArray = [];
      dsrs.forEach(dsr => {
        dsrArray.push(dsr.details);
      });
      this.dsrEmployees = dsrArray;
    });
  } // async openCalendar() {
  //   const options: CalendarModalOptions = {
  //     pickMode: 'range',
  //     title: 'RANGE',
  //     color:'dark'
  //   };
  //   const myCalendar = await this.modalCtrl.create({
  //     component: CalendarModal,
  //     componentProps: { options }
  //   });
  //   myCalendar.present();
  //   const event: any = await myCalendar.onDidDismiss();
  //   const date = event.data;
  //   const from: CalendarResult = date.from;
  //   const to: CalendarResult = date.to;
  //   console.log(date, from, to);
  //   this.date = from.string +" - "+to.string
  // }


  parseFloat(number) {
    return parseFloat(number).toFixed(2);
  }

  acceptTask(task) {
    task.status = 1;
    this.tasksService.updateTask(task).then(resp => {});
  }

  dateChange(ev) {
    let that = this;
    setTimeout(() => {
      that.getDSR(this.teamEmployees);
    }, 500);
  }

  rejectTask(task) {
    task.status = 2;
    this.tasksService.updateTask(task).then(resp => {});
  }

  previewFilterDSR() {
    var _this = this;

    return (0,_Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const popover = yield _this.modalCtrl.create({
        component: _pages_dsr_monthly_preview_dsr_monthly_preview_page__WEBPACK_IMPORTED_MODULE_7__.DsrMonthlyPreviewPage,
        cssClass: 'dsr-preview-modal',
        //    enterAnimation(baseEl) {
        //     const wrapperAnimation = createAnimation()
        //     .beforeStyles({
        //       transform: 'translateY(0) scale(1)'
        //     })
        //     .addElement(baseEl.shadowRoot.querySelector('.modal-wrapper'));
        //   return createAnimation()
        //     .addElement(baseEl)
        //     .duration(250)
        //     .fromTo('opacity', '0', '1')
        //     .addAnimation([wrapperAnimation]);
        // },
        showBackdrop: true
      });
      yield popover.present();
    })();
  }

};

ViewDsrComponent.ctorParameters = () => [{
  type: _services_auth_service__WEBPACK_IMPORTED_MODULE_6__.AuthService
}, {
  type: _services_tasks_service__WEBPACK_IMPORTED_MODULE_4__.TasksService
}, {
  type: _services_project_service__WEBPACK_IMPORTED_MODULE_5__.ProjectService
}, {
  type: _services_common_service__WEBPACK_IMPORTED_MODULE_3__.CommonService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ModalController
}];

ViewDsrComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
  selector: 'app-view-dsr',
  template: _view_dsr_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_view_dsr_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], ViewDsrComponent);


/***/ }),

/***/ 9366:
/*!*************************************************************!*\
  !*** ./src/app/pages/dashboard/dashboard-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DashboardPageRoutingModule": () => (/* binding */ DashboardPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _dashboard_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dashboard.page */ 6446);




const routes = [
    {
        path: '',
        component: _dashboard_page__WEBPACK_IMPORTED_MODULE_0__.DashboardPage
    }
];
let DashboardPageRoutingModule = class DashboardPageRoutingModule {
};
DashboardPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], DashboardPageRoutingModule);



/***/ }),

/***/ 1659:
/*!*****************************************************!*\
  !*** ./src/app/pages/dashboard/dashboard.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DashboardPageModule": () => (/* binding */ DashboardPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _dashboard_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dashboard-routing.module */ 9366);
/* harmony import */ var _components_dsr_dsr_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../components/dsr/dsr.component */ 4792);
/* harmony import */ var _components_view_dsr_view_dsr_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../components/view-dsr/view-dsr.component */ 3582);
/* harmony import */ var _dashboard_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./dashboard.page */ 6446);









let DashboardPageModule = class DashboardPageModule {
};
DashboardPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _dashboard_routing_module__WEBPACK_IMPORTED_MODULE_0__.DashboardPageRoutingModule
        ],
        declarations: [_dashboard_page__WEBPACK_IMPORTED_MODULE_3__.DashboardPage, _components_dsr_dsr_component__WEBPACK_IMPORTED_MODULE_1__.DsrComponent, _components_view_dsr_view_dsr_component__WEBPACK_IMPORTED_MODULE_2__.ViewDsrComponent]
    })
], DashboardPageModule);



/***/ }),

/***/ 6446:
/*!***************************************************!*\
  !*** ./src/app/pages/dashboard/dashboard.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DashboardPage": () => (/* binding */ DashboardPage)
/* harmony export */ });
/* harmony import */ var _Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _dashboard_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dashboard.page.html?ngResource */ 3890);
/* harmony import */ var _dashboard_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./dashboard.page.scss?ngResource */ 7791);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/common.service */ 5620);
/* harmony import */ var _services_project_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/project.service */ 354);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/auth.service */ 7556);
/* harmony import */ var _pages_feedback_feedback_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../pages/feedback/feedback.page */ 1106);
/* harmony import */ var _pages_new_post_new_post_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../pages/new-post/new-post.page */ 8604);
/* harmony import */ var _services_dashboard_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../services/dashboard.service */ 9386);













let DashboardPage = class DashboardPage {
  constructor(authService, projectService, commonService, dashboardService, modalController, router) {
    this.authService = authService;
    this.projectService = projectService;
    this.commonService = commonService;
    this.dashboardService = dashboardService;
    this.modalController = modalController;
    this.router = router;
    this.daysInWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    this.segment = 'home';
    this.isReportingManager = 0;
    this.posts = [];
    this.getNearbyPosts = false;
    this.checkedNearbyPosts = false;
    this.allProjects = [];
    this.newsFeed = [];
    this.quote = {};
    this.name = [{
      employeeName: 'Aniket'
    }, {
      employeeName: 'Sonali'
    }, {
      employeeName: 'Parul'
    }, {
      employeeName: 'Vikash'
    }, {
      employeeName: 'Faisal'
    }];
    this.project = [{
      projectName: 'Hr Portal',
      progress: 0.3,
      teamName: 'Development Team'
    }, {
      projectName: 'The Meet',
      progress: 0.8,
      teamName: 'Sales Team'
    }];
    this.permissionViewAllDSR = false;
  }

  ngOnInit() {
    this.today = new Date();
    this.taskDate = this.commonService.formatDate(new Date());
    this.authService.getRandomQuote().then(resp => {
      this.quote = resp;
    });
    this.authService.userLogin.subscribe(resp => {
      if (resp && Object.keys(resp).length > 0) {
        this.permissionViewAllDSR = resp.permissions.ViewAllDSR;
        console.log(resp);
        this.getAllProjects();
        this.projectService.getTeamsReporting().then(resp => {
          this.isReportingManager = resp.length;
        });
        this.getAllPost();
      }
    });
    this.authService.getNewsFeed().then(resp => {
      // console.log("  getNewsFeed", resp)
      this.newsFeed = resp;
    });
  }

  getAllPost() {
    this.dashboardService.getAllPost().then(resp => {
      this.posts = resp;
    });
  }

  presentPopover() {
    var _this = this;

    return (0,_Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const popover = yield _this.modalController.create({
        component: _pages_feedback_feedback_page__WEBPACK_IMPORTED_MODULE_6__.FeedbackPage,
        cssClass: 'setting-modal',
        //    enterAnimation(baseEl) {
        //     const wrapperAnimation = createAnimation()
        //     .beforeStyles({
        //       transform: 'translateY(0) scale(1)'
        //     })
        //     .addElement(baseEl.shadowRoot.querySelector('.modal-wrapper'));
        //   return createAnimation()
        //     .addElement(baseEl)
        //     .duration(250)
        //     .fromTo('opacity', '0', '1')
        //     .addAnimation([wrapperAnimation]);
        // },
        showBackdrop: true
      });
      yield popover.present();
    })();
  }

  createNewPost() {
    var _this2 = this;

    return (0,_Users_chandrasingh_Projects_HrPortal_HrApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const popover = yield _this2.modalController.create({
        component: _pages_new_post_new_post_page__WEBPACK_IMPORTED_MODULE_7__.NewPostPage,
        cssClass: 'setting-modal',
        //    enterAnimation(baseEl) {
        //     const wrapperAnimation = createAnimation()
        //     .beforeStyles({
        //       transform: 'translateY(0) scale(1)'
        //     })
        //     .addElement(baseEl.shadowRoot.querySelector('.modal-wrapper'));
        //   return createAnimation()
        //     .addElement(baseEl)
        //     .duration(250)
        //     .fromTo('opacity', '0', '1')
        //     .addAnimation([wrapperAnimation]);
        // },
        showBackdrop: true
      });
      popover.onDidDismiss().then(post => {
        console.log(" onDidDismiss ", post.data.post);

        _this2.posts.unshift(post.data.post);
      });
      yield popover.present();
    })();
  }

  getDayOfWeek(taskDate) {
    let date = new Date(taskDate);
    let day = date.getDay();
    return this.daysInWeek[day];
  }

  getAllProjects() {
    this.projectService.getMemberProjects().then(resp => {
      // console.log("fetchAllProjects",resp)
      this.allProjects = resp; // console.log("response from getEmployee",this.allProjects)
    });
  }

  logout() {
    localStorage.clear();
    this.router.navigate(['/login']);
  }

};

DashboardPage.ctorParameters = () => [{
  type: _services_auth_service__WEBPACK_IMPORTED_MODULE_5__.AuthService
}, {
  type: _services_project_service__WEBPACK_IMPORTED_MODULE_4__.ProjectService
}, {
  type: _services_common_service__WEBPACK_IMPORTED_MODULE_3__.CommonService
}, {
  type: _services_dashboard_service__WEBPACK_IMPORTED_MODULE_8__.DashboardService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.ModalController
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.Router
}];

DashboardPage = (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.Component)({
  selector: 'app-dashboard',
  template: _dashboard_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_12__.ViewEncapsulation.None,
  styles: [_dashboard_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], DashboardPage);


/***/ }),

/***/ 3514:
/*!**************************************************************!*\
  !*** ./src/app/components/dsr/dsr.component.scss?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkc3IuY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 4851:
/*!************************************************************************!*\
  !*** ./src/app/components/view-dsr/view-dsr.component.scss?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ2aWV3LWRzci5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 7791:
/*!****************************************************************!*\
  !*** ./src/app/pages/dashboard/dashboard.page.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = ".projects ion-item {\n  --background: #161b22;\n}\n\n#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n\nion-toolbar {\n  --background: #ddecf1;\n  background-color: #ddecf1;\n}\n\n.quote {\n  padding: 20px;\n  font-size: 15px;\n  font-weight: 100;\n  font-style: italic;\n}\n\n.newPost ion-item {\n  --background: #0d1116;\n}\n\n.diag {\n  position: absolute;\n  z-index: 1;\n  top: 0;\n  height: 76%;\n  text-align: center;\n  top: 20%;\n}\n\n.chatPage {\n  position: absolute;\n  top: 25px;\n  left: 140px;\n  color: #ccc;\n  font-size: 18px;\n  text-transform: capitalize;\n}\n\n.chatBackground {\n  background-size: cover;\n}\n\n.text-input-md,\n.text-input-ios {\n  text-align: left !important;\n  font-size: 17px;\n}\n\n.list-header-md,\n.list-header-ios {\n  padding-left: 16px;\n  margin-bottom: 13px;\n  min-height: 4.5rem;\n  border-top: 1px solid #dedede;\n  font-size: 2.4rem;\n  color: #fff;\n  background: transparent;\n}\n\n.label-md,\n.label-ios {\n  margin: 0px !important;\n}\n\n.item-md,\n.item-ios {\n  margin-top: -13px !important;\n}\n\n.item-md.item-block .item-inner,\n.item-ios.item-block .item-inner {\n  border: none;\n}\n\nion-footer {\n  position: sticky;\n  bottom: 0;\n}\n\nbutton {\n  background: transparent;\n  font-size: 33px;\n}\n\nion-refresher ion-refresher-content {\n  background: #000;\n  --color: #FFF !important;\n}\n\n.container {\n  width: 100%;\n  margin: 0 auto;\n  margin-top: 30%;\n  display: block;\n  position: fixed;\n  vertical-align: middle;\n  text-align: center;\n}\n\n.container img {\n  object-fit: cover;\n}\n\nion-card {\n  --background: #161b22;\n  box-shadow: 1px 1px 4px 0px rgba(0, 0, 0, 0.5);\n  margin: 10px 20px;\n}\n\n.postDescription {\n  color: #ccc;\n  margin: 10px 20px;\n  padding-left: 53px;\n  overflow: hidden;\n  padding-bottom: 10px;\n  border-radius: 10px;\n  font-size: 16px;\n  margin-top: -20px;\n}\n\n.postDescription img {\n  border-radius: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRhc2hib2FyZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxxQkFBQTtBQUNGOztBQUVBO0VBQ0Usa0JBQUE7RUFDQSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsUUFBQTtFQUNBLDJCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7QUFDRjs7QUFFQTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxTQUFBO0FBQ0Y7O0FBRUE7RUFDRSxxQkFBQTtBQUNGOztBQUVBO0VBQ0UscUJBQUE7RUFDQSx5QkFBQTtBQUNGOztBQUlBO0VBQ0UsYUFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0FBREY7O0FBSUE7RUFDRSxxQkFBQTtBQURGOztBQVNBO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0VBRUEsTUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7QUFQRjs7QUFVQTtFQUNFLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLDBCQUFBO0FBUEY7O0FBVUE7RUFFRSxzQkFBQTtBQVJGOztBQVdBOztFQUVFLDJCQUFBO0VBQ0EsZUFBQTtBQVJGOztBQVdBOztFQUVFLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLDZCQUFBO0VBQ0EsaUJBQUE7RUFDQSxXQUFBO0VBQ0EsdUJBQUE7QUFSRjs7QUFXQTs7RUFFRSxzQkFBQTtBQVJGOztBQVdBOztFQUVFLDRCQUFBO0FBUkY7O0FBV0E7O0VBRUUsWUFBQTtBQVJGOztBQVdBO0VBQ0UsZ0JBQUE7RUFDQSxTQUFBO0FBUkY7O0FBV0E7RUFDRSx1QkFBQTtFQUNBLGVBQUE7QUFSRjs7QUFXQTtFQUNFLGdCQUFBO0VBQ0Esd0JBQUE7QUFSRjs7QUFXQTtFQUVFLFdBQUE7RUFFQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtBQVZGOztBQWFBO0VBSUUsaUJBQUE7QUFaRjs7QUFvQkE7RUFDRSxxQkFBQTtFQUVBLDhDQUFBO0VBQ0EsaUJBQUE7QUFsQkY7O0FBMkJBO0VBQ0UsV0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUtBLG9CQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUE1QkY7O0FBOEJFO0VBQ0UsbUJBQUE7QUE1QkoiLCJmaWxlIjoiZGFzaGJvYXJkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5wcm9qZWN0cyBpb24taXRlbSB7XG4gIC0tYmFja2dyb3VuZDogIzE2MWIyMjtcbn1cblxuI2NvbnRhaW5lciB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiAwO1xuICByaWdodDogMDtcbiAgdG9wOiA1MCU7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNTAlKTtcbn1cblxuI2NvbnRhaW5lciBzdHJvbmcge1xuICBmb250LXNpemU6IDIwcHg7XG4gIGxpbmUtaGVpZ2h0OiAyNnB4O1xufVxuXG4jY29udGFpbmVyIHAge1xuICBmb250LXNpemU6IDE2cHg7XG4gIGxpbmUtaGVpZ2h0OiAyMnB4O1xuICBjb2xvcjogIzhjOGM4YztcbiAgbWFyZ2luOiAwO1xufVxuXG4jY29udGFpbmVyIGEge1xuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG59XG5cbmlvbi10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjZGRlY2YxO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZGRlY2YxO1xuICAvLyAtLWJhY2tncm91bmQ6ICNmZmY7XG4gIC8vIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG59XG5cbi5xdW90ZSB7XG4gIHBhZGRpbmc6IDIwcHg7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgZm9udC13ZWlnaHQ6IDEwMDtcbiAgZm9udC1zdHlsZTogaXRhbGljO1xufVxuXG4ubmV3UG9zdCBpb24taXRlbSB7XG4gIC0tYmFja2dyb3VuZDogIzBkMTExNjtcbn1cblxuLy8gaW9uLXRvb2xiYXIge1xuLy8gLS1iYWNrZ3JvdW5kOiByZWQ7XG4vLyAtLWlvbi1jb2xvci1iYXNlOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xuLy8gfVxuXG4uZGlhZyB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgei1pbmRleDogMTtcbiAgLy8gd2lkdGg6IGNhbGMoMTAwJSAtIDM0cHgpO1xuICB0b3A6IDA7XG4gIGhlaWdodDogNzYlO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHRvcDogMjAlO1xufVxuXG4uY2hhdFBhZ2Uge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMjVweDtcbiAgbGVmdDogMTQwcHg7XG4gIGNvbG9yOiAjY2NjO1xuICBmb250LXNpemU6IDE4cHg7XG4gIHRleHQtdHJhbnNmb3JtOiBjYXBpdGFsaXplO1xufVxuXG4uY2hhdEJhY2tncm91bmQge1xuICAvLyBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoYXNzZXRzL2ltZ3MvY2hhdGJnLmpwZyk7XG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG59XG5cbi50ZXh0LWlucHV0LW1kLFxuLnRleHQtaW5wdXQtaW9zIHtcbiAgdGV4dC1hbGlnbjogbGVmdCAhaW1wb3J0YW50O1xuICBmb250LXNpemU6IDE3cHg7XG59XG5cbi5saXN0LWhlYWRlci1tZCxcbi5saXN0LWhlYWRlci1pb3Mge1xuICBwYWRkaW5nLWxlZnQ6IDE2cHg7XG4gIG1hcmdpbi1ib3R0b206IDEzcHg7XG4gIG1pbi1oZWlnaHQ6IDQuNXJlbTtcbiAgYm9yZGVyLXRvcDogMXB4IHNvbGlkICNkZWRlZGU7XG4gIGZvbnQtc2l6ZTogMi40cmVtO1xuICBjb2xvcjogI2ZmZjtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG59XG5cbi5sYWJlbC1tZCxcbi5sYWJlbC1pb3Mge1xuICBtYXJnaW46IDBweCAhaW1wb3J0YW50O1xufVxuXG4uaXRlbS1tZCxcbi5pdGVtLWlvcyB7XG4gIG1hcmdpbi10b3A6IC0xM3B4ICFpbXBvcnRhbnQ7XG59XG5cbi5pdGVtLW1kLml0ZW0tYmxvY2sgLml0ZW0taW5uZXIsXG4uaXRlbS1pb3MuaXRlbS1ibG9jayAuaXRlbS1pbm5lciB7XG4gIGJvcmRlcjogbm9uZTtcbn1cblxuaW9uLWZvb3RlciB7XG4gIHBvc2l0aW9uOiBzdGlja3k7XG4gIGJvdHRvbTogMDtcbn1cblxuYnV0dG9uIHtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIGZvbnQtc2l6ZTogMzNweDtcbn1cblxuaW9uLXJlZnJlc2hlciBpb24tcmVmcmVzaGVyLWNvbnRlbnQge1xuICBiYWNrZ3JvdW5kOiAjMDAwO1xuICAtLWNvbG9yOiAjRkZGICFpbXBvcnRhbnQ7XG59XG5cbi5jb250YWluZXIge1xuICAvLyB3aWR0aDogMzAwcHg7XG4gIHdpZHRoOiAxMDAlO1xuICAvLyBoZWlnaHQ6IDEwMCU7XG4gIG1hcmdpbjogMCBhdXRvO1xuICBtYXJnaW4tdG9wOiBjYWxjKDMwJSk7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmNvbnRhaW5lciBpbWcge1xuICAvLyBoZWlnaHQ6IDEwMCU7XG4gIC8vIHdpZHRoOiAxMDAlO1xuICAtby1vYmplY3QtZml0OiBjb3ZlcjtcbiAgb2JqZWN0LWZpdDogY292ZXI7XG59XG5cbi8vIGlvbi1zZWdtZW50LWJ1dHRvbiB7XG4vLyAtLWNvbG9yLWNoZWNrZWQ6ICMwMDA7XG4vLyAtLWNvbG9yLWZvY3VzZWQ6ICMwMDA7XG4vLyB9XG5cbmlvbi1jYXJkIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMTYxYjIyO1xuICAvLyAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICBib3gtc2hhZG93OiAxcHggMXB4IDRweCAwcHggcmdiYSgwLCAwLCAwLCAwLjUpO1xuICBtYXJnaW46IDEwcHggMjBweDtcblxufVxuXG4vLyBpb24tc2VnbWVudC1idXR0b24ge1xuLy8gICAgIHdpZHRoOiAxMDBweDtcbi8vICAgLS1jb2xvci1jaGVja2VkOiAjMDAwO1xuLy8gICBmb250LXdlaWdodDogYm9sZDtcbi8vIH1cbi5wb3N0RGVzY3JpcHRpb24ge1xuICBjb2xvcjogI2NjYztcbiAgbWFyZ2luOiAxMHB4IDIwcHg7XG4gIHBhZGRpbmctbGVmdDogNTNweDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgLy8gdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gIC8vIGRpc3BsYXk6IC13ZWJraXQtYm94O1xuICAvLyAtd2Via2l0LWxpbmUtY2xhbXA6IDM7XG4gIC8vIC13ZWJraXQtYm94LW9yaWVudDogdmVydGljYWw7XG4gIHBhZGRpbmctYm90dG9tOiAxMHB4O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBmb250LXNpemU6IDE2cHg7XG4gIG1hcmdpbi10b3A6IC0yMHB4O1xuXG4gIGltZyB7XG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgfVxufSJdfQ== */";

/***/ }),

/***/ 2496:
/*!**************************************************************!*\
  !*** ./src/app/components/dsr/dsr.component.html?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "<div style=\"padding: 20px;\">\n  <!-- <ion-toolbar color=\"gray\">\n      <ion-title>Daily Status Reports</ion-title>\n    </ion-toolbar> -->\n  <ion-toolbar color=\"gray\">\n    <ion-searchbar placeholder=\"Search Employee\"></ion-searchbar>\n  </ion-toolbar>\n  <ion-toolbar color=\"gray\" style=\"border-top: 0px solid #3f4040;border-bottom: 0px solid #3f4040;\">\n    <ion-row>\n      <ion-col size=\"2\" style=\"border-right: 1px solid rgb(37 38 40);\n        background-color: transparent;\n        padding: 0px;\">\n        <ion-item lines=\"none\">\n          <ion-select placeholder=\"Select team\" [(ngModel)]=\"status\" (ngModelChange)=\"statusChanged($event)\" style=\"color: #fff;width: 100%;\" multiple>\n            <!-- <ion-select-option style=\"color: #fff;font-weight: bold;\" value=\"1\">All Teams</ion-select-option> -->\n            <ion-select-option style=\"color: #fff;font-weight: bold;\" value=\"0\">New</ion-select-option>\n            <ion-select-option style=\"color: #fff;font-weight: bold;\" value=\"1\">Accepted</ion-select-option>\n            <ion-select-option style=\"color: #fff;font-weight: bold;\" value=\"2\">Rejected</ion-select-option>\n          </ion-select>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"4.5\" style=\"border-right: 1px solid rgb(37 38 40);\n        background-color: transparent;\n        padding: 0px;\">\n        <ion-item lines=\"none\">\n          <ion-select placeholder=\"Select team\" [(ngModel)]=\"selectedTeam\" (ngModelChange)=\"teamChanged($event)\"\n            style=\"color: #fff;width: 100%;\" multiple>\n            <ion-select-option *ngFor=\"let team of teams\" style=\"color: #fff;font-weight: bold;\" [value]=\"team.teamId\">\n              {{team.teamName}}</ion-select-option>\n          </ion-select>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"1.5\" style=\"border-right: 1px solid rgb(37 38 40);\n        background-color: transparent;\n        padding: 0px;\">\n        <ion-item lines=\"none\">\n          <ion-button fill=\"clear\" color=\"dark\" expand=\"block\" (click)=\"previewFilterDSR()\">\n            <ion-icon slot=\"start\" name=\"calendar-outline\"></ion-icon>\n            <ion-label>Preview</ion-label>\n          </ion-button>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"1.5\" style=\"border: 0px solid rgb(37 38 40);\n        background-color: transparent;\n        padding: 0px;\">\n        <ion-item lines=\"none\">\n          <!-- <ion-button (click)=\"openCalendar()\" expand=\"block\" fill=\"clear\" color=\"light\">\n              {{date}}\n            </ion-button> -->\n          <ion-input [(ngModel)]=\"toDate\" (change)=\"dateChange($event)\" type=\"date\"\n            style=\"color: #ccc;font-weight: bold;\">\n          </ion-input>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"1\" style=\"text-align: center;line-height: 34px;\">\n        <div>\n          to\n        </div>\n      </ion-col>\n      <ion-col size=\"1.5\" style=\"border: 0px solid rgb(37 38 40);\n        background-color: transparent;\n        padding: 0px;\">\n        <ion-item lines=\"none\">\n          <!-- <ion-button (click)=\"openCalendar()\" expand=\"block\" fill=\"clear\" color=\"light\">\n              {{date}}\n            </ion-button> -->\n          <ion-input [(ngModel)]=\"fromDate\" (change)=\"dateChange($event)\" type=\"date\"\n            style=\"color: #ccc;font-weight: bold;\">\n          </ion-input>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n  </ion-toolbar>\n\n  <ion-accordion-group *ngFor=\"let employee of dsrEmployees\" value=\"first\" style=\"margin-bottom: 10px;\">\n    <ion-accordion value=\"first\" style=\"border: 1px solid #494a4a !important;\">\n      <ion-item slot=\"header\" lines=\"none\">\n        <ion-avatar slot=\"start\">\n          <img [src]=\"employee.image\">\n        </ion-avatar>\n        <!-- <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373;\" slot=\"start\" name=\"close-circle-outline\"></ion-icon> -->\n        <!-- <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon> -->\n        <ion-label style=\"font-size: 18px !important;\">{{employee.firstName}} {{employee.lastName}}</ion-label>\n        <ion-button slot=\"end\" fill=\"outline\" style=\"\" color=\"success\" (click)=\"approveAllUserDSR(employee)\">\n          <ion-icon slot=\"start\" name=\"checkmark-done\" slot=\"icon-only\"></ion-icon>\n          <ion-label slot=\"end\"> Approve all</ion-label>\n        </ion-button>\n      </ion-item>\n      <div class=\"ion-padding\" slot=\"content\" class=\"expandedDSR\">\n        <ion-item lines=\"none\" class=\"ion-text-wrap\" *ngFor=\"let task of employee.task;let i = index;\">\n          <ion-note slot=\"start\" style=\"font-weight: 300;font-size: 12px;\">\n            {{i+1}}\n          </ion-note>\n          <ion-button slot=\"start\" (click)=\"rejectTask(task)\" fill=\"clear\" style=\"padding: 0px;text-align:center;font-size: 16px;margin: 0px;\">\n            <ion-icon [color]=\"task.status == 2 ? \n              'danger' : 'dark'\" name=\"close-circle-outline\" slot=\"icon-only\"></ion-icon>\n          </ion-button>\n          <ion-button slot=\"start\" (click)=\"acceptTask(task)\" fill=\"clear\" style=\"padding: 0px;text-align:center;font-size: 16px;margin: 0px;\">\n            <ion-icon [color]=\"task.status == 1 ? \n            'success' : 'dark'\" name=\"checkmark-circle-outline\" slot=\"icon-only\"></ion-icon>\n          </ion-button>\n          <ion-label class=\"ion-text-wrap\">{{task.taskName}}</ion-label>\n          <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;text-align: right;\">\n            SpotYourDeal <br> {{parseFloat(task.hours || 0)}} hrs\n          </ion-note>\n          <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;\">\n            {{task.from | date:'HH:mm a'}} - {{task.to | date:'HH:mm a'}} <br> {{task.date | date:'dd MMM, yyyy'}}\n          </ion-note>\n        </ion-item>\n        <!-- <ion-item lines=\"none\">\n            <ion-note slot=\"start\" style=\"font-weight: 300;font-size: 12px;\">\n              2\n            </ion-note>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;\" slot=\"start\" name=\"close-circle-outline\"></ion-icon>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon>\n            <ion-label>Chat message date not showing</ion-label>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;text-align: right;\">\n              iDMX <br> 2 hrs\n            </ion-note>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;\">\n              1:30 PM - 4:30 PM <br> 2 Aug, 2022\n            </ion-note>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-note slot=\"start\" style=\"font-weight: 300;font-size: 12px;\">\n              3\n            </ion-note>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373;\" slot=\"start\" name=\"close-circle-outline\"></ion-icon>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon>\n            <ion-label>Feeds page not scrolling back to top when segment change</ion-label>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;text-align: right;\">\n              Hr Portal <br> 2 hrs\n            </ion-note>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;\">\n              1:30 PM - 4:30 PM <br> 2 Aug, 2022\n            </ion-note>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-note slot=\"start\" style=\"font-weight: 300;font-size: 12px;\">\n              4\n            </ion-note>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373;\" slot=\"start\" name=\"close-circle-outline\"></ion-icon>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon>\n            <ion-label>User chat not opening on receiving chat notification</ion-label>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;text-align: right;\">\n              SpotYourDeal <br> 2 hrs\n            </ion-note>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;\">\n              1:30 PM - 4:30 PM <br> 2 Aug, 2022\n            </ion-note>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-note slot=\"start\" style=\"font-weight: 300;font-size: 12px;\">\n              5\n            </ion-note>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373;\" slot=\"start\" name=\"close-circle-outline\"></ion-icon>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon>\n            <ion-label>Remove possible duplicate users</ion-label>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;text-align: right;\">\n              SpotYourDeal <br> 2 hrs\n            </ion-note>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;\">\n              1:30 PM - 4:30 PM <br> 2 Aug, 2022\n            </ion-note>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-note slot=\"start\" style=\"font-weight: 300;font-size: 12px;\">\n              6\n            </ion-note>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373;\" slot=\"start\" name=\"close-circle-outline\"></ion-icon>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon>\n            <ion-label>Blocked users cannot send message from anywhere</ion-label>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;text-align: right;\">\n              SpotYourDeal <br> 2 hrs\n            </ion-note>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;\">\n              1:30 PM - 4:30 PM <br> 2 Aug, 2022\n            </ion-note>\n          </ion-item> -->\n      </div>\n    </ion-accordion>\n  </ion-accordion-group>\n</div>";

/***/ }),

/***/ 3270:
/*!************************************************************************!*\
  !*** ./src/app/components/view-dsr/view-dsr.component.html?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = "\n  <div style=\"padding: 20px;\">\n    <!-- <ion-toolbar color=\"gray\">\n      <ion-title>Daily Status Reports</ion-title>\n    </ion-toolbar> -->\n    <ion-toolbar color=\"gray\">\n      <ion-searchbar placeholder=\"Search Employee\"></ion-searchbar>\n    </ion-toolbar>\n    <ion-toolbar color=\"gray\" style=\"border-top: 1px solid #3f4040;border-bottom: 1px solid #3f4040;\">\n      <ion-row>\n        <ion-col size=\"2\" style=\"border-right: 1px solid rgb(37 38 40);\n        background-color: transparent;\n        padding: 0px;\">\n          <ion-item lines=\"none\">\n            <ion-select placeholder=\"Select team\" [(ngModel)]=\"status\" style=\"color: #fff;width: 100%;\" multiple>\n              <!-- <ion-select-option style=\"color: #fff;font-weight: bold;\" value=\"1\">All Teams</ion-select-option> -->\n              <ion-select-option style=\"color: #fff;font-weight: bold;\" value=\"1\">New</ion-select-option>\n              <ion-select-option style=\"color: #fff;font-weight: bold;\" value=\"2\">Accepted</ion-select-option>\n              <ion-select-option style=\"color: #fff;font-weight: bold;\" value=\"3\">Rejected</ion-select-option>\n            </ion-select>\n          </ion-item>\n        </ion-col>\n        <ion-col size=\"4.5\" style=\"border-right: 1px solid rgb(37 38 40);\n        background-color: transparent;\n        padding: 0px;\">\n          <ion-item lines=\"none\">\n            <ion-select placeholder=\"Select team\" [(ngModel)]=\"selectedTeam\" (ngModelChange)=\"teamChanged($event)\" style=\"color: #fff;width: 100%;\" multiple>\n              <ion-select-option *ngFor=\"let team of teams\" style=\"color: #fff;font-weight: bold;\" [value]=\"team.teamId\">{{team.teamName}}</ion-select-option>\n            </ion-select>\n          </ion-item>\n        </ion-col>\n        <ion-col size=\"1.5\" style=\"border-right: 1px solid rgb(37 38 40);\n        background-color: transparent;\n        padding: 0px;\">\n          <ion-item lines=\"none\">\n            <ion-button fill=\"clear\" color=\"dark\" expand=\"block\" (click)=\"previewFilterDSR()\">\n              <ion-icon slot=\"start\" name=\"calendar-outline\"></ion-icon>\n              <ion-label>Preview</ion-label>\n            </ion-button>\n          </ion-item>\n        </ion-col>\n        <ion-col size=\"1.5\" style=\"border: 0px solid rgb(37 38 40);\n        background-color: transparent;\n        padding: 0px;\">\n          <ion-item lines=\"none\">\n            <!-- <ion-button (click)=\"openCalendar()\" expand=\"block\" fill=\"clear\" color=\"light\">\n              {{date}}\n            </ion-button> -->\n            <ion-input [(ngModel)]=\"toDate\" (change)=\"dateChange($event)\" type=\"date\" style=\"color: #ccc;font-weight: bold;\">\n            </ion-input>\n          </ion-item>\n        </ion-col>\n        <ion-col size=\"1\" style=\"text-align: center;line-height: 34px;\">\n        <div>\n          to\n        </div>\n        </ion-col>\n        <ion-col size=\"1.5\" style=\"border: 0px solid rgb(37 38 40);\n        background-color: transparent;\n        padding: 0px;\">\n          <ion-item lines=\"none\">\n            <!-- <ion-button (click)=\"openCalendar()\" expand=\"block\" fill=\"clear\" color=\"light\">\n              {{date}}\n            </ion-button> -->\n            <ion-input [(ngModel)]=\"fromDate\" (change)=\"dateChange($event)\" type=\"date\" style=\"color: #ccc;font-weight: bold;\">\n            </ion-input>\n          </ion-item>\n        </ion-col>\n      </ion-row>\n    </ion-toolbar>\n\n    <ion-accordion-group *ngFor=\"let employee of dsrEmployees\" style=\"margin-bottom: 5px;\">\n      <ion-accordion value=\"first\">\n        <ion-item slot=\"header\" lines=\"none\">\n          <ion-avatar slot=\"start\">\n            <img src=\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRFMEVXuFb_tRXt584wK0LUfXhUWC5XkZyvyHV5LZBi4xzkbd4RNT_gSxr_337y8fZUccw&usqp=CAU\">\n          </ion-avatar>\n          <!-- <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373;\" slot=\"start\" name=\"close-circle-outline\"></ion-icon> -->\n          <!-- <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon> -->\n          <ion-label style=\"font-size: 18px !important;\">{{employee.firstName}} {{employee.lastName}}</ion-label>\n        </ion-item>\n        <div class=\"ion-padding\" slot=\"content\" class=\"expandedDSR\">\n          <ion-item lines=\"none\" class=\"ion-text-wrap\" *ngFor=\"let task of employee.task;let i = index;\">\n            <ion-note slot=\"start\" style=\"font-weight: 300;font-size: 12px;\">\n              {{i+1}}\n            </ion-note>\n            <ion-icon (click)=\"rejectTask(task)\" style=\"margin-right: 10px;cursor: pointer;\"  \n            [color]=\"task.status == 2 ? \n            'danger' : 'light'\" slot=\"start\" name=\"close-circle-outline\"></ion-icon>\n            <ion-icon (click)=\"acceptTask(task)\" style=\"margin-right: 10px;cursor: pointer;\" \n            [color]=\"task.status == 1 ? \n            'success' : 'light'\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon>\n            <ion-label class=\"ion-text-wrap\">{{task.taskName}}</ion-label>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;text-align: right;\">\n              SpotYourDeal <br> {{parseFloat(task.hours)}} hrs\n            </ion-note>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;\">\n              {{task.from | date:'HH:mm a'}} - {{task.to | date:'HH:mm a'}} <br> {{task.date | date:'dd MMM, yyyy'}}\n            </ion-note>\n          </ion-item>\n          <!-- <ion-item lines=\"none\">\n            <ion-note slot=\"start\" style=\"font-weight: 300;font-size: 12px;\">\n              2\n            </ion-note>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;\" slot=\"start\" name=\"close-circle-outline\"></ion-icon>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon>\n            <ion-label>Chat message date not showing</ion-label>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;text-align: right;\">\n              iDMX <br> 2 hrs\n            </ion-note>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;\">\n              1:30 PM - 4:30 PM <br> 2 Aug, 2022\n            </ion-note>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-note slot=\"start\" style=\"font-weight: 300;font-size: 12px;\">\n              3\n            </ion-note>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373;\" slot=\"start\" name=\"close-circle-outline\"></ion-icon>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon>\n            <ion-label>Feeds page not scrolling back to top when segment change</ion-label>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;text-align: right;\">\n              Hr Portal <br> 2 hrs\n            </ion-note>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;\">\n              1:30 PM - 4:30 PM <br> 2 Aug, 2022\n            </ion-note>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-note slot=\"start\" style=\"font-weight: 300;font-size: 12px;\">\n              4\n            </ion-note>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373;\" slot=\"start\" name=\"close-circle-outline\"></ion-icon>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon>\n            <ion-label>User chat not opening on receiving chat notification</ion-label>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;text-align: right;\">\n              SpotYourDeal <br> 2 hrs\n            </ion-note>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;\">\n              1:30 PM - 4:30 PM <br> 2 Aug, 2022\n            </ion-note>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-note slot=\"start\" style=\"font-weight: 300;font-size: 12px;\">\n              5\n            </ion-note>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373;\" slot=\"start\" name=\"close-circle-outline\"></ion-icon>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon>\n            <ion-label>Remove possible duplicate users</ion-label>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;text-align: right;\">\n              SpotYourDeal <br> 2 hrs\n            </ion-note>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;\">\n              1:30 PM - 4:30 PM <br> 2 Aug, 2022\n            </ion-note>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-note slot=\"start\" style=\"font-weight: 300;font-size: 12px;\">\n              6\n            </ion-note>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373;\" slot=\"start\" name=\"close-circle-outline\"></ion-icon>\n            <ion-icon style=\"margin-right: 10px;cursor: pointer;color: #737373\"  slot=\"start\" name=\"checkmark-circle-outline\"></ion-icon>\n            <ion-label>Blocked users cannot send message from anywhere</ion-label>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;text-align: right;\">\n              SpotYourDeal <br> 2 hrs\n            </ion-note>\n            <ion-note slot=\"end\" style=\"font-weight: 300;font-size: 12px;\">\n              1:30 PM - 4:30 PM <br> 2 Aug, 2022\n            </ion-note>\n          </ion-item> -->\n        </div>\n      </ion-accordion>\n    </ion-accordion-group>\n  </div>\n";

/***/ }),

/***/ 3890:
/*!****************************************************************!*\
  !*** ./src/app/pages/dashboard/dashboard.page.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar color=\"gray\" mode=\"ios\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title style=\"text-transform: capitalize;\">{{segment}}</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"presentPopover()\">\n        <ion-icon name=\"chatbubbles-outline\"></ion-icon>\n      </ion-button>\n      <ion-button>\n        <ion-icon name=\"settings-outline\"></ion-icon>\n      </ion-button>\n      <ion-button (click)=\"logout()\">\n        <ion-icon color=\"danger\" name=\"log-out-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n\n  <!-- <ion-item lines=\"none\" (click)=\"logout()\" style=\"cursor: pointer;\">\n            <ion-label>Logout</ion-label>\n            <ion-icon name=\"log-out-outline\"></ion-icon>\n          </ion-item> -->\n  <!-- <ion-toolbar color=\"gray\" style=\"font-size:22px;padding: 0px 20px;\">\n  </ion-toolbar> -->\n  <ion-toolbar color=\"tertiary\">\n    <ion-segment [(ngModel)]=\"segment\" style=\"margin: 0;\">\n      <ion-segment-button value=\"home\">\n        <ion-text>\n          Home\n        </ion-text>\n      </ion-segment-button>\n      <ion-segment-button value=\"Team-DSR\" *ngIf=\"isReportingManager != 0\">\n        <ion-text>\n          DSR\n        </ion-text>\n      </ion-segment-button>\n      <ion-segment-button value=\"projects\">\n        <ion-text>\n          Projects\n        </ion-text>\n      </ion-segment-button>\n      <!-- <ion-segment-button value=\"teams\">\n        <ion-text>\n          Teams\n        </ion-text>\n      </ion-segment-button> -->\n      <!-- <ion-segment-button value=\"suspended\">\n        <ion-text>\n          Suspended\n        </ion-text>\n      </ion-segment-button> -->\n    </ion-segment>\n    <ion-label slot=\"end\" style=\"padding: 0px 10px;font-weight: bold;font-size: 17px;;\">\n      {{getDayOfWeek(today)}} {{today | date:'d MMMM, yyyy'}}\n    </ion-label>\n  </ion-toolbar>\n\n</ion-header>\n\n<ion-content>\n\n\n\n\n  <div *ngIf=\"segment == 'home'\">\n\n    <!-- <div class=\"quote\">\n      {{quote.content}}\n    </div> -->\n\n    <ion-row>\n      <!-- <ion-col size=\"4\" style=\"\">\n\n      </ion-col> -->\n      <ion-col size=\"8\" style=\"\">\n        <div style=\"font-size: 25px;background: #0d1116;padding-top: 10px !important;margin-bottom: -5px;margin-top: -10px;\" class=\"newPost\">\n          <ion-item class=\"messageBox\" lines=\"none\" style=\"padding-bottom: 0px;\" (click)=\"createNewPost()\">\n            <ion-label style=\"padding: 10px 20px;border: 1px solid #fff;border-radius: 20px;\">\n              <h2 style=\"color: #fff;font-size:16px;\">\n                Create new post..\n              </h2>\n            </ion-label>\n            <ion-icon slot=\"end\" name=\"images-outline\" color=\"dark\"></ion-icon>\n          </ion-item>\n        </div>\n        <ion-row *ngIf=\"posts.length == 0\">\n          <!-- <ion-row> -->\n          <div id=\"container\">\n            <img width=\"100px\" src=\"assets/loader.gif\" alt=\"\">\n          </div>\n        </ion-row>\n        <ion-card *ngFor=\"let post of posts\" style=\"padding-top: 10px;border: 0px solid rgb(97, 97, 97);\">\n          <ion-item class=\"messageBox\" lines=\"none\" style=\"padding: 0px;\">\n            <ion-avatar slot=\"start\"\n              style=\"height: 50px;width: 50px;padding: 0px;margin-left: -10px;margin-right: 12px;\">\n              <img [src]=\"post.image\">\n            </ion-avatar>\n            <ion-label>\n              <h2 style=\"color: #fff;font-weight:bold;text-transform: capitalize;\">\n                {{post.firstName}} {{post.lastName}}\n              </h2>\n              <p style=\"color: #848484;font-size: 14px;\">\n                {{post.designation}}\n              </p>\n            </ion-label>\n            <ion-icon slot=\"end\" name=\"ellipsis-vertical-outline\" style=\"font-size: 14px;\"></ion-icon>\n          </ion-item>\n          <div [innerHTML]=\"post.postDescription\"\n            class=\"postDescription\">\n            \n          </div>\n          <ion-row style=\"border-top: 0.5px solid #394351;\">\n            <ion-col size=\"12\" style=\"padding: 0px;\">\n              <ion-item lines=\"none\">\n                <ion-label style=\"text-align: right;\">{{post.createdAt | date:'hh:mm a dd MMM'}}</ion-label>\n                <!-- <ion-icon slot=\"start\" *ngIf=\"!post.userLiked\" name=\"heart-outline\"></ion-icon> -->\n                <ion-chip slot=\"start\">\n                  <ion-label>2</ion-label>\n                  <ion-icon name=\"heart-outline\" color=\"dark\"></ion-icon>\n                </ion-chip>\n                <!-- <ion-chip slot=\"start\">\n                  <ion-label>4</ion-label>\n                  <ion-icon name=\"chatbox-outline\" color=\"dark\"></ion-icon>\n                </ion-chip> -->\n              </ion-item>\n              <!-- <ion-button (click)=\"toggleLike(post)\" expand=\"block\" fill=\"clear\" style=\"height: 25px;\">\n                    <ion-icon *ngIf=\"!post.userLiked\" name=\"thumbs-up-outline\" color=\"dark\"></ion-icon>\n                    <ion-icon *ngIf=\"post.userLiked\" name=\"thumbs-up\" color=\"danger\"></ion-icon>\n                    <div style=\"color: #ccc;text-align: center;margin-top: -3px; padding-left: 5px;padding-top: 3px;\">{{post.likesCount}}</div>\n                  </ion-button> -->\n            </ion-col>\n            <!-- <ion-col size=\"4\" style=\"padding: 0px;\">\n                  <ion-button expand=\"block\" fill=\"clear\" style=\"height: 25px;\">\n                    <ion-icon name=\"chatbox-outline\" color=\"dark\"></ion-icon>\n                    <div style=\"color: #ccc;text-align: center;margin-top: -3px; padding-left: 5px;padding-top: 3px;\">{{post.commentsCount}}</div>\n                  </ion-button>\n                </ion-col>\n                <ion-col size=\"4\" style=\"padding: 0px;\">\n                  {{today | date:'hh:mm a'}}\n                </ion-col> -->\n          </ion-row>\n        </ion-card>\n\n\n        <!-- <ion-card>\n          <img src=\"https://edit.org/img/blog/yli-templates-employee-month-certificates-editable-online.jpg\" />\n        </ion-card> -->\n      </ion-col>\n      <ion-col size=\"4\">\n        <ion-item>\n          <ion-label style=\"padding: 10px 20px;\">\n            <h2 style=\"color: #fff;font-size:16px;\">\n              Latest News Headlines\n            </h2>\n          </ion-label>\n        </ion-item>\n        <div *ngFor=\"let news of newsFeed | slice:0:10\">\n          <ion-item>\n            <ion-thumbnail slot=\"start\"\n              style=\"height: 50px;width: 50px;padding: 0px;margin-left: -10px;margin-right: 12px;\">\n              <img [src]=\"news['media:thumbnail']['0']['$']['url']\">\n            </ion-thumbnail>\n            <ion-label class=\"ion-text-wrap\">\n              <ion-text>\n                <h2>{{news.title}}</h2>\n              </ion-text>\n              <ion-text color=\"dark\">\n                <p style=\"font-size: 12px;text-align: right;\"> {{news.pubDate | date:'hh:mm a dd MMM'}}</p>\n              </ion-text>\n            </ion-label>\n\n          </ion-item>\n          <!-- <ion-card style=\"border-bottom: 0px solid #fff;\">\n          </ion-card> -->\n        </div>\n\n        <!-- <div style=\"font-size: 25px;color: #ed3b95;padding-top: 10px !important;margin-bottom: -5px;\" class=\"newPost\">\n              <ion-item class=\"messageBox\" lines=\"none\" style=\"padding-bottom: 0px;background: #fff\">\n                <ion-label style=\"padding: 10px 20px;border: 1px solid #fff;border-radius: 20px;\">\n                  <h2 style=\"color: #fff;font-size:16px;\">\n                    Create new post..\n                  </h2>\n                </ion-label>\n                <ion-icon slot=\"end\" name=\"images-outline\" color=\"dark\"></ion-icon>\n              </ion-item>\n            </div>\n          \n\n            <ion-card *ngFor=\"let post of posts\" style=\"padding-top: 20px;border-bottom: 2px solid #fff;\">\n              <ion-item class=\"messageBox\" lines=\"none\" style=\"padding: 0px;\">\n                <ion-avatar slot=\"start\" style=\"height: 50px;width: 50px;padding: 0px;margin-left: -10px;margin-right: 12px;\">\n                  <img [src]=\"post.image\">\n                </ion-avatar>\n                <ion-label>\n                  <h2 style=\"color: #01bae8;font-weight:bold;text-transform: capitalize;\">\n                    {{post.name}}\n                  </h2>\n                  <p style=\"color: #585858;font-size: 12px;\">\n                  </p>\n                </ion-label>\n                <ion-icon slot=\"end\" name=\"ellipsis-vertical-outline\" color=\"pink\"></ion-icon>\n              </ion-item>\n              <div style=\"color: #ccc;margin: 10px 20px;padding-left: 53px;margin-top: -2px;overflow: hidden;text-overflow: ellipsis;display: -webkit-box;-webkit-line-clamp: 3;-webkit-box-orient: vertical;\">\n                {{post.text}}\n              </div>\n              <div style=\"text-align:center;padding-left: 73px;margin-top: -2px;padding-right: 10px;\">\n                <img style=\"max-height: 500px;border-radius: 10px;\" *ngIf=\"post.imageUrl\" [src]=\"post.imageUrl\">\n              </div>\n              <ion-row style=\"border-top: 0px solid #ccc;padding-left: 53px;padding-bottom: 10px ;\">\n                <ion-col size=\"4\" style=\"padding: 0px;\">\n                  <ion-button (click)=\"toggleLike(post)\" expand=\"block\" fill=\"clear\" style=\"height: 25px;\">\n                    <ion-icon *ngIf=\"!post.userLiked\" name=\"thumbs-up-outline\" color=\"dark\"></ion-icon>\n                    <ion-icon *ngIf=\"post.userLiked\" name=\"thumbs-up\" color=\"danger\"></ion-icon>\n                    <div style=\"color: #ccc;text-align: center;margin-top: -3px; padding-left: 5px;padding-top: 3px;\">{{post.likesCount}}</div>\n                  </ion-button>\n                </ion-col>\n                <ion-col size=\"4\" style=\"padding: 0px;\">\n                  <ion-button expand=\"block\" fill=\"clear\" style=\"height: 25px;\">\n                    <ion-icon name=\"chatbox-outline\" color=\"dark\"></ion-icon>\n                    <div style=\"color: #ccc;text-align: center;margin-top: -3px; padding-left: 5px;padding-top: 3px;\">{{post.commentsCount}}</div>\n                  </ion-button>\n                </ion-col>\n                <ion-col size=\"4\" style=\"padding: 0px;\">\n                </ion-col>\n              </ion-row>\n            </ion-card>\n       -->\n      </ion-col>\n    </ion-row>\n  </div>\n\n  <div *ngIf=\"segment == 'Team-DSR'\">\n    <app-dsr></app-dsr>\n  </div>\n  <div *ngIf=\"segment == 'projects'\">\n    <ion-grid>\n      <!-- <ion-item routerDirection=\"root\" lines=\"none\" detail=\"false\"\n        routerLinkActive=\"selected\">\n        <ion-label>Project</ion-label>\n      </ion-item> -->\n      <ion-row>\n\n        <ion-col sizeLg=\"12\" sizeMd=\"12\" sizeSm=\"12\" sizeXs=\"12\" *ngFor=\"let project of allProjects\">\n          <ion-list class=\"projects\" routerLink=\"/project-manage/{{project.projectId}}\">\n            <ion-item class=\"item\" lines=\"none\">\n              <ion-avatar slot=\"start\">\n                <ion-icon name=\"globe-outline\" style=\"font-size: 35px;color: rgb(160, 158, 158);\"></ion-icon>\n              </ion-avatar>\n              <ion-label style=\"color: #fff;font-size: 14px;font-weight: 500;\">{{project.projectName}}\n                <!-- <p style=\"color: rgb(146, 145, 145);font-size: 13px;\">Mckinsol</p> -->\n              </ion-label>\n              <!-- <div class=\"option1\">\n                      <ion-icon name=\"ellipsis-horizontal-outline\" style=\"font-size: 25px;color: rgb(160, 158, 158);\">\n                      </ion-icon>\n                    </div> -->\n            </ion-item>\n            <div>\n              <ion-row>\n                <ion-col size=\"4\" style=\"padding: 0px;\">\n                  <ion-item class=\"item\" lines=\"none\">\n                    <ion-label style=\"color: #fff;font-size: 14px;font-weight: 500;\">Billable Hrs\n                      <p style=\"color: rgb(146, 145, 145);font-size: 13px;\">224</p>\n                    </ion-label>\n                  </ion-item>\n                </ion-col>\n                <ion-col size=\"4\" style=\"padding: 0px;\">\n                  <ion-item class=\"item\" lines=\"none\">\n                    <ion-label style=\"color: #fff;font-size: 14px;font-weight: 500;\">Non Billable Hrs\n                      <p style=\"color: rgb(146, 145, 145);font-size: 13px;\">524</p>\n                    </ion-label>\n                  </ion-item>\n                </ion-col>\n                <ion-col size=\"4\" style=\"padding: 0px;\">\n                  <ion-item class=\"item\" lines=\"none\">\n                    <ion-label style=\"color: #fff;font-size: 14px;font-weight: 500;\">Total Hours\n                      <p style=\"color: rgb(146, 145, 145);font-size: 13px;\">867</p>\n                    </ion-label>\n                  </ion-item>\n                </ion-col>\n              </ion-row>\n            </div>\n            <!-- <ion-progress-bar value=\"0.2\" color=\"success\"></ion-progress-bar> -->\n          </ion-list>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </div>\n  <div *ngIf=\"segment == 'teams'\">\n    <ion-grid>\n      <!-- <ion-item routerDirection=\"root\" routerLink=\"/project-manage\" lines=\"none\" detail=\"false\"\n        routerLinkActive=\"selected\">\n        <ion-label>Teams</ion-label>\n      </ion-item> -->\n      <ion-row>\n\n        <ion-col sizeLg=\"12\" sizeMd=\"12\" sizeSm=\"12\" sizeXs=\"12\" *ngFor=\"let data of project\">\n          <ion-list class=\"projects\">\n            <ion-item class=\"item\" lines=\"none\">\n              <ion-avatar slot=\"start\">\n                <ion-icon name=\"globe-outline\" style=\"font-size: 35px;color: rgb(160, 158, 158);\"></ion-icon>\n              </ion-avatar>\n              <ion-label style=\"color: #fff;font-size: 14px;font-weight: 500;\">{{data.teamName}}\n              </ion-label>\n              <!-- <div class=\"option1\">\n                      <ion-icon name=\"ellipsis-horizontal-outline\" style=\"font-size: 25px;color: rgb(160, 158, 158);\">\n                      </ion-icon>\n                    </div> -->\n            </ion-item>\n            <div>\n              <ion-row>\n                <ion-col size=\"4\" style=\"padding: 0px;\">\n                  <ion-item class=\"item\" lines=\"none\">\n                    <ion-label style=\"color: #fff;font-size: 14px;font-weight: 500;\">test\n                      <p style=\"color: rgb(146, 145, 145);font-size: 13px;\">224 Hrs</p>\n                    </ion-label>\n                  </ion-item>\n                </ion-col>\n                <ion-col size=\"4\" style=\"padding: 0px;\">\n                  <ion-item class=\"item\" lines=\"none\">\n                    <ion-label style=\"color: #fff;font-size: 14px;font-weight: 500;\">test\n                      <p style=\"color: rgb(146, 145, 145);font-size: 13px;\">224 Hrs</p>\n                    </ion-label>\n                  </ion-item>\n                </ion-col>\n                <ion-col size=\"4\" style=\"padding: 0px;\">\n                  <ion-item class=\"item\" lines=\"none\">\n                    <ion-label style=\"color: #fff;font-size: 14px;font-weight: 500;\">test\n                      <p style=\"color: rgb(146, 145, 145);font-size: 13px;\">224 Hrs</p>\n                    </ion-label>\n                  </ion-item>\n                </ion-col>\n              </ion-row>\n            </div>\n          </ion-list>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </div>\n\n\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_dashboard_dashboard_module_ts.js.map