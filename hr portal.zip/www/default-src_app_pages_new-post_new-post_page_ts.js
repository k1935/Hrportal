"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_pages_new-post_new-post_page_ts"],{

/***/ 8604:
/*!*************************************************!*\
  !*** ./src/app/pages/new-post/new-post.page.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewPostPage": () => (/* binding */ NewPostPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _new_post_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./new-post.page.html?ngResource */ 6478);
/* harmony import */ var _new_post_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./new-post.page.scss?ngResource */ 9644);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/common.service */ 5620);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/auth.service */ 7556);
/* harmony import */ var _services_dashboard_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/dashboard.service */ 9386);
/* harmony import */ var _services_project_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/project.service */ 354);









let NewPostPage = class NewPostPage {
    constructor(modalCtrl, commonService, authService, dashboardService, projectService) {
        this.modalCtrl = modalCtrl;
        this.commonService = commonService;
        this.authService = authService;
        this.dashboardService = dashboardService;
        this.projectService = projectService;
        this.post = {};
        this.quillConfig = {
            //toolbar: '.toolbar',
            toolbar: {
                container: [
                    ['bold', 'italic', 'underline', 'strike'],
                    ['code-block'],
                    [{ 'header': 1 }, { 'header': 2 }],
                    [{ 'list': 'ordered' }, { 'list': 'bullet' }],
                    [{ 'script': 'sub' }, { 'script': 'super' }],
                    [{ 'indent': '-1' }, { 'indent': '+1' }],
                    [{ 'direction': 'rtl' }],
                    [{ 'size': ['small', false, 'large', 'huge'] }],
                    [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
                    [{ 'font': [] }],
                    [{ 'align': [] }],
                    ['clean'],
                    ['link', 'image', 'video']
                ],
            },
            "emoji-toolbar": false,
            "emoji-textarea": false,
            "emoji-shortname": false,
            keyboard: {
                bindings: {
                    enter: {
                        key: 13,
                        handler: (range, context) => {
                            console.log("enter");
                            return true;
                        }
                    }
                }
            }
        };
        this.user = {};
    }
    ngOnInit() {
        this.authService.userLogin.subscribe((resp) => {
            if (resp && Object.keys(resp).length > 0) {
                this.user = resp;
            }
        });
    }
    createPost() {
        this.commonService.presentLoading();
        this.dashboardService.createPost(this.post).then((resp) => {
            this.post.postId = resp.postId;
            this.post.createdAt = resp.createdAt;
            this.post.likes = [];
            this.post.firstName = this.user.firstName;
            this.post.lastName = this.user.lastName;
            this.post.image = this.user.image;
            this.commonService.showToast("success", "New Post Created!");
            this.commonService.loadingDismiss();
            this.modalCtrl.dismiss({ post: this.post });
        });
    }
};
NewPostPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController },
    { type: _services_common_service__WEBPACK_IMPORTED_MODULE_2__.CommonService },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService },
    { type: _services_dashboard_service__WEBPACK_IMPORTED_MODULE_4__.DashboardService },
    { type: _services_project_service__WEBPACK_IMPORTED_MODULE_5__.ProjectService }
];
NewPostPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-new-post',
        template: _new_post_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_new_post_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], NewPostPage);



/***/ }),

/***/ 9386:
/*!***********************************************!*\
  !*** ./src/app/services/dashboard.service.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DashboardService": () => (/* binding */ DashboardService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth.service */ 7556);




let DashboardService = class DashboardService {
    constructor(http, authService) {
        this.http = http;
        this.authService = authService;
    }
    createPost(postData) {
        return new Promise((resolve, reject) => {
            postData.organisationId = this.authService.organisationId;
            postData.creator = this.authService.userId;
            this.http.post(this.authService.apiUrl + 'createPost', postData).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getAllPost() {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getAllPost', { organisationId: this.authService.organisationId, skip: 0 }).subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getRandomQuote() {
        return new Promise((resolve, reject) => {
            this.http.get('https://api.quotable.io/random').subscribe((resp) => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    login(data) {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'login', data).subscribe(resp => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
    getNewsFeed() {
        return new Promise((resolve, reject) => {
            this.http.post(this.authService.apiUrl + 'getNewsFeed', {}).subscribe(resp => {
                resolve(resp);
            }, error => {
                reject(error);
            });
        });
    }
};
DashboardService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient },
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService }
];
DashboardService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], DashboardService);



/***/ }),

/***/ 9644:
/*!**************************************************************!*\
  !*** ./src/app/pages/new-post/new-post.page.scss?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "ion-menu ion-content {\n  --background: var(--ion-item-background, var(--ion-background-color, #fff));\n}\n\nion-menu.md ion-content {\n  --padding-start: 8px;\n  --padding-end: 8px;\n  --padding-top: 20px;\n  --padding-bottom: 20px;\n}\n\nion-menu.md ion-list {\n  padding: 20px 0;\n}\n\nion-menu.md ion-note {\n  margin-bottom: 30px;\n}\n\nion-menu.md ion-list-header,\nion-menu.md ion-note {\n  padding-left: 10px;\n}\n\nion-menu.md ion-list#inbox-list {\n  border-bottom: 1px solid var(--ion-color-step-150, #d7d8da);\n}\n\nion-menu.md ion-list#inbox-list ion-list-header {\n  font-size: 22px;\n  font-weight: 600;\n  min-height: 20px;\n}\n\nion-menu.md ion-list#labels-list ion-list-header {\n  font-size: 16px;\n  margin-bottom: 18px;\n  color: #757575;\n  min-height: 26px;\n}\n\nion-menu.md ion-item {\n  --padding-start: 10px;\n  --padding-end: 10px;\n  border-radius: 4px;\n}\n\nion-menu.md ion-item.selected {\n  --background: rgba(var(--ion-color-primary-rgb), 0.14);\n}\n\nion-menu.md ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.md ion-item ion-icon {\n  color: #616e7e;\n}\n\nion-menu.md ion-item ion-label {\n  font-weight: 500;\n}\n\nion-menu.ios ion-content {\n  --padding-bottom: 20px;\n}\n\nion-menu.ios ion-list {\n  padding: 20px 0 0 0;\n}\n\nion-menu.ios ion-note {\n  line-height: 24px;\n  margin-bottom: 20px;\n}\n\nion-menu.ios ion-item {\n  --padding-start: 16px;\n  --padding-end: 16px;\n  --min-height: 50px;\n}\n\nion-menu.ios ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.ios ion-item ion-icon {\n  font-size: 24px;\n  color: #73849a;\n}\n\nion-menu.ios ion-list#labels-list ion-list-header {\n  margin-bottom: 8px;\n}\n\nion-menu.ios ion-list-header,\nion-menu.ios ion-note {\n  padding-left: 16px;\n  padding-right: 16px;\n}\n\nion-menu.ios ion-note {\n  margin-bottom: 8px;\n}\n\nion-note {\n  display: inline-block;\n  font-size: 16px;\n  color: var(--ion-color-medium-shade);\n}\n\nion-item.selected {\n  --color: var(--ion-color-primary);\n}\n\nion-list {\n  background: #f7f7f7;\n  padding: 10px;\n}\n\nion-item {\n  --background: transparent;\n}\n\nion-input {\n  border: 0.5px solid rgb(83, 83, 83);\n  background: #161b22;\n  border-radius: 10px;\n  padding: 0px 10px !important;\n  color: #fff;\n}\n\nion-accordion {\n  background: #112c44;\n  color: #fff;\n}\n\nion-accordion.accordion-expanding .ion-accordion-toggle-icon,\nion-accordion.accordion-expanded .ion-accordion-toggle-icon {\n  color: #fff !important;\n}\n\nion-accordion.accordion-animated .ion-accordion-toggle-icon {\n  color: #fff !important;\n}\n\nion-accordion.accordion-animated .ion-accordion-toggle-icon {\n  color: #fff !important;\n}\n\n/* The container must be positioned relative: */\n\nion-item .custom-select {\n  position: relative;\n  font-family: Arial;\n}\n\nion-item .custom-select select {\n  display: none;\n  /*hide original SELECT element: */\n}\n\nselect {\n  width: 100%;\n  background: white;\n  color: #222;\n  padding: 7px;\n  border: 0.5px solid #ddd;\n  border-radius: 10px;\n  outline: none;\n}\n\nselect:active,\nselect:hover {\n  outline: none;\n}\n\nselect:focus {\n  border-color: gray;\n  outline: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5ldy1wb3N0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLDJFQUFBO0FBQ0o7O0FBRUU7RUFDRSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtBQUNKOztBQUVFO0VBQ0UsZUFBQTtBQUNKOztBQUVFO0VBQ0UsbUJBQUE7QUFDSjs7QUFFRTs7RUFFRSxrQkFBQTtBQUNKOztBQUVFO0VBQ0UsMkRBQUE7QUFDSjs7QUFFRTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUVBLGdCQUFBO0FBQUo7O0FBR0U7RUFDRSxlQUFBO0VBRUEsbUJBQUE7RUFFQSxjQUFBO0VBRUEsZ0JBQUE7QUFISjs7QUFNRTtFQUNFLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQUhKOztBQU1FO0VBQ0Usc0RBQUE7QUFISjs7QUFNRTtFQUNFLCtCQUFBO0FBSEo7O0FBTUU7RUFDRSxjQUFBO0FBSEo7O0FBTUU7RUFDRSxnQkFBQTtBQUhKOztBQU1FO0VBQ0Usc0JBQUE7QUFISjs7QUFNRTtFQUNFLG1CQUFBO0FBSEo7O0FBTUU7RUFDRSxpQkFBQTtFQUNBLG1CQUFBO0FBSEo7O0FBTUU7RUFDRSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUFISjs7QUFNRTtFQUNFLCtCQUFBO0FBSEo7O0FBTUU7RUFDRSxlQUFBO0VBQ0EsY0FBQTtBQUhKOztBQU1FO0VBQ0Usa0JBQUE7QUFISjs7QUFNRTs7RUFFRSxrQkFBQTtFQUNBLG1CQUFBO0FBSEo7O0FBTUU7RUFDRSxrQkFBQTtBQUhKOztBQU1FO0VBQ0UscUJBQUE7RUFDQSxlQUFBO0VBRUEsb0NBQUE7QUFKSjs7QUFPRTtFQUNFLGlDQUFBO0FBSko7O0FBT0U7RUFDRSxtQkFBQTtFQUNBLGFBQUE7QUFKSjs7QUFRRTtFQUNFLHlCQUFBO0FBTEo7O0FBUUU7RUFDRSxtQ0FBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSw0QkFBQTtFQUNBLFdBQUE7QUFMSjs7QUFZRTtFQUNFLG1CQUFBO0VBQ0EsV0FBQTtBQVRKOztBQWNFOztFQUVFLHNCQUFBO0FBWEo7O0FBZUU7RUFDRSxzQkFBQTtBQVpKOztBQWVFO0VBQ0Usc0JBQUE7QUFaSjs7QUF3QkUsK0NBQUE7O0FBQ0E7RUFDRSxrQkFBQTtFQUNBLGtCQUFBO0FBckJKOztBQXdCRTtFQUNFLGFBQUE7RUFDQSxpQ0FBQTtBQXJCSjs7QUF3QkU7RUFDRSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHdCQUFBO0VBQ0EsbUJBQUE7RUFFQSxhQUFBO0FBdEJKOztBQXlCRTs7RUFFRSxhQUFBO0FBdEJKOztBQTBCRTtFQUNFLGtCQUFBO0VBQ0EsYUFBQTtBQXZCSiIsImZpbGUiOiJuZXctcG9zdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tbWVudSBpb24tY29udGVudCB7XG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24taXRlbS1iYWNrZ3JvdW5kLCB2YXIoLS1pb24tYmFja2dyb3VuZC1jb2xvciwgI2ZmZikpO1xuICB9XG4gIFxuICBpb24tbWVudS5tZCBpb24tY29udGVudCB7XG4gICAgLS1wYWRkaW5nLXN0YXJ0OiA4cHg7XG4gICAgLS1wYWRkaW5nLWVuZDogOHB4O1xuICAgIC0tcGFkZGluZy10b3A6IDIwcHg7XG4gICAgLS1wYWRkaW5nLWJvdHRvbTogMjBweDtcbiAgfVxuICBcbiAgaW9uLW1lbnUubWQgaW9uLWxpc3Qge1xuICAgIHBhZGRpbmc6IDIwcHggMDtcbiAgfVxuICBcbiAgaW9uLW1lbnUubWQgaW9uLW5vdGUge1xuICAgIG1hcmdpbi1ib3R0b206IDMwcHg7XG4gIH1cbiAgXG4gIGlvbi1tZW51Lm1kIGlvbi1saXN0LWhlYWRlcixcbiAgaW9uLW1lbnUubWQgaW9uLW5vdGUge1xuICAgIHBhZGRpbmctbGVmdDogMTBweDtcbiAgfVxuICBcbiAgaW9uLW1lbnUubWQgaW9uLWxpc3QjaW5ib3gtbGlzdCB7XG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1zdGVwLTE1MCwgI2Q3ZDhkYSk7XG4gIH1cbiAgXG4gIGlvbi1tZW51Lm1kIGlvbi1saXN0I2luYm94LWxpc3QgaW9uLWxpc3QtaGVhZGVyIHtcbiAgICBmb250LXNpemU6IDIycHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBcbiAgICBtaW4taGVpZ2h0OiAyMHB4O1xuICB9XG4gIFxuICBpb24tbWVudS5tZCBpb24tbGlzdCNsYWJlbHMtbGlzdCBpb24tbGlzdC1oZWFkZXIge1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgXG4gICAgbWFyZ2luLWJvdHRvbTogMThweDtcbiAgXG4gICAgY29sb3I6ICM3NTc1NzU7XG4gIFxuICAgIG1pbi1oZWlnaHQ6IDI2cHg7XG4gIH1cbiAgXG4gIGlvbi1tZW51Lm1kIGlvbi1pdGVtIHtcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDEwcHg7XG4gICAgLS1wYWRkaW5nLWVuZDogMTBweDtcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XG4gIH1cbiAgXG4gIGlvbi1tZW51Lm1kIGlvbi1pdGVtLnNlbGVjdGVkIHtcbiAgICAtLWJhY2tncm91bmQ6IHJnYmEodmFyKC0taW9uLWNvbG9yLXByaW1hcnktcmdiKSwgMC4xNCk7XG4gIH1cbiAgXG4gIGlvbi1tZW51Lm1kIGlvbi1pdGVtLnNlbGVjdGVkIGlvbi1pY29uIHtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICB9XG4gIFxuICBpb24tbWVudS5tZCBpb24taXRlbSBpb24taWNvbiB7XG4gICAgY29sb3I6ICM2MTZlN2U7XG4gIH1cbiAgXG4gIGlvbi1tZW51Lm1kIGlvbi1pdGVtIGlvbi1sYWJlbCB7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgfVxuICBcbiAgaW9uLW1lbnUuaW9zIGlvbi1jb250ZW50IHtcbiAgICAtLXBhZGRpbmctYm90dG9tOiAyMHB4O1xuICB9XG4gIFxuICBpb24tbWVudS5pb3MgaW9uLWxpc3Qge1xuICAgIHBhZGRpbmc6IDIwcHggMCAwIDA7XG4gIH1cbiAgXG4gIGlvbi1tZW51LmlvcyBpb24tbm90ZSB7XG4gICAgbGluZS1oZWlnaHQ6IDI0cHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMjBweDtcbiAgfVxuICBcbiAgaW9uLW1lbnUuaW9zIGlvbi1pdGVtIHtcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDE2cHg7XG4gICAgLS1wYWRkaW5nLWVuZDogMTZweDtcbiAgICAtLW1pbi1oZWlnaHQ6IDUwcHg7XG4gIH1cbiAgXG4gIGlvbi1tZW51LmlvcyBpb24taXRlbS5zZWxlY3RlZCBpb24taWNvbiB7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgfVxuICBcbiAgaW9uLW1lbnUuaW9zIGlvbi1pdGVtIGlvbi1pY29uIHtcbiAgICBmb250LXNpemU6IDI0cHg7XG4gICAgY29sb3I6ICM3Mzg0OWE7XG4gIH1cbiAgXG4gIGlvbi1tZW51LmlvcyBpb24tbGlzdCNsYWJlbHMtbGlzdCBpb24tbGlzdC1oZWFkZXIge1xuICAgIG1hcmdpbi1ib3R0b206IDhweDtcbiAgfVxuICBcbiAgaW9uLW1lbnUuaW9zIGlvbi1saXN0LWhlYWRlcixcbiAgaW9uLW1lbnUuaW9zIGlvbi1ub3RlIHtcbiAgICBwYWRkaW5nLWxlZnQ6IDE2cHg7XG4gICAgcGFkZGluZy1yaWdodDogMTZweDtcbiAgfVxuICBcbiAgaW9uLW1lbnUuaW9zIGlvbi1ub3RlIHtcbiAgICBtYXJnaW4tYm90dG9tOiA4cHg7XG4gIH1cbiAgXG4gIGlvbi1ub3RlIHtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICBcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bS1zaGFkZSk7XG4gIH1cbiAgXG4gIGlvbi1pdGVtLnNlbGVjdGVkIHtcbiAgICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gIH1cbiAgXG4gIGlvbi1saXN0IHtcbiAgICBiYWNrZ3JvdW5kOiAjZjdmN2Y3O1xuICAgIHBhZGRpbmc6IDEwcHg7XG4gIH1cbiAgXG4gIFxuICBpb24taXRlbSB7XG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgfVxuICBcbiAgaW9uLWlucHV0IHtcbiAgICBib3JkZXI6IDAuNXB4IHNvbGlkIHJnYig4MywgODMsIDgzKTtcbiAgICBiYWNrZ3JvdW5kOiAjMTYxYjIyO1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgcGFkZGluZzogMHB4IDEwcHggIWltcG9ydGFudDtcbiAgICBjb2xvcjogI2ZmZjtcbiAgfVxuICBcbiAgLy8gaW5wdXQge1xuICAvLyAgIHBhZGRpbmc6IDEwcHggIWltcG9ydGFudDtcbiAgLy8gfVxuICBcbiAgaW9uLWFjY29yZGlvbiB7XG4gICAgYmFja2dyb3VuZDogIzExMmM0NDtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICAvLyBiYWNrZ3JvdW5kOiAjNzQ4Y2IyO1xuICB9XG4gIFxuICBcbiAgaW9uLWFjY29yZGlvbi5hY2NvcmRpb24tZXhwYW5kaW5nIC5pb24tYWNjb3JkaW9uLXRvZ2dsZS1pY29uLFxuICBpb24tYWNjb3JkaW9uLmFjY29yZGlvbi1leHBhbmRlZCAuaW9uLWFjY29yZGlvbi10b2dnbGUtaWNvbiB7XG4gICAgY29sb3I6ICNmZmYgIWltcG9ydGFudDtcbiAgfVxuICBcbiAgXG4gIGlvbi1hY2NvcmRpb24uYWNjb3JkaW9uLWFuaW1hdGVkIC5pb24tYWNjb3JkaW9uLXRvZ2dsZS1pY29uIHtcbiAgICBjb2xvcjogI2ZmZiAhaW1wb3J0YW50O1xuICB9XG4gIFxuICBpb24tYWNjb3JkaW9uLmFjY29yZGlvbi1hbmltYXRlZCAuaW9uLWFjY29yZGlvbi10b2dnbGUtaWNvbiB7XG4gICAgY29sb3I6ICNmZmYgIWltcG9ydGFudDtcbiAgfVxuICBcbiAgLy8gLm15LWN1c3RvbS1tb2RhbC1jc3MgLm1vZGFsLXdyYXBwZXIge1xuICAvLyAgIGhlaWdodDogMjAlO1xuICAvLyAgIHdpZHRoOiAyMCU7XG4gIC8vICAgcG9zaXRpb246IGFic29sdXRlOyBcbiAgLy8gICBkaXNwbGF5OiBibG9jazsgIFxuICAvLyB9XG4gIFxuICBcbiAgXG4gIC8qIFRoZSBjb250YWluZXIgbXVzdCBiZSBwb3NpdGlvbmVkIHJlbGF0aXZlOiAqL1xuICBpb24taXRlbSAuY3VzdG9tLXNlbGVjdCB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIGZvbnQtZmFtaWx5OiBBcmlhbDtcbiAgfVxuICBcbiAgaW9uLWl0ZW0gLmN1c3RvbS1zZWxlY3Qgc2VsZWN0IHtcbiAgICBkaXNwbGF5OiBub25lO1xuICAgIC8qaGlkZSBvcmlnaW5hbCBTRUxFQ1QgZWxlbWVudDogKi9cbiAgfVxuICBcbiAgc2VsZWN0IHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgICBjb2xvcjogIzIyMjtcbiAgICBwYWRkaW5nOiA3cHg7XG4gICAgYm9yZGVyOiAwLjVweCBzb2xpZCAjZGRkO1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgLy8gYm94LXNoYWRvdzogMCAwIDEwcHggMTAwcHggI2ZmZiBpbnNldDtcbiAgICBvdXRsaW5lOiBub25lXG4gIH1cbiAgXG4gIHNlbGVjdDphY3RpdmUsXG4gIHNlbGVjdDpob3ZlciB7XG4gICAgb3V0bGluZTogbm9uZVxuICB9XG4gIFxuICBcbiAgc2VsZWN0OmZvY3VzIHtcbiAgICBib3JkZXItY29sb3I6IGdyYXk7XG4gICAgb3V0bGluZTogbm9uZTtcbiAgfVxuICAiXX0= */";

/***/ }),

/***/ 6478:
/*!**************************************************************!*\
  !*** ./src/app/pages/new-post/new-post.page.html?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar color=\"gray\">\n    <ion-title>Create New Post</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"modalCtrl.dismiss()\">\n        <ion-icon name=\"arrow-down\"></ion-icon>\n      </ion-button>\n      <!-- <ion-button>\n        <ion-icon name=\"settings-outline\"></ion-icon>\n      </ion-button> -->\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-item lines=\"none\" style=\"margin-top: 20px;\">\n    <ion-avatar slot=\"start\">\n      <img [src]=\"user.image\">\n    </ion-avatar>\n    <ion-label>\n      <h2 style=\"color: #fff;font-weight:bold;\">\n        {{user.firstName}} {{user.lastName}}\n      </h2>\n    </ion-label>\n    </ion-item>\n  <ion-item lines=\"none\">\n    <ion-label position=\"stacked\" style=\"color: #fff;\">Whats on your mind..</ion-label>\n    <quill-editor [styles]=\"{color: '#fff'}\" [(ngModel)]=\"post.postDescription\" placeholder=\"\"\n      [modules]=\"quillConfig\"\n      style=\"background-color: #161b22; min-height: 100px;border-radius: 10px;border: 0.5px solid rgb(83, 83, 83);width: 100%;\">\n    </quill-editor>\n  </ion-item>\n</ion-content>\n<ion-footer color=\"gray\">\n  <ion-toolbar color=\"gray\">\n    <ion-buttons slot=\"end\">\n      <ion-button *ngIf=\"projectId != 'null'\" expand=\"block\" fill=\"solid\" color=\"success\"\n        style=\"font-weight: 300;width: 150px;\" (click)=\"createPost()\">\n        Submit\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-footer>";

/***/ })

}]);
//# sourceMappingURL=default-src_app_pages_new-post_new-post_page_ts.js.map